
using UnityEngine;
using System.Reflection;

namespace ORKFramework.Reflection
{
	public class ChangeFields : BaseData
	{
		// parameters
		[ORKEditorArray(false, "Add Field", "Adds a field that will be changed.", "", 
			"Remove", "Removes this field.", "", 
			foldout=true, foldoutText=new string[] {"Field", "The field's value will be changed.", ""})]
		public ChangeField[] field = new ChangeField[0];
		
		public ChangeFields()
		{
			
		}
		
		public void Change(System.Object instance)
		{
			if(instance != null)
			{
				System.Type instanceType = instance.GetType();
				if(instanceType != null)
				{
					for(int i=0; i<this.field.Length; i++)
					{
						this.field[i].Change(instance, instanceType);
					}
				}
			}
		}
		
		public void ChangeStatic(string className)
		{
			if(className != "")
			{
				System.Type classType = ORK.Core.TypeHandler.GetType(className);
				if(classType != null)
				{
					for(int i=0; i<this.field.Length; i++)
					{
						this.field[i].ChangeStatic(classType);
					}
				}
				else
				{
					Debug.LogWarning("Class not found: " + className);
				}
			}
		}
	}
}
