
using System.Collections.Generic;

namespace ORKFramework
{
	public class ContentSorter : BaseData
	{
		[ORKEditorHelp("Sort By", "Select how the data will be sorted:\n" +
			"- None: The data isn't sorted and will be listet as it appears.\n" +
			"- Name: The data is sorted by name (e.g. item name, ability name).\n" +
			"- ID: The data is sorted by ID (i.e. the index of the data).\n" +
			"- Type: The data is sorted by type (e.g. item type, ability type).\n" +
			"- Type Name: The data is first sorted by type, then by name.\n" +
			"- Type ID: The data is first sorted by type, then by ID.", "")]
		public ContentSorting sorting = ContentSorting.Name;

		[ORKEditorHelp("Invert Order", "The data is sorted in inverted order.", "")]
		public bool invert = false;

		public ContentSorter()
		{

		}


		/*
		============================================================================
		Sort functions
		============================================================================
		*/
		public void SortContent(ref List<IContent> list)
		{
			if(ContentSorting.Name == this.sorting)
			{
				list.Sort(new NameContentSorter(this.invert));
			}
			else if(ContentSorting.ID == this.sorting)
			{
				list.Sort(new IDContentSorter(this.invert));
			}
			else if(ContentSorting.Type == this.sorting)
			{
				list.Sort(new TypeContentSorter(this.invert));
			}
			else if(ContentSorting.TypeName == this.sorting)
			{
				list.Sort(new TypeNameContentSorter(this.invert));
			}
			else if(ContentSorting.TypeID == this.sorting)
			{
				list.Sort(new TypeIDContentSorter(this.invert));
			}
		}

		public void Sort(ref List<Area> list)
		{
			if(ContentSorting.None == this.sorting)
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else
			{
				List<IContent> tmpList = new List<IContent>(list.Count);
				foreach(Area data in list)
				{
					tmpList.Add(data as IContent);
				}

				this.SortContent(ref tmpList);

				list.Clear();
				foreach(IContent data in tmpList)
				{
					list.Add(data as Area);
				}
			}
		}

		public void Sort(ref List<Log> list)
		{
			if(ContentSorting.None == this.sorting)
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else
			{
				List<IContent> tmpList = new List<IContent>(list.Count);
				foreach(Log data in list)
				{
					tmpList.Add(data as IContent);
				}

				this.SortContent(ref tmpList);

				list.Clear();
				foreach(IContent data in tmpList)
				{
					list.Add(data as Log);
				}
			}
		}

		public void Sort(ref List<CraftingRecipeShortcut> list)
		{
			if(ContentSorting.None == this.sorting)
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else
			{
				List<IContent> tmpList = new List<IContent>(list.Count);
				foreach(CraftingRecipeShortcut data in list)
				{
					tmpList.Add(data as IContent);
				}

				this.SortContent(ref tmpList);

				list.Clear();
				foreach(IContent data in tmpList)
				{
					list.Add(data as CraftingRecipeShortcut);
				}
			}
		}

		public void Sort(ref List<Quest> list)
		{
			if(ContentSorting.None == this.sorting)
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else
			{
				List<IContent> tmpList = new List<IContent>(list.Count);
				foreach(Quest data in list)
				{
					tmpList.Add(data as IContent);
				}

				this.SortContent(ref tmpList);

				list.Clear();
				foreach(IContent data in tmpList)
				{
					list.Add(data as Quest);
				}
			}
		}

		public void Sort(ref List<BestiaryEntry> list)
		{
			if(ContentSorting.None == this.sorting)
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else
			{
				List<IContent> tmpList = new List<IContent>(list.Count);
				foreach(BestiaryEntry data in list)
				{
					tmpList.Add(data as IContent);
				}

				this.SortContent(ref tmpList);

				list.Clear();
				foreach(IContent data in tmpList)
				{
					list.Add(data as BestiaryEntry);
				}
			}
		}

		public void Sort(ref List<AbilityShortcut> list)
		{
			if(ContentSorting.None == this.sorting)
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else
			{
				List<IContent> tmpList = new List<IContent>(list.Count);
				foreach(AbilityShortcut data in list)
				{
					tmpList.Add(data as IContent);
				}

				this.SortContent(ref tmpList);

				list.Clear();
				foreach(IContent data in tmpList)
				{
					list.Add(data as AbilityShortcut);
				}
			}
		}

		public void Sort(ref List<EquipShortcut> list)
		{
			if(ContentSorting.None == this.sorting)
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else
			{
				List<IContent> tmpList = new List<IContent>(list.Count);
				foreach(EquipShortcut data in list)
				{
					tmpList.Add(data as IContent);
				}

				this.SortContent(ref tmpList);

				list.Clear();
				foreach(IContent data in tmpList)
				{
					list.Add(data as EquipShortcut);
				}
			}
		}

		public void Sort(ref List<ItemShortcut> list)
		{
			if(ContentSorting.None == this.sorting)
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else
			{
				List<IContent> tmpList = new List<IContent>(list.Count);
				foreach(ItemShortcut data in list)
				{
					tmpList.Add(data as IContent);
				}

				this.SortContent(ref tmpList);

				list.Clear();
				foreach(IContent data in tmpList)
				{
					list.Add(data as ItemShortcut);
				}
			}
		}

		public void Sort(ref List<IShortcut> list)
		{
			if(ContentSorting.None == this.sorting)
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else
			{
				List<IContent> tmpList = new List<IContent>(list.Count);
				foreach(IShortcut data in list)
				{
					tmpList.Add(data as IContent);
				}

				this.SortContent(ref tmpList);

				list.Clear();
				foreach(IContent data in tmpList)
				{
					list.Add(data as IShortcut);
				}
			}
		}

		public void Sort(ref List<ResearchTree> list)
		{
			if(ContentSorting.None == this.sorting)
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else
			{
				List<IContent> tmpList = new List<IContent>(list.Count);
				foreach(ResearchTree data in list)
				{
					tmpList.Add(data as IContent);
				}

				this.SortContent(ref tmpList);

				list.Clear();
				foreach(IContent data in tmpList)
				{
					list.Add(data as ResearchTree);
				}
			}
		}

		public void Sort(ref List<ResearchItem> list)
		{
			if(ContentSorting.None == this.sorting)
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else
			{
				List<IContent> tmpList = new List<IContent>(list.Count);
				foreach(ResearchItem data in list)
				{
					tmpList.Add(data as IContent);
				}

				this.SortContent(ref tmpList);

				list.Clear();
				foreach(IContent data in tmpList)
				{
					list.Add(data as ResearchItem);
				}
			}
		}

		public void Sort(ref List<ShopWrapperShortcut> list)
		{
			if(ContentSorting.None == this.sorting)
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else
			{
				List<IContent> tmpList = new List<IContent>(list.Count);
				foreach(ShopWrapperShortcut data in list)
				{
					tmpList.Add(data as IContent);
				}

				this.SortContent(ref tmpList);

				list.Clear();
				foreach(IContent data in tmpList)
				{
					list.Add(data as ShopWrapperShortcut);
				}
			}
		}

		public void Sort(ref List<AIBehaviourShortcut> list)
		{
			if(ContentSorting.None == this.sorting)
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else
			{
				List<IContent> tmpList = new List<IContent>(list.Count);
				foreach(AIBehaviourShortcut data in list)
				{
					tmpList.Add(data as IContent);
				}

				this.SortContent(ref tmpList);

				list.Clear();
				foreach(IContent data in tmpList)
				{
					list.Add(data as AIBehaviourShortcut);
				}
			}
		}

		public void Sort(ref List<AIRulesetShortcut> list)
		{
			if(ContentSorting.None == this.sorting)
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else
			{
				List<IContent> tmpList = new List<IContent>(list.Count);
				foreach(AIRulesetShortcut data in list)
				{
					tmpList.Add(data as IContent);
				}

				this.SortContent(ref tmpList);

				list.Clear();
				foreach(IContent data in tmpList)
				{
					list.Add(data as AIRulesetShortcut);
				}
			}
		}
	}
}
