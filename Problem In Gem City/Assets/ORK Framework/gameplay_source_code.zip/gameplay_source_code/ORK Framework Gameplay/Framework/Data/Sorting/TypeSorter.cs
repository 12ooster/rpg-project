
using System.Collections.Generic;

namespace ORKFramework
{
	public class TypeSorter : BaseData
	{
		[ORKEditorHelp("Sort By", "Select how the data will be sorted:\n" +
			"- None: The data isn't sorted and will be listet as it appears.\n" +
			"- Name: The data are sorted by name.\n" +
			"- ID: The data are sorted by ID (i.e. the index of the data).", "")]
		public TypeSorting sorting = TypeSorting.Name;

		[ORKEditorHelp("Invert Order", "The data is sorted in inverted order.", "")]
		public bool invert = false;

		public TypeSorter()
		{

		}

		public TypeSorter(TypeSorting sorting)
		{
			this.sorting = sorting;
		}

		public void Sort(ref List<int> list, ORKDataType type)
		{
			if(TypeSorting.None == this.sorting)
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else if(TypeSorting.Name == this.sorting)
			{
				GetName getName = ORK.GetNameFunction(type);
				if(getName != null)
				{
					list.Sort(new NameSorter(getName, this.invert));
				}
			}
			else if(TypeSorting.ID == this.sorting)
			{
				list.Sort(new IDSorter(this.invert));
			}
		}

		public void Sort(ref List<Combatant> list)
		{
			if(TypeSorting.None == this.sorting)
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else if(TypeSorting.Name == this.sorting)
			{
				list.Sort(new NameCombatantSorter(this.invert));
			}
			else if(TypeSorting.ID == this.sorting)
			{
				list.Sort(new IDCombatantSorter(this.invert));
			}
		}

		public void Sort(ref List<SortIDDataType> list)
		{
			if(TypeSorting.None == this.sorting)
			{
				if(this.invert)
				{
					list.Reverse();
				}
			}
			else if(TypeSorting.Name == this.sorting)
			{
				list.Sort(new NameDataTypeSorter(this.invert));
			}
			else if(TypeSorting.ID == this.sorting)
			{
				list.Sort(new IDDataTypeSorter(this.invert));
			}
		}
	}
}
