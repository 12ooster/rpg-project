﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CombatantDistanceSorter : IComparer<Combatant>
	{
		private Combatant user;

		public CombatantDistanceSorter(Combatant user)
		{
			this.user = user;
		}

		public int Compare(Combatant x, Combatant y)
		{
			if(x.GameObject == null &&
				y.GameObject == null)
			{
				return 0;
			}
			else if(x.GameObject != null &&
				y.GameObject == null)
			{
				return -1;
			}
			else if(x.GameObject == null &&
				y.GameObject != null)
			{
				return 1;
			}
			else
			{
				return Vector3.Distance(this.user.GameObject.transform.position, x.GameObject.transform.position).CompareTo(
					Vector3.Distance(this.user.GameObject.transform.position, y.GameObject.transform.position));
			}
		}
	}
}
