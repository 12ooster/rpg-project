﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class IconInfo : BaseData
	{
		[ORKEditorHelp("Icon", "Select the icon that will be used.", "")]
		public Texture icon;

		public IconInfo()
		{

		}
	}
}
