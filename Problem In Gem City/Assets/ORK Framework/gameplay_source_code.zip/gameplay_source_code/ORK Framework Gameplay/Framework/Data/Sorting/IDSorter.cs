
using System.Collections.Generic;

namespace ORKFramework
{
	public class IDSorter : IComparer<int>
	{
		private bool invert = false;

		public IDSorter(bool invert)
		{
			this.invert = invert;
		}

		public int Compare(int x, int y)
		{
			if(this.invert)
			{
				return y.CompareTo(x);
			}
			else
			{
				return x.CompareTo(y);
			}
		}
	}

	public class IDDataTypeSorter : IComparer<SortIDDataType>
	{
		private bool invert = false;

		public IDDataTypeSorter(bool invert)
		{
			this.invert = invert;
		}

		public int Compare(SortIDDataType x, SortIDDataType y)
		{
			if(this.invert)
			{
				return y.id.CompareTo(x.id);
			}
			else
			{
				return x.id.CompareTo(y.id);
			}
		}
	}
}
