
using System.Collections.Generic;

namespace ORKFramework
{
	public class StatusEffectSorter : IComparer<StatusEffect>
	{
		public int Compare(StatusEffect x , StatusEffect y)
		{
			if(x.Setting.priority == y.Setting.priority)
			{
				return x.RealID.CompareTo(y.RealID);
			}
			else
			{
				return x.Setting.priority.CompareTo(y.Setting.priority);
			}
		}
	}
}
