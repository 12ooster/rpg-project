
using UnityEngine;

namespace ORKFramework
{
	public class FactionSympathySettings : BaseSettings
	{
		// sympathy settings
		[ORKEditorHelp("Minimum Sympathy", "The minimum sympathy value a faction can reach.", "")]
		[ORKEditorInfo("Sympathy Settings", "A factions sympathy defines how combatants " +
			"of the faction will react to other factions.\n" +
			"Negative sympathy values will make the faction an enemy, positive values will make it an ally.", "")]
		public float min = -1000;

		[ORKEditorHelp("Maximum Sympathy", "The maximum sympathy value a faction can reach.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public float max = 1000;


		// sympathy matrix
		[ORKEditorInfo(hide=true)]
		[ORKEditorArray(ORKDataType.Faction)]
		public FactionSympathy[] data = new FactionSympathy[] {
			new FactionSympathy(new float[] {0, -1000, 1000}),
			new FactionSympathy(new float[] {-1000, 0, -1000}),
			new FactionSympathy(new float[] {1000, -1000, 0})
		};

		public FactionSympathySettings(ORKProjectAsset project)
		{
			this.LoadProject(project);
		}

		public override void SetRealIDs()
		{

		}


		/*
		============================================================================
		Paths and files
		============================================================================
		*/
		public override string FILENAME
		{
			get { return "factionSympathy"; }
		}


		/*
		============================================================================
		Add, copy and remove
		============================================================================
		*/
		public override int Add()
		{
			return -1;
		}

		public override int Copy(int index)
		{
			return -1;
		}

		public override void Remove(int index)
		{

		}

		public override void Move(int index, bool down)
		{

		}

		public void CheckMatrix()
		{
			for(int i = 0; i < this.data.Length; i++)
			{
				for(int j = 0; j < this.data[i].sympathy.Length; j++)
				{
					if(i == j)
					{
						this.data[i].sympathy[j] = 0;
					}
					else if(j < i)
					{
						this.data[i].sympathy[j] = this.data[j].sympathy[i];
					}
					ValueHelper.Limit(ref this.data[i].sympathy[j], this.min, this.max);
				}
			}
		}


		/*
		============================================================================
		Names and count
		============================================================================
		*/
		public override string GetName(int index)
		{
			return "";
		}

		public override string[] GetNames(bool addIndex)
		{
			return new string[0];
		}

		public override int Count
		{
			get
			{
				return 0;
			}
		}


		/*
		============================================================================
		Add, remove callbacks
		============================================================================
		*/
		public override void DataAdded(ORKDataType type, int index)
		{
			if(ORKDataType.Faction == type)
			{
				for(int i = 0; i < this.data.Length; i++)
				{
					ArrayHelper.Add(ref this.data[i].sympathy, 0.0f);
				}
				ArrayHelper.Add(ref this.data, new FactionSympathy());
				this.CheckMatrix();
			}
			else
			{
				DataHelper.DataAdded(this, type, index);
			}
		}

		public override void DataRemoved(ORKDataType type, int index, int index2)
		{
			if(ORKDataType.Faction == type)
			{
				ArrayHelper.RemoveAt(ref this.data, index);
				for(int i = 0; i < this.data.Length; i++)
				{
					ArrayHelper.RemoveAt(ref this.data[i].sympathy, index);
				}
				this.CheckMatrix();
			}
			else
			{
				DataHelper.DataRemoved(this, type, index, index2);
			}
		}

		public override void DataMoved(ORKDataType type, bool down, int index, int index2)
		{
			if(ORKDataType.Faction == type)
			{
				if(down)
				{
					ArrayHelper.MoveDown(ref this.data, index);
					for(int i = 0; i < this.data.Length; i++)
					{
						ArrayHelper.MoveDown(ref this.data[i].sympathy, index);
					}
				}
				else
				{
					ArrayHelper.MoveUp(ref this.data, index);
					for(int i = 0; i < this.data.Length; i++)
					{
						ArrayHelper.MoveUp(ref this.data[i].sympathy, index);
					}
				}
				this.CheckMatrix();
			}
			else
			{
				DataHelper.DataMoved(this, type, down, index, index2);
			}
		}
	}
}
