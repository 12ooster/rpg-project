
using UnityEngine;

namespace ORKFramework
{
	public class LanguageContent : BaseData
	{
		[ORKEditorHelp("Text", "The text of this button.", "")]
		[ORKEditorInfo(isTextArea=true)]
		public string name = "";

		[ORKEditorHelp("Icon", "The icon of this button.", "")]
		public Texture icon;
		
		public LanguageContent()
		{
			
		}
		
		public LanguageContent(string name)
		{
			this.name = name;
		}
		
		public string GetName()
		{
			return this.name;
		}
		
		public Texture GetIcon()
		{
			return this.icon;
		}
		
		public GUIContent GetContent()
		{
			return new GUIContent(this.name, this.icon);
		}
		
		public ChoiceContent GetChoiceContent()
		{
			return new ChoiceContent(new GUIContent(this.name, this.icon));
		}
	}
}

