﻿
using UnityEngine;
using ORKFramework.AI;
using System.Collections.Generic;

namespace ORKFramework.UI
{
	public class AIRulesetBMItem : BMItem
	{
		private int slotIndex = -1;

		private AIRulesetShortcut ruleset;

		public AIRulesetBMItem(int slotIndex, AIRulesetShortcut ruleset, ChoiceContent content)
		{
			this.slotIndex = slotIndex;
			this.ruleset = ruleset;
			this.content = content;
		}

		public override void CreateDrag(Combatant owner)
		{
			// portrait
			if(this.ruleset != null &&
				this.content.portrait == null &&
				owner.BattleMenu.Settings.showAIRulesetPortraits &&
				this.ruleset.HasPortrait())
			{
				this.content.portrait = this.ruleset.GetPortrait();
			}
		}

		public override bool ActiveCheck(Combatant owner)
		{
			bool tmp = this.content.Active;
			if(this.ruleset == null)
			{
				this.content.Active = owner.AI.AIRulesetSlot[this.slotIndex].Equipped;
			}
			else
			{
				this.content.Active = this.ruleset.CanUse(owner, false);
			}
			return tmp != this.content.Active;
		}

		public override bool Accepted(Combatant owner)
		{
			if(owner.BattleMenu != null)
			{
				if(this.ruleset == null)
				{
					owner.AI.UnequipAIRuleset(this.slotIndex, true, true);
				}
				else
				{
					owner.AI.EquipAIRuleset(this.ruleset.ID, this.slotIndex, true, true, true);
				}

				if(owner.BattleMenu.CommandedBy != null)
				{
					owner.EndBattleMenu(true);
				}
				else
				{
					owner.BattleMenu.Show(true);
				}
				return true;
			}
			return false;
		}
	}
}
