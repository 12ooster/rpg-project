
using UnityEngine;
using ORKFramework;
using ORKFramework.Events;
using System.Collections.Generic;

namespace ORKFramework.Animations
{
	public class MecanimAutoRotationParameter : BaseData
	{
		[ORKEditorHelp("Rotation Type", "Select which rotation type will be used:\n" +
			"- Full Degree: Sets a float parameter to the actual rotation in degree (0-360).\n" +
			"- Direction 4: Sets an int parameter to a 4-directional " +
			"number representation of the rotation " +
			"(0-3, 0 = north, 1 = east, 2 = south, 3 = west).\n" +
			"- Direction 8: Sets an int parameter to an 8-directional " +
			"number representation of the rotation " +
			"(0-7, 0 = norht, 1 = north-east, 2 = east, 3 = south-east, etc.).", "")]
		public MecanimRotationType type = MecanimRotationType.FullDegree;

		[ORKEditorHelp("Parameter Name", "The name of the int/float parameter " +
			"used to set the rotation of the combatant.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string parameterName = "";

		public MecanimAutoRotationParameter()
		{

		}

		public void SetParameter(Animator animator, float rotation)
		{
			if(MecanimRotationType.FullDegree == this.type)
			{
				ValueHelper.SecureRotation(ref rotation);
				animator.SetFloat(this.parameterName, rotation);
			}
			else if(MecanimRotationType.Direction4 == this.type)
			{
				animator.SetInteger(this.parameterName, ValueHelper.Get4Directional(rotation));
			}
			else if(MecanimRotationType.Direction8 == this.type)
			{
				animator.SetInteger(this.parameterName, ValueHelper.Get8Directional(rotation));
			}
		}
	}
}
