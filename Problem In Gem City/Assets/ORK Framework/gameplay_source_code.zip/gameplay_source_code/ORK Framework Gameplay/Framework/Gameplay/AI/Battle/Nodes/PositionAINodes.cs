
using ORKFramework;
using ORKFramework.AI;
using ORKFramework.Behaviours;
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.AI.Steps
{
	[ORKEditorHelp("Check Distance", "The distance between user and target is checked with a defined value.\n" +
		"If the check is valid, 'Success' will be executed next, else 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Position", "Check")]
	public class CheckDistanceStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings.\n" +
			"- Clear: The targets will be removed from the list.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;


		// distance
		[ORKEditorHelp("Ignore Height Distance", "Height differences to the targets are ignored when calculating the distance.\n" +
			"Depending on the 'Horizontal Plane' defined in the game settings, " +
			"this either ignores the Y-axis (XZ plane, 3D) or the Z-axis (XY plane, 2D).", "")]
		[ORKEditorInfo(separator=true, labelText="Distance")]
		public bool ignoreHeightDistance = false;

		[ORKEditorHelp("Ignore Radius", "The box radius settings of the combatants will be ignored when calculating the distance.", "")]
		public bool ignComRad = false;


		// check
		[ORKEditorHelp("Check Type", "Checks if the value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the value is between two defined values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[ORKEditorInfo(separator=true)]
		public VariableValueCheck check = VariableValueCheck.IsEqual;


		// check value
		[ORKEditorInfo(separator=true, labelText="Check Value")]
		public AIFloat value = new AIFloat();

		// check value 2
		[ORKEditorInfo(separator=true, labelText="Check Value 2")]
		[ORKEditorLayout(new string[] {"check", "check"},
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive},
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public AIFloat value2 = new AIFloat();

		public CheckDistanceStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<bool>("ignY"))
			{
				data.Get("ignY", ref this.ignoreHeightDistance);
			}
		}

		public override BaseAction Execute(ref int currentStep, Combatant user,
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			bool any = false;
			if(FoundTargets.Clear == this.foundType)
			{
				foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(foundTargets);
				foundTargets.Clear();
				this.Check(ref any, user, tmp, foundTargets);
			}

			// check all possible targets
			this.Check(ref any, user,
				this.GetTargetList(this.targetType, this.targetExcludeSelf, user, allies, enemies),
				foundTargets);

			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check for status requirements
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(ValueHelper.CheckVariableValue(user.DistanceTo(list[i],
							this.ignoreHeightDistance, this.ignComRad, ORK.GameSettings.horizontalPlane),
						this.value.GetValue(user, list[i]),
						this.value2 != null ? this.value2.GetValue(user, list[i]) : 0,
						this.check))
					{
						any = true;
						if(!foundTargets.Contains(list[i]))
						{
							foundTargets.Add(list[i]);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check.ToString() + " " + this.value.GetInfoText();
		}
	}

	[ORKEditorHelp("Check Angle", "The angle between user and target is checked with a defined value.\n" +
		"If the check is valid, 'Success' will be executed next, else 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Position", "Check")]
	public class CheckAngleStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings.\n" +
			"- Clear: The targets will be removed from the list.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;


		// angle
		[ORKEditorHelp("Use Direction", "The angle between the forward directions of user and target will be calculated.\n" +
			"E.g. the result will be 0 if both are looking into the same direction, -180/180 if they look into opposite directions.\n" +
			"If disabled, the angle between the positions will be calculated.\n" +
			"E.g. the result will be 0 if the user looks directly at the target, -180/180 if he looks away from the target.", "")]
		[ORKEditorInfo(separator=true, labelText="Angle")]
		public bool direction = false;

		[ORKEditorHelp("Horizontal Plane", "Select the horizontal plane (i.e. which axes are used for horizontal movement):\n" +
			"- XZ: The game objects are moving on the XZ plane horizontally, i.e. default 3D behaviour.\n" +
			"- XY: The game objects are moving on the XY plane horizontally, i.e. default 2D behaviour.", "")]
		public HorizontalPlaneType horizontalPlane = HorizontalPlaneType.XZ;

		[ORKEditorHelp("From Target", "The angle is calculated from target to user.\n" +
			"If disabled, the angle is calculated from user to target.", "")]
		[ORKEditorLayout("direction", false, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool fromTarget = false;


		// check
		[ORKEditorHelp("Check Type", "Checks if the value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the value is between two defined values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[ORKEditorInfo(separator=true)]
		public VariableValueCheck check = VariableValueCheck.IsEqual;


		// check value
		[ORKEditorInfo(separator=true, labelText="Check Value")]
		public AIFloat value = new AIFloat();

		// check value 2
		[ORKEditorInfo(separator=true, labelText="Check Value 2")]
		[ORKEditorLayout(new string[] {"check", "check"},
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive},
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public AIFloat value2 = new AIFloat();

		public CheckAngleStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, Combatant user,
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			bool any = false;
			if(FoundTargets.Clear == this.foundType)
			{
				foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(foundTargets);
				foundTargets.Clear();
				this.Check(ref any, user, tmp, foundTargets);
			}

			// check all possible targets
			this.Check(ref any, user,
				this.GetTargetList(this.targetType, this.targetExcludeSelf, user, allies, enemies),
				foundTargets);

			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check for status requirements
			if(user.GameObject != null)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null && list[i].GameObject != null)
					{
						float tmpVal = 0;
						if(this.direction)
						{
							tmpVal = VectorHelper.HorizontalDirectionAngle(user.GameObject.transform,
								list[i].GameObject.transform, this.horizontalPlane);
						}
						else if(this.fromTarget)
						{
							tmpVal = VectorHelper.HorizontalAngle(list[i].GameObject.transform,
								user.GameObject.transform.position, this.horizontalPlane);
						}
						else
						{
							tmpVal = VectorHelper.HorizontalAngle(user.GameObject.transform,
								list[i].GameObject.transform.position, this.horizontalPlane);
						}

						if(ValueHelper.CheckVariableValue(tmpVal,
							this.value.GetValue(user, list[i]),
							this.value2 != null ? this.value2.GetValue(user, list[i]) : 0,
							this.check))
						{
							any = true;
							if(!foundTargets.Contains(list[i]))
							{
								foundTargets.Add(list[i]);
							}
						}
					}
				}
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check + " " + this.value.GetInfoText() +
				(this.direction ? " Direction" : "") + (this.fromTarget ? " from Target" : "");
		}
	}

	[ORKEditorHelp("Check Orientation", "Checks the orientation from user to target (e.g. if the target is in front of the user).\n" +
		"If the check is valid, 'Success' will be executed next, else 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Position", "Check")]
	public class CheckOrientationStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings.\n" +
			"- Clear: The targets will be removed from the list.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;


		// orientation
		[ORKEditorHelp("Orientation", "Select the orientation that'll be checked for:\n" +
			"- None: The orientation is ignored.\n" +
			"- Front: The target has to be in front of the user.\n" +
			"- Back: The target has to be in the back of the user.\n" +
			"- Left: The target has to be left of the user.\n" +
			"- Right: The target has to be right of the user.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75, separator=true, labelText="Orientation")]
		public Orientation orientation = Orientation.Front;

		[ORKEditorHelp("Horizontal Plane", "Select the horizontal plane (i.e. which axes are used for horizontal movement):\n" +
			"- XZ: The game objects are moving on the XZ plane horizontally, i.e. default 3D behaviour.\n" +
			"- XY: The game objects are moving on the XY plane horizontally, i.e. default 2D behaviour.", "")]
		public HorizontalPlaneType horizontalPlane = HorizontalPlaneType.XZ;

		[ORKEditorHelp("From Target", "The orientation is checked from target to user.\n" +
			"If disabled, the orientation is checked from user to target.", "")]
		public bool fromTarget = false;

		public CheckOrientationStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, Combatant user,
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			bool any = false;
			if(FoundTargets.Clear == this.foundType)
			{
				foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(foundTargets);
				foundTargets.Clear();
				this.Check(ref any, user, tmp, foundTargets);
			}

			// check all possible targets
			this.Check(ref any, user,
				this.GetTargetList(this.targetType, this.targetExcludeSelf, user, allies, enemies),
				foundTargets);

			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check for status requirements
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					Orientation check = Orientation.None;
					if(user.GameObject != null && list[i].GameObject != null)
					{
						if(this.fromTarget)
						{
							check = VectorHelper.GetOrientation(list[i].GameObject.transform,
								user.GameObject.transform, this.horizontalPlane);
						}
						else
						{
							check = VectorHelper.GetOrientation(user.GameObject.transform,
								list[i].GameObject.transform, this.horizontalPlane);
						}
					}
					if(Orientation.None == this.orientation ||
						this.orientation == check)
					{
						any = true;
						if(!foundTargets.Contains(list[i]))
						{
							foundTargets.Add(list[i]);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.orientation + (this.fromTarget ? ", from Target" : "");
		}
	}

	[ORKEditorHelp("Check Grid Distance", "The distance on a battle grid between user and target is checked with a defined value.\n" +
		"Neighbouring cells have a distance of 1, a cell between is distance of 2, etc.\n" +
		"If the check is valid, 'Success' will be executed next, else 'Failed'.\n" +
		"Any combatant that matches the requirements will be added to the target list. " +
		"The target list will be used by actions to determine the target.\n" +
		"Only used in grid battles.", "")]
	[ORKNodeInfo("Position", "Check")]
	public class CheckGridDistanceStep : BaseAICheckStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings.\n" +
			"- Clear: The targets will be removed from the list.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;


		// check
		[ORKEditorHelp("Check Type", "Checks if the value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the value is between two defined values, including the values.\n" +
			"Range exclusive checks if the value is between two defined values, excluding the values.\n" +
			"Approximately checks if the value is similar to the defined value.", "")]
		[ORKEditorInfo(separator=true)]
		public VariableValueCheck check = VariableValueCheck.IsEqual;


		// check value
		[ORKEditorInfo(separator=true, labelText="Check Value")]
		public AIFloat value = new AIFloat();

		// check value 2
		[ORKEditorInfo(separator=true, labelText="Check Value 2")]
		[ORKEditorLayout(new string[] {"check", "check"},
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive},
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public AIFloat value2 = new AIFloat();

		public CheckGridDistanceStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, Combatant user,
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			bool any = false;

			if(ORK.Battle.Grid != null &&
				user.GridCell != null)
			{
				if(FoundTargets.Clear == this.foundType)
				{
					foundTargets.Clear();
				}
				else if(FoundTargets.Check == this.foundType)
				{
					List<Combatant> tmp = new List<Combatant>(foundTargets);
					foundTargets.Clear();
					this.Check(ref any, user, tmp, foundTargets);
				}

				// check all possible targets
				this.Check(ref any, user,
					this.GetTargetList(this.targetType, this.targetExcludeSelf, user, allies, enemies),
					foundTargets);
			}

			// any target found?
			if(any)
			{
				currentStep = this.next;
			}
			else
			{
				currentStep = this.nextFail;
			}
			return null;
		}

		private void Check(ref bool any, Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			// check for status requirements
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null && list[i].GridCell != null)
				{
					if(ValueHelper.CheckVariableValue(
						user.GridCell.CubeCoord.Distance(list[i].GridCell.CubeCoord),
						this.value.GetValue(user, list[i]),
						this.value2 != null ? this.value2.GetValue(user, list[i]) : 0,
						this.check))
					{
						any = true;
						if(!foundTargets.Contains(list[i]))
						{
							foundTargets.Add(list[i]);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.check.ToString() + " " + this.value.GetInfoText();
		}
	}

	[ORKEditorHelp("Rotate To Target", "Changes the user's rotation to look at the found target.", "")]
	[ORKNodeInfo("Position")]
	public class RotateToTargetStep : BaseAIStep
	{
		[ORKEditorHelp("Use Center", "Use the center position when multiple targets are available.\n" +
			"If disabled, the first available target will be used.", "")]
		public bool useCenter = false;

		public RotateToTargetStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, Combatant user,
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			if(user.GameObject != null)
			{
				List<Combatant> preferredTargets = this.GetPreferredTargets(user, foundTargets);

				if(preferredTargets.Count > 0)
				{
					if(this.useCenter)
					{
						user.LookAt(TransformHelper.GetCenterPosition(preferredTargets));
					}
					else
					{
						for(int i = 0; i < preferredTargets.Count; i++)
						{
							if(preferredTargets[i] != null &&
								preferredTargets[i].GameObject != null)
							{
								user.LookAt(preferredTargets[i]);
								break;
							}
						}
					}
				}
			}

			currentStep = this.next;
			return null;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.useCenter ? "Center" : "";
		}
	}

	[ORKEditorHelp("Grid Rotate To Target", "Changes the user's orientation on the grid to look at the found target.\n" +
		"Only used in grid battles.", "")]
	[ORKNodeInfo("Position")]
	public class GridRotateToTargetStep : BaseAIStep
	{
		[ORKEditorHelp("Use Center", "Use the center position when multiple targets are available.\n" +
			"If disabled, the first available target will be used.", "")]
		public bool useCenter = false;

		public GridRotateToTargetStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, Combatant user,
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			List<Combatant> preferredTargets = this.GetPreferredTargets(user, foundTargets);

			if(preferredTargets.Count > 0)
			{
				if(this.useCenter)
				{
					BattleGridHelper.RotateToPosition(user,
						TransformHelper.GetCenterPosition(preferredTargets));
				}
				else
				{
					for(int i = 0; i < preferredTargets.Count; i++)
					{
						if(preferredTargets[i] != null &&
							preferredTargets[i].GameObject != null)
						{
							BattleGridHelper.RotateToPosition(user,
								preferredTargets[i].GameObject.transform.position);
							break;
						}
					}
				}
			}

			currentStep = this.next;
			return null;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.useCenter ? "Center" : "";
		}
	}
	[ORKEditorHelp("Get Nearest", "Adds the nearest combatant to the target list.\n" +
	   "The target list will be used by actions to determine the target.", "")]
	[ORKNodeInfo("Position")]
	public class GetNearestStep : BaseAIStep
	{
		[ORKEditorHelp("Found Targets", "Select how previously found targets will be handled:\n" +
			"- Keep: The targets will remain in the target list.\n" +
			"- Check: The targets will be checked with this step's settings.\n" +
			"- Clear: The targets will be removed from the list.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public FoundTargets foundType = FoundTargets.Keep;

		[ORKEditorHelp("Target", "Select which combatant or combatant group will be checked:\n" +
			"- Self: Checks the combatant itself.\n" +
			"- Ally: Checks the combatant's allies.\n" +
			"- Enemy: Checks the combatant's enemies.\n" +
			"- All: Checks all combatants.\n" +
			"- None: Checks no combatants, e.g. when you only want to check the found targets.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public BattleAITargetType targetType = BattleAITargetType.Ally;

		[ORKEditorHelp("Exclude Self", "Exclude the user combatant from the targets.", "")]
		[ORKEditorLayout(new string[] {"targetType", "targetType" },
			new System.Object[] {BattleAITargetType.Ally, BattleAITargetType.All },
			needed=Needed.One, endCheckGroup=true, setDefault=true, defaultValue=false)]
		public bool targetExcludeSelf = false;


		// distance
		[ORKEditorHelp("Ignore Height Distance", "Height differences to the targets are ignored when calculating the distance.\n" +
			"Depending on the 'Horizontal Plane' defined in the game settings, " +
			"this either ignores the Y-axis (XZ plane, 3D) or the Z-axis (XY plane, 2D).", "")]
		[ORKEditorInfo(separator=true, labelText="Check Distance")]
		public bool ignoreHeightDistance = false;

		[ORKEditorHelp("Ignore Radius", "The box radius settings of the combatants will be ignored when calculating the distance.", "")]
		public bool ignComRad = false;

		public GetNearestStep()
		{

		}

		public override BaseAction Execute(ref int currentStep, Combatant user,
			List<Combatant> allies, List<Combatant> enemies, List<Combatant> foundTargets)
		{
			if(FoundTargets.Clear == this.foundType)
			{
				foundTargets.Clear();
			}
			else if(FoundTargets.Check == this.foundType)
			{
				List<Combatant> tmp = new List<Combatant>(foundTargets);
				foundTargets.Clear();
				this.Check(user, tmp, foundTargets);
			}

			// check all possible targets
			this.Check(user,
				this.GetTargetList(this.targetType, this.targetExcludeSelf, user, allies, enemies),
				foundTargets);

			currentStep = this.next;
			return null;
		}

		private void Check(Combatant user, List<Combatant> list, List<Combatant> foundTargets)
		{
			Combatant nearest = TargetHelper.GetNearestTarget(user, list, Consider.Ignore);
			if(nearest != null &&
				!foundTargets.Contains(nearest))
			{
				foundTargets.Add(nearest);
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return "";
		}
	}
}
