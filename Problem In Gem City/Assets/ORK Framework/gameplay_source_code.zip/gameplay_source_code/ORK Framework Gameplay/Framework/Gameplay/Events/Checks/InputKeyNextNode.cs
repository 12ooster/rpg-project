
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.Events
{
	public class InputKeyNextNode : BaseData
	{
		[ORKEditorHelp("Input Key", "Select the input key that will be used.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int inputKeyID = 0;
		
		[ORKEditorInfo(hide=true)]
		public int next = -1;
		
		public InputKeyNextNode()
		{
			
		}
	}
}
