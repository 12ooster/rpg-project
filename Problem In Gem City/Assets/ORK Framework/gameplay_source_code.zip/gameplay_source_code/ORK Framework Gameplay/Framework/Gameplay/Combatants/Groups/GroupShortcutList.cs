
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GroupShortcutList : ISaveData
	{
		private Group group;


		// slots
		private Dictionary<int, GroupShortcutSlot> slots;

		public GroupShortcutList(Group group)
		{
			this.group = group;
			this.slots = new Dictionary<int, GroupShortcutSlot>();
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		public void RemoveCombatant(Combatant combatant)
		{
			List<int> keys = new List<int>();

			foreach(KeyValuePair<int, GroupShortcutSlot> pair in this.slots)
			{
				if(pair.Value.Owner == combatant)
				{
					keys.Add(pair.Key);
				}
			}

			for(int i = 0; i < keys.Count; i++)
			{
				this.slots.Remove(keys[i]);
			}
		}


		/*
		============================================================================
		Slot functions
		============================================================================
		*/
		public GroupShortcutSlot this[int index]
		{
			get
			{
				if(this.slots.ContainsKey(index))
				{
					return this.slots[index];
				}
				return null;
			}
			set
			{
				if(value == null)
				{
					this.slots.Remove(index);
				}
				else if(this.group.IsBattleMember(value.Owner))
				{
					if(this.slots.ContainsKey(index))
					{
						this.slots[index] = value;
					}
					else
					{
						this.slots.Add(index, value);
					}
				}
				this.group.MarkHUDUpdate();
			}
		}

		public bool HasShortcut(int index)
		{
			return this.slots.ContainsKey(index) &&
				this.slots[index] != null &&
				this.slots[index].CheckShortcut();
		}

		public bool Contains(Combatant combatant, IShortcut shortcut)
		{
			foreach(KeyValuePair<int, GroupShortcutSlot> pair in this.slots)
			{
				if(pair.Value != null &&
					pair.Value.Owner == combatant &&
					(pair.Value.Shortcut == shortcut ||
					(pair.Value.Shortcut.GetType().IsAssignableFrom(shortcut.GetType()) &&
						pair.Value.Shortcut.ID == shortcut.ID)))
				{
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();

			foreach(KeyValuePair<int, GroupShortcutSlot> pair in this.slots)
			{
				data.Set(pair.Key.ToString(), pair.Value.SaveGame());
			}

			return data;
		}

		public void LoadGame(DataObject data)
		{
			this.slots = new Dictionary<int, GroupShortcutSlot>();
			if(data != null)
			{
				Dictionary<string, DataObject> tmp = data.GetData<DataObject>(typeof(DataObject));
				if(tmp != null && tmp.Count > 0)
				{
					foreach(KeyValuePair<string, DataObject> pair in tmp)
					{
						GroupShortcutSlot shortcut = new GroupShortcutSlot(this.group, pair.Value);
						if(shortcut.Owner != null && shortcut.Shortcut != null)
						{
							this.slots.Add(int.Parse(pair.Key), shortcut);
						}
					}
				}
			}
		}
	}
}
