
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class LootTable : BaseData
	{
		// level settings
		[ORKEditorHelp("Minimum Level", "The minimum level a combatant must have to enable this loot table.", "")]
		[ORKEditorInfo(labelText="Level Range Settings")]
		[ORKEditorLimit(1, false)]
		public int minLevel = 1;

		[ORKEditorHelp("Maximum Level", "The maximum level a combatant must have to enable this loot table.", "")]
		[ORKEditorLimit("minLevel", false)]
		public int maxLevel = 99;

		[ORKEditorHelp("Use Class Level", "The combatant's class level is used to check the level range.\n" +
			"If disabled, the combatant's base level is used.", "")]
		public bool isClassLevel = false;


		// variable condition
		[ORKEditorHelp("Check Variables", "This loot table will check game variables if it will be dropped by a combatant.", "")]
		[ORKEditorInfo("Variable Condition", "If a loot table is available can depend on variable conditions.\n" +
			"Also, loot tables can change game variables after being used/dropped by a combatant.", "")]
		public bool useVarCon = false;

		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Global: Global game variables will be used.\n" +
			"- Combatant: Object variables on the combatant's game object will be used.\n" +
			"- Spawner: Object variables on the combatant's spawner game object will be used.", "")]
		[ORKEditorLayout("useVarCon", true)]
		public LootVariableOrigin varConOrigin = LootVariableOrigin.Global;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public VariableCondition variableCondition;


		// variable setter
		[ORKEditorHelp("Set Variables", "This loot table will change game variables when it's dropped by a combatant.", "")]
		[ORKEditorInfo("Set After Drop", "Loot tables can change game variables after being used/dropped by a combatant.", "")]
		public bool useVarSet = false;

		[ORKEditorHelp("Only On Drop", "Changing game variables will only happen if something is dropped by this loot table.\n" +
			"If nothing is dropped (due to 'Chance' settings), the variables wont be changed.\n" +
			"If disabled, the game variables will always be changed when this loot table is used.", "")]
		[ORKEditorLayout("useVarSet", true)]
		public bool varSetOnlyOnDrop = false;

		[ORKEditorHelp("Variable Origin", "Select the origin of the variables:\n" +
			"- Global: Global game variables will be used.\n" +
			"- Combatant: Object variables on the combatant's game object will be used.\n" +
			"- Spawner: Object variables on the combatant's spawner game object will be used.", "")]
		public LootVariableOrigin varSetOrigin = LootVariableOrigin.Global;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public VariableSetter variableSetter;


		// loot settings
		[ORKEditorHelp("Get Random", "A single, random item from the items defined in this loot table will be selected as loot (if it's chance check succeeds).\n" +
			"If disabled, all items defined in this loot table will be used as loot (still using the chance check).", "")]
		[ORKEditorInfo("Loot Settings", "Define item content of this loot table.", "")]
		public bool getRandom = false;

		[ORKEditorHelp("Money", "The amount of money added to the loot.\n" +
			"This money will always be added, also if you use 'Get Random'.", "")]
		[ORKEditorArray(ORKDataType.Currency)]
		[ORKEditorLimit(0, false)]
		public int[] money = new int[ORK.Currencies.Count];

		// item list
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorArray(false, "Add Item", "Adds an item to the loot table.", "",
			"Remove", "Removes this item from the loot table.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {"Item",
			"This item will be available as loot for a combatant using this loot setting.", ""})]
		public ItemGain[] itemDrop = new ItemGain[0];

		public LootTable()
		{

		}


		/*
		============================================================================
		Loot functions
		============================================================================
		*/
		public bool Get(ref List<IShortcut> list, Combatant combatant, bool useAddType)
		{
			if(((this.isClassLevel &&
				combatant.ClassLevel >= this.minLevel &&
				combatant.ClassLevel <= this.maxLevel) ||
				(!this.isClassLevel &&
				combatant.Level >= this.minLevel &&
				combatant.Level <= this.maxLevel)) &&
				(!this.useVarCon || this.CheckVariables(combatant)))
			{
				bool added = false;
				// add money
				for(int i = 0; i < this.money.Length; i++)
				{
					if(this.money[i] > 0)
					{
						ShortcutHelper.Add(ref list, new MoneyShortcut(i, this.money[i]), useAddType);
					}
				}
				// add items
				if(this.getRandom)
				{
					int index = Random.Range(0, this.itemDrop.Length);
					if(this.itemDrop[index].CheckChance())
					{
						added = true;
						ShortcutHelper.Add(ref list, this.itemDrop[index].CreateShortcut(), useAddType);
					}
				}
				else
				{
					for(int i = 0; i < this.itemDrop.Length; i++)
					{
						if(this.itemDrop[i].CheckChance())
						{
							added = true;
							ShortcutHelper.Add(ref list, this.itemDrop[i].CreateShortcut(), useAddType);
						}
					}
				}
				// set variables
				if(this.useVarSet &&
					(!this.varSetOnlyOnDrop || added))
				{
					this.SetVariables(combatant);
				}
				return true;
			}
			return false;
		}


		/*
		============================================================================
		Variable functions
		============================================================================
		*/
		public bool CheckVariables(Combatant combatant)
		{
			if(LootVariableOrigin.Global == this.varConOrigin)
			{
				return this.variableCondition.CheckVariables();
			}
			else if(LootVariableOrigin.Combatant == this.varConOrigin)
			{
				if(combatant.GameObject != null)
				{
					ObjectVariablesComponent comp = ComponentHelper.
						GetInChildren<ObjectVariablesComponent>(combatant.GameObject);
					if(comp != null)
					{
						return this.variableCondition.CheckVariables(comp.GetHandler());
					}
				}
			}
			else if(LootVariableOrigin.Spawner == this.varConOrigin)
			{
				if(combatant.Group.Spawner != null)
				{
					ObjectVariablesComponent comp = ComponentHelper.
						GetInChildren<ObjectVariablesComponent>(combatant.Group.Spawner.gameObject);
					if(comp != null)
					{
						return this.variableCondition.CheckVariables(comp.GetHandler());
					}
				}
			}
			return true;
		}

		public void SetVariables(Combatant combatant)
		{
			if(LootVariableOrigin.Global == this.varSetOrigin)
			{
				this.variableSetter.SetVariables();
			}
			else if(LootVariableOrigin.Combatant == this.varSetOrigin)
			{
				if(combatant.GameObject != null)
				{
					ObjectVariablesComponent comp = ComponentHelper.
						GetInChildren<ObjectVariablesComponent>(combatant.GameObject);
					if(comp != null)
					{
						this.variableSetter.SetVariables(comp.GetHandler());
					}
				}
			}
			else if(LootVariableOrigin.Spawner == this.varSetOrigin)
			{
				if(combatant.Group.Spawner != null)
				{
					ObjectVariablesComponent comp = ComponentHelper.
						GetInChildren<ObjectVariablesComponent>(combatant.Group.Spawner.gameObject);
					if(comp != null)
					{
						this.variableSetter.SetVariables(comp.GetHandler());
					}
				}
			}
		}
	}
}
