﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class AutoAnimationSetting : BaseData
	{
		[ORKEditorHelp("Minimum Fall Time (s)", "The minimum fall time in seconds to play the land animation.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float minFallTime = 0.3f;


		// run speed
		[ORKEditorHelp("Minimum Run Speed", "The minimum speed to play the run animation.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLimit(0.0f, false)]
		public float minRunSpeed = 3;

		[ORKEditorHelp("Run Speed Threshold", "The threshold is used for a smoother change between walk/run animations.\n" +
			"The run animation will be played when the combatant's speed is above 'Minimum Run Speed + threshold', " +
			"the walk animation will be played again when the speed is below 'Minimum Run Speed - threshold'.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float runSpeedThreshold = 0;


		// sprint speed
		[ORKEditorHelp("Minimum Sprint Speed", "The minimum speed to play the sprint animation.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLimit(0.0f, false)]
		public float minSprintSpeed = 6;

		[ORKEditorHelp("Sprint Speed Threshold", "The threshold is used for a smoother change between run/sprint animations.\n" +
			"The sprint animation will be played when the combatant's speed is above 'Minimum Sprint Speed + threshold', " +
			"the run animation will be played again when the speed is below 'Minimum Sprint Speed - threshold'.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float sprintSpeedThreshold = 0;


		// speed change delay
		[ORKEditorHelp("Use Speed Change Delay", "Delay animation changes when the speed change exceeds a defined value.\n" +
			"E.g. use this when a short stop (e.g. between two movement nodes) causes an unwanted animation change.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useSpeedChangeDelay = false;

		[ORKEditorHelp("Minimum Speed Change", "The minimum speed change that must happen to trigger the animation delay.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout("useSpeedChangeDelay", true)]
		public float minSpeedChange = 1;

		[ORKEditorHelp("Delay (s)", "The time in seconds the animation change will be delayed.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout(endCheckGroup=true)]
		public float speedChangeDelay = 0.1f;


		public AutoAnimationSetting()
		{

		}
	}
}
