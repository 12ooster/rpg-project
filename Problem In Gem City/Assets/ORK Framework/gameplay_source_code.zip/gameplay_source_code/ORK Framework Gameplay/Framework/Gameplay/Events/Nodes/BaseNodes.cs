
using UnityEngine;
using ORKFramework;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Wait", "Waits for a defined time.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Base")]
	public class WaitStep : BaseEventStep
	{
		[ORKEditorHelp("Random", "Wait for a random amount of time between two defined values ('Time' and 'Time 2').\n" +
			"If disabled, the step waits for the time defined in 'Time'.", "")]
		public bool random = false;

		// time
		[ORKEditorInfo(separator=true, labelText="Time (s)", label=new string[] {
			"The time in seconds to wait before executing the next step."
		})]
		public EventFloat time = new EventFloat(1);

		// time 2
		[ORKEditorInfo(separator=true, labelText="Time 2 (s)", label=new string[] {
			"The 2nd time in seconds - the wait time will be between 'Time' and 'Time 2'."
		})]
		[ORKEditorLayout("random", true, endCheckGroup=true, autoInit=true)]
		public EventFloat time2;

		public WaitStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<float>("time"))
			{
				this.time = new EventFloat();
				this.time.type = NumberValueType.Value;
				data.Get("time", ref this.time.value);

				if(this.random)
				{
					this.time2 = new EventFloat();
					this.time2.type = NumberValueType.Value;
					data.Get("time2", ref this.time2.value);
				}
			}
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.random)
			{
				baseEvent.StartTime(
					Random.Range(
						this.time.GetValue(baseEvent),
						this.time2.GetValue(baseEvent)),
					this.next);
			}
			else
			{
				baseEvent.StartTime(this.time.GetValue(baseEvent), this.next);
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.random ? this.time.GetInfoText() + " - " +
					this.time2.GetInfoText() + "s" :
				this.time.GetInfoText() + "s");
		}
	}

	[ORKEditorHelp("Check Chance", "Which step will be executed next is decided by chance.\n" +
		"The chance is checked against a random number between two values (default 0 and 100, " +
		"you can change this in the game settings). If the random number is less or equal to the " +
		"defined chance, 'Success' is executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Base", "Check/Chance")]
	public class CheckChanceStep : BaseEventCheckStep
	{
		[ORKEditorInfo(labelText="Chance")]
		public EventFloat chance = new EventFloat();

		public CheckChanceStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(ORK.GameSettings.CheckRandom(this.chance.GetValue(baseEvent)))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.chance.GetInfoText();
		}
	}

	[ORKEditorHelp("Chance Fork", "Which step will be executed next is decided by chance.\n" +
		"he chance is checked against a random number between two values (default 0 and 100, " +
		"you can change this in the game settings).\n" +
		"The next step of the first defined value range, that includes the chance, will be executed.\n" +
		"If no range contains the chance, 'Failed' will be executed.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Base", "Check/Chance")]
	public class ChanceForkStep : BaseEventStep
	{
		[ORKEditorArray(false, "Add Range", "Adds a range for the chance check.", "",
			"Remove", "Removes this range.", "", isCopy=true, isMove=true, noRemoveCount=1,
			foldout=true, foldoutText=new string[] {
				"Range", "Define the minimum and maximum value of the range.\n" +
				"If the random chance value is within the range (i.e. minimum <= chance <= maximum), " +
				"this range's next step will be executed.", ""
		})]
		public ChanceEventNextNode[] range = new ChanceEventNextNode[] {new ChanceEventNextNode()};

		public ChanceForkStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			int check = this.next;

			float chance = ORK.GameSettings.GetRandom();

			for(int i = 0; i < this.range.Length; i++)
			{
				if(this.range[i].Contains(chance, baseEvent))
				{
					check = this.range[i].next;
					break;
				}
			}

			baseEvent.StepFinished(check);
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Failed";
			}
			else if(index > 0)
			{
				return (index - 1).ToString() + ": " +
					this.range[index - 1].GetInfoText();
			}
			return "";
		}

		public override int GetNextCount()
		{
			return this.range.Length + 1;
		}

		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index > 0)
			{
				return this.range[index - 1].next;
			}
			return -1;
		}

		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index > 0)
			{
				this.range[index - 1].next = next;
			}
		}
	}

	[ORKEditorHelp("Random", "Randomly executes a next step out of a list of defined steps.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Base")]
	public class RandomStep : BaseEventStep
	{
		[ORKEditorInfo(hide=true, instanceCallback="buttons:randomstep")]
		public int[] random = new int[] {-1};

		public RandomStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			baseEvent.StepFinished(this.random[Random.Range(0, this.random.Length)]);
		}


		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			return "Random " + index;
		}

		public override int GetNextCount()
		{
			return this.random.Length;
		}

		public override int GetNext(int index)
		{
			return this.random[index];
		}

		public override void SetNext(int index, int next)
		{
			this.random[index] = next;
		}
	}

	[ORKEditorHelp("Comment", "Leave a comment in your event.\n" +
		"This step does nothing and is only for commentary purposes.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Base")]
	public class CommentStep : BaseEventStep
	{
		[ORKEditorHelp("Comment", "The comment.", "")]
		[ORKEditorInfo(isTextArea=true)]
		public string comment = "";

		public CommentStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.comment;
		}
	}

	[ORKEditorHelp("Change Time Scale", "Changes the time scale.\n" +
		"The time scale influences the speed of everything in the game - " +
		"you can use this to create slow motion effects.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Base")]
	public class ChangeTimeScaleStep : BaseEventStep
	{
		[ORKEditorHelp("Reset", "Reset the time scale to the previous value.", "")]
		public bool reset = false;

		[ORKEditorHelp("Time Scale", "The time scale that will be used.\n" +
			"E.g.:\n" +
			"- 1 is normal time.\n" +
			"- 0.5 is slows down time by halve.\n" +
			"- 2 quickens time by double.", "")]
		[ORKEditorLimit(0.0f, false)]
		[ORKEditorLayout("reset", false, endCheckGroup=true)]
		public float scale = 1;

		[ORKEditorHelp("Set ORK Scale", "Set the ORK Framework time scale - " +
			"it's used only for ORK Framework related things, like battles, events, etc.\n" +
			"If disabled, the Unity time scale will be set, affecting everything in the game.", "")]
		public bool orkScale = false;

		public ChangeTimeScaleStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.orkScale)
			{
				if(this.reset)
				{
					ORK.Game.ResetTimeScale();
				}
				else
				{
					ORK.Game.TimeScale = this.scale;
				}
			}
			else
			{
				if(this.reset)
				{
					ORK.Game.ResetUnityTimeScale();
				}
				else
				{
					ORK.Game.UnityTimeScale = this.scale;
				}
			}

			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.reset ?
				("Reset " + (this.orkScale ? "ORK " : "Unity ")) :
				((this.orkScale ? "ORK " : "Unity ") + this.scale);
		}
	}
}
