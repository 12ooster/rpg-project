﻿
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class AIRuleBlockAbility : BaseData
	{
		// abilities
		[ORKEditorHelp("Block All Abilities", "All abilities are blocked, except for the defined abilities.\n" +
			"If disabled, all abilities are allowed, except for the defined abilities.", "")]
		[ORKEditorInfo("Block Abilities", "Define abilities that will be blocked from use for the battle AI.\n" +
			"The combatant can still use the abilities (e.g. if the player manually uses them), only the AI can't use them.", "")]
		public bool blockAllAbilities = false;

		[ORKEditorHelp("Block Ability Use", "Select the ability that will be blocked from using.", "")]
		[ORKEditorInfo(ORKDataType.Ability, endFoldout=true, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Ability Block", "Adds an ability that will be blocked from using.", "",
			"Remove", "Removes the blocked ability.", "", isHorizontal=true)]
		public int[] abilityID = new int[0];


		// ability types
		[ORKEditorHelp("Block All Types", "All ability types are blocked, except for the defined types.\n" +
			"If disabled, all ability types are allowed, except for the defined types.", "")]
		[ORKEditorInfo("Block Ability Types", "Define ability types that will be blocked from use for the battle AI, " +
			"abilities of the blocked types will be blocked from use.\n" +
			"The combatant can still use the abilities (e.g. if the player manually uses them), only the AI can't use them.", "")]
		public bool blockAllAbilityTypes = false;

		[ORKEditorHelp("Block Ability Type Use", "Select the ability type that will be blocked.\n" +
			"A combatant can't use any ability of the selected type.", "")]
		[ORKEditorInfo(ORKDataType.AbilityType, endFoldout=true, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Ability Type Block", "Adds an ability type that will be blocked from using.", "",
			"Remove", "Removes the blocked ability type.", "", isHorizontal=true)]
		public int[] abilityTypeID = new int[0];

		public AIRuleBlockAbility()
		{

		}

		public bool CanUse(int abilityID)
		{
			// blocked abilities
			if(this.blockAllAbilities)
			{
				for(int i = 0; i < this.abilityID.Length; i++)
				{
					if(this.abilityID[i] == abilityID)
					{
						return true;
					}
				}
				return false;
			}
			else
			{
				for(int i = 0; i < this.abilityID.Length; i++)
				{
					if(this.abilityID[i] == abilityID)
					{
						return false;
					}
				}
			}

			// blocked ability types
			int typeID = ORK.Abilities.Get(abilityID).abilityType;
			if(this.blockAllAbilityTypes)
			{
				for(int i = 0; i < this.abilityTypeID.Length; i++)
				{
					if(this.abilityTypeID[i] == typeID)
					{
						return true;
					}
				}
				return false;
			}
			else
			{
				for(int i = 0; i < this.abilityTypeID.Length; i++)
				{
					if(this.abilityTypeID[i] == typeID)
					{
						return false;
					}
				}
			}
			return true;
		}
	}
}
