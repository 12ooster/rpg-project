﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GroupShortcuts : ISaveData
	{
		private Group owner;


		// shortcut lists
		private GroupShortcutList[] shortcutList;

		private int shortcutIndex = 0;

		public GroupShortcuts(Group owner)
		{
			this.owner = owner;
		}

		public void RemoveCombatant(Combatant combatant)
		{
			if(this.shortcutList != null)
			{
				for(int i = 0; i < this.shortcutList.Length; i++)
				{
					this.shortcutList[i].RemoveCombatant(combatant);
				}
			}
		}


		/*
		============================================================================
		Shortcut functions
		============================================================================
		*/
		private void InitLists()
		{
			if(this.shortcutList == null)
			{
				this.shortcutList = new GroupShortcutList[ORK.GameSettings.groupShortcutListCount];
				for(int i = 0; i < this.shortcutList.Length; i++)
				{
					this.shortcutList[i] = new GroupShortcutList(this.owner);
				}
			}
		}

		public GroupShortcutList Current
		{
			get
			{
				this.InitLists();
				if(this.shortcutIndex >= 0 && 
					this.shortcutIndex < this.shortcutList.Length)
				{
					return this.shortcutList[this.shortcutIndex];
				}
				else
				{
					return this.shortcutList[0];
				}
			}
		}

		public GroupShortcutList GetList(int index)
		{
			this.InitLists();
			if(index >= 0 && index < this.shortcutList.Length)
			{
				return this.shortcutList[index];
			}
			return null;
		}

		public void ChangeList(int change, bool loop)
		{
			this.InitLists();
			this.shortcutIndex += change;

			if(this.shortcutIndex < 0)
			{
				this.shortcutIndex = loop ? this.shortcutList.Length - 1 : 0;
			}
			else if(this.shortcutIndex >= this.shortcutList.Length)
			{
				this.shortcutIndex = loop ? 0 : this.shortcutList.Length - 1;
			}
			this.owner.MarkHUDUpdate();
		}

		public void SetList(int index)
		{
			this.InitLists();
			this.shortcutIndex = index;

			if(this.shortcutIndex < 0)
			{
				this.shortcutIndex = 0;
			}
			else if(this.shortcutIndex >= this.shortcutList.Length)
			{
				this.shortcutIndex = this.shortcutList.Length - 1;
			}
			this.owner.MarkHUDUpdate();
		}


		/*
		============================================================================
		Auto functions
		============================================================================
		*/
		public void AutoAdd(Combatant combatant, IShortcut shortcut)
		{
			if(this.owner == combatant.Group &&
				shortcut != null)
			{
				if(combatant.Setting.useClassShortcuts)
				{
					Class cl = ORK.Classes.Get(combatant.ClassID);
					if(!cl.replaceDefaultAutoAddSlots)
					{
						for(int i = 0; i < ORK.ShortcutSettings.autoAddShortcuts.Length; i++)
						{
							if(ORK.ShortcutSettings.autoAddShortcuts[i].AutoAddGroup(combatant, shortcut))
							{
								return;
							}
						}
					}
					for(int i = 0; i < cl.autoAddShortcuts.Length; i++)
					{
						if(cl.autoAddShortcuts[i].AutoAddGroup(combatant, shortcut))
						{
							return;
						}
					}
				}
				else
				{
					if(!combatant.Setting.replaceDefaultAutoAddSlots)
					{
						for(int i = 0; i < ORK.ShortcutSettings.autoAddShortcuts.Length; i++)
						{
							if(ORK.ShortcutSettings.autoAddShortcuts[i].AutoAddGroup(combatant, shortcut))
							{
								return;
							}
						}
					}
					for(int i = 0; i < combatant.Setting.autoAddShortcuts.Length; i++)
					{
						if(combatant.Setting.autoAddShortcuts[i].AutoAddGroup(combatant, shortcut))
						{
							return;
						}
					}
				}
			}
		}

		public void AutoArrange()
		{
			List<Combatant> list = this.owner.GetBattle();
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					if(list[i].Setting.useClassShortcuts)
					{
						Class cl = ORK.Classes.Get(list[i].ClassID);
						if(!cl.replaceDefaultAutoArrangeSlots)
						{
							for(int j = 0; j < ORK.ShortcutSettings.autoArrangeShortcuts.Length; j++)
							{
								ORK.ShortcutSettings.autoArrangeShortcuts[j].AutoArrangeGroup(list[i]);
							}
						}
						for(int j = 0; j < cl.autoArrangeShortcuts.Length; j++)
						{
							cl.autoArrangeShortcuts[j].AutoArrangeGroup(list[i]);
						}
					}
					else
					{
						if(!list[i].Setting.replaceDefaultAutoArrangeSlots)
						{
							for(int j = 0; j < ORK.ShortcutSettings.autoArrangeShortcuts.Length; j++)
							{
								ORK.ShortcutSettings.autoArrangeShortcuts[j].AutoArrangeGroup(list[i]);
							}
						}
						for(int j = 0; j < list[j].Setting.autoArrangeShortcuts.Length; j++)
						{
							list[j].Setting.autoArrangeShortcuts[j].AutoArrangeGroup(list[i]);
						}
					}
				}
			}
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();

			if(this.shortcutList != null)
			{
				DataObject[] tmp = new DataObject[this.shortcutList.Length];
				for(int i = 0; i < this.shortcutList.Length; i++)
				{
					tmp[i] = this.shortcutList[i].SaveGame();
				}
				data.Set("shortcutList", tmp);
			}

			return data;
		}

		public void LoadGame(DataObject data)
		{
			if(data != null)
			{
				DataObject[] sl = data.GetFileArray("shortcutList");
				if(sl != null)
				{
					this.shortcutList = new GroupShortcutList[ORK.GameSettings.groupShortcutListCount];
					for(int i = 0; i < this.shortcutList.Length; i++)
					{
						this.shortcutList[i] = new GroupShortcutList(this.owner);

						if(i < this.shortcutList.Length)
						{
							this.shortcutList[i].LoadGame(sl[i]);
						}
					}
				}
			}
		}
	}
}
