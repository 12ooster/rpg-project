﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.UI
{
	public class AIRulesetBattleMenuItem : BaseBattleMenuItem
	{
		[ORKEditorHelp("Add Unequip", "Add an unequip button to the AI ruleset list.", "")]
		public bool addUnequip = false;

		[ORKEditorHelp("Unequip First", "The unequip button will be displayed before the AI rulesets.\n" +
			"If disabled, the unequip button will be displayed after the AI rulesets.", "")]
		[ORKEditorLayout("addUnequip", true, endCheckGroup=true)]
		public bool unequipFirst = false;


		// AI type
		[ORKEditorHelp("Show AI Types", "Display a list of AI types to separate the available AI rulesets.\n" +
			"The AI rulesets are shown after an AI type has been selected.", "")]
		public bool showTypes = false;

		[ORKEditorHelp("Limit AI Type", "Limit the displayed AI rulesets to a defined AI type and it's sub-types.", "")]
		public bool limitAIType = false;

		[ORKEditorHelp("AI Type", "Select the AI type that will be used to limit the displayed AI rulesets.", "")]
		[ORKEditorInfo(ORKDataType.AIType)]
		[ORKEditorLayout("limitAIType", true, endCheckGroup=true)]
		public int typeID = 0;


		// sorting
		[ORKEditorInfo(separator=true, labelText="Type Sorting")]
		[ORKEditorLayout("showTypes", true, endCheckGroup=true)]
		public TypeSorter typeSorter = new TypeSorter();


		// button
		[ORKEditorArray(dataType=ORKDataType.Language, foldout=true, languageFoldout=true)]
		[ORKEditorInfo(separator=true, labelText="Button Content")]
		public LanguageInfo[] button = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count);


		// layout
		[ORKEditorInfo("Slot Content Layout", "Define the layout of the equipment part buttons.", "",
			endFoldout=true)]
		public TitleContentLayout contentLayout = new TitleContentLayout(
			ContentLayoutType.Both, ContentLayoutType.Both, ContentLayoutInfoType.None);


		// slot name
		[ORKEditorHelp("Slot Index Display", "Offset added to the index of the slot when displayed in the name ('%').\n" +
			"The first slot has the index 0, i.e. if you want to start your slot index numbers at 1, set this setting to 1.", "")]
		[ORKEditorInfo("Slot Title", "The name and icon displayed for the AI ruleset slots, " +
			"can be displayed in the title part of the choice.", "")]
		public int slotIndexDisplay = 0;

		[ORKEditorInfo(endFoldout=true, label=new string[] { "% = slot index" })]
		[ORKEditorArray(ORKDataType.Language, foldout=true, languageFoldout=true)]
		public LanguageContent[] slotContent = ArrayHelper.CreateArray<LanguageContent>(ORK.Languages.Count,
			new System.Type[] {typeof(string)}, new System.Object[] {"Slot %"});


		// empty button
		[ORKEditorInfo("Empty Button", "The empty button is displayed when an AI ruleset slot has nothing equipped.", "",
			endFoldout=true)]
		[ORKEditorArray(foldout=true, languageFoldout=true, dataType=ORKDataType.Language)]
		public LanguageInfo[] emptyPartButton = ArrayHelper.CreateArray<LanguageInfo>(ORK.Languages.Count,
			new System.Type[] {typeof(string)}, new System.Object[] {"Empty"});

		public AIRulesetBattleMenuItem()
		{

		}

		public AIRulesetBattleMenuItem(DataObject data)
		{
			this.SetData(data);
		}


		/*
		============================================================================
		Menu functions
		============================================================================
		*/
		public override bool IsType(BMItemType type)
		{
			return BMItemType.AIRuleset == type;
		}

		public override void AddToMenu(ref List<BMItem> list, Combatant owner, BattleMenu bm, BattleMenuItem parent)
		{
			list.Add(new AIRulesetSlotBMItem(bm.contentLayout.GetChoiceContent(this.button), -1, parent));
		}

		public ChoiceContent GetChoiceContent(Combatant combatant, int slotIndex)
		{
			ChoiceContent content = combatant.AI.AIRulesetSlot[slotIndex].Equipped ?
				this.contentLayout.GetChoiceContent(combatant.AI.AIRulesetSlot[slotIndex].AIRuleset, combatant) :
				this.contentLayout.GetChoiceContent(this.emptyPartButton);
			content.Title = this.contentLayout.GetTitleContent(
				this.slotContent[ORK.Game.Language].GetName().Replace("%", (slotIndex + this.slotIndexDisplay).ToString()),
				this.slotContent[ORK.Game.Language].GetIcon());

			return content;
		}
	}
}
