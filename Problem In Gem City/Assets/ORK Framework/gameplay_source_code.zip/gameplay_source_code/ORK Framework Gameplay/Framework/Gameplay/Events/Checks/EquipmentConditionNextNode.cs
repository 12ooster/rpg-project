
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Events
{
	public class EquipmentConditionNextNode : BaseData
	{
		[ORKEditorInfo(hide=true)]
		public int next = -1;

		[ORKEditorHelp("Equip", "Select how the equipment part will be checked:\n" +
			"- None: The equipment part has to be unequipped.\n" +
			"- Weapon: A weapon has to be equipped.\n" +
			"- Armor: An armor has to be equipped.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public EquipSet equip = EquipSet.None;

		[ORKEditorHelp("Equipment", "Select the equipment that will be checked for.", "")]
		[ORKEditorInfo(isPopup=true, itemFieldName="equip")]
		[ORKEditorLayout("equip", EquipSet.None, elseCheckGroup=true, endCheckGroup=true)]
		public int id = 0;

		public EquipmentConditionNextNode()
		{

		}

		public string GetInfoText()
		{
			if(EquipSet.Weapon == this.equip)
			{
				return ORK.Weapons.GetName(this.id) + " (Weapon)";
			}
			else if(EquipSet.Armor == this.equip)
			{
				return ORK.Armors.GetName(this.id) + " (Armor)";
			}
			else
			{
				return "Unequipped";
			}
		}
	}
}
