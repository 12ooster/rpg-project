
using UnityEngine;
using ORKFramework.Animations;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CombatantEquipment : ISaveData
	{
		private Combatant owner;

		private EquipPartSlot[] equipment;


		// equipment parts from items/events
		private List<int> addedParts = new List<int>();

		private List<int> blockedParts = new List<int>();

		private List<int> blockedViewers = new List<int>();


		// events
		private CombatantChanged changedHandler;
		public event CombatantChanged Changed
		{
			add { this.changedHandler += value; }
			remove { this.changedHandler -= value; }
		}

		public CombatantEquipment(Combatant owner)
		{
			this.owner = owner;

			this.equipment = new EquipPartSlot[ORK.EquipmentParts.Count];
			for(int i = 0; i < this.equipment.Length; i++)
			{
				this.equipment[i] = new EquipPartSlot();
			}
		}

		public void FireChanged()
		{
			if(this.changedHandler != null)
			{
				this.changedHandler(this.owner);
			}
			this.owner.FireChanged();
		}

		/// <summary>
		/// Checks the available equipment parts.
		/// </summary>
		public void CheckAvailableParts(bool reset)
		{
			bool[] partStatus = new bool[this.equipment.Length];

			// base class/combatant parts
			System.Array.Copy(this.Settings.equipPart, partStatus, partStatus.Length);

			// added parts
			for(int i = 0; i < this.addedParts.Count; i++)
			{
				if(this.addedParts[i] >= 0 && this.addedParts[i] < partStatus.Length)
				{
					partStatus[this.addedParts[i]] = true;
				}
			}
			// from equipment
			for(int i = 0; i < this.equipment.Length; i++)
			{
				if(this.equipment[i].Available && this.equipment[i].Equipped)
				{
					EquipmentLevel lvl = this.equipment[i].Equipment.GetEquipmentLevel();
					if(lvl != null)
					{
						for(int j = 0; j < lvl.addEquipmentPart.Length; j++)
						{
							partStatus[lvl.addEquipmentPart[j]] = true;
						}
					}
				}
			}
			// from passive abilities
			List<AbilityShortcut> passiveAbility = this.owner.Abilities.GetAbilities(UseableIn.None, IncludeCheckType.Yes);
			for(int i = 0; i < passiveAbility.Count; i++)
			{
				PassiveAbility lvl = passiveAbility[i].GetPassiveLevel();
				if(lvl != null)
				{
					for(int j = 0; j < lvl.addEquipmentPart.Length; j++)
					{
						partStatus[lvl.addEquipmentPart[j]] = true;
					}
				}
			}
			// from status effects
			for(int i = 0; i < this.owner.Status.Effects.Count; i++)
			{
				for(int j = 0; j < this.owner.Status.Effects[i].Setting.addEquipmentPart.Length; j++)
				{
					partStatus[this.owner.Status.Effects[i].Setting.addEquipmentPart[j]] = true;
				}
			}


			// blocked parts
			for(int i = 0; i < this.blockedParts.Count; i++)
			{
				if(this.blockedParts[i] >= 0 && this.blockedParts[i] < partStatus.Length)
				{
					partStatus[this.blockedParts[i]] = false;
				}
			}
			// from equipment
			for(int i = 0; i < this.equipment.Length; i++)
			{
				if(this.equipment[i].Available && this.equipment[i].Equipped)
				{
					EquipmentLevel lvl = this.equipment[i].Equipment.GetEquipmentLevel();
					if(lvl != null)
					{
						for(int j = 0; j < lvl.blockedEquipmentPart.Length; j++)
						{
							partStatus[lvl.blockedEquipmentPart[j]] = false;
						}
					}
				}
			}
			// from passive abilities
			for(int i = 0; i < passiveAbility.Count; i++)
			{
				PassiveAbility lvl = passiveAbility[i].GetPassiveLevel();
				if(lvl != null)
				{
					for(int j = 0; j < lvl.blockedEquipmentPart.Length; j++)
					{
						partStatus[lvl.blockedEquipmentPart[j]] = false;
					}
				}
			}
			// from status effects
			for(int i = 0; i < this.owner.Status.Effects.Count; i++)
			{
				for(int j = 0; j < this.owner.Status.Effects[i].Setting.blockedEquipmentPart.Length; j++)
				{
					partStatus[this.owner.Status.Effects[i].Setting.blockedEquipmentPart[j]] = false;
				}
			}

			// final check/set
			bool changed = false;
			for(int i = 0; i < this.equipment.Length; i++)
			{
				if(this.equipment[i].Available != partStatus[i])
				{
					if(!partStatus[i])
					{
						this.Unequip(i, this.owner.Inventory, false);
					}
					this.equipment[i].Available = partStatus[i];
					changed = true;
				}
			}

			if(changed)
			{
				this.FireChanged();
				if(reset)
				{
					this.owner.MarkResetStatus();
				}
			}
		}

		public void CheckViewerBlocks(bool notify)
		{
			List<int> blocked = new List<int>(this.blockedViewers);

			for(int i = 0; i < this.equipment.Length; i++)
			{
				this.equipment[i].DisplayViewer = true;

				if(this.equipment[i].Available &&
					this.equipment[i].Equipped &&
					this.equipment[i].Equipment != null)
				{
					this.equipment[i].Equipment.Setting.GetBlockedViewers(ref blocked);
				}
			}

			for(int i = 0; i < blocked.Count; i++)
			{
				this.equipment[blocked[i]].DisplayViewer = false;
			}

			if(notify && this.changedHandler != null)
			{
				this.changedHandler(this.owner);
			}
		}

		public bool CanEquip(EquipType equipType, bool[] parts)
		{
			if(EquipType.Single == equipType)
			{
				for(int i = 0; i < this.equipment.Length; i++)
				{
					if(parts[i] && this.equipment[i].Available)
					{
						return true;
					}
				}
			}
			else if(EquipType.Multi == equipType)
			{
				for(int i = 0; i < this.equipment.Length; i++)
				{
					if(parts[i] && !this.equipment[i].Available)
					{
						return false;
					}
				}
				return true;
			}
			return false;
		}

		public bool IsEquipped(EquipSet equipSet, int id, int level)
		{
			for(int i = 0; i < this.equipment.Length; i++)
			{
				if(this.equipment[i].Available &&
					this.equipment[i].Equipped &&
					this.equipment[i].Equipment != null)
				{
					if(this.equipment[i].Equipment.Type == equipSet &&
						this.equipment[i].Equipment.ID == id &&
						this.equipment[i].Equipment.Level >= level)
					{
						return true;
					}
				}
			}
			return false;
		}

		public bool IsTypeEquipped(EquipSet equipSet, int index)
		{
			for(int i = 0; i < this.equipment.Length; i++)
			{
				if(this.equipment[i].Available &&
					this.equipment[i].Equipped &&
					this.equipment[i].Equipment != null)
				{
					if(this.equipment[i].Equipment.Type == equipSet &&
						this.equipment[i].Equipment.TypeID == index)
					{
						return true;
					}
				}
			}
			return false;
		}

		/// <summary>
		/// Gets the EquipPartSlot at the specified index.
		/// This lets you access an equipment part of the combatant.
		/// </summary>
		/// <param name='index'>
		/// The ID (index) of the equipment part.
		/// </param>
		public EquipPartSlot this[int index]
		{
			get { return this.equipment[index]; }
		}

		public AvailableEquipment Settings
		{
			get
			{
				if(this.owner.Setting.ownEquipment)
				{
					return this.owner.Setting.equipment;
				}
				else
				{
					return ORK.Classes.Get(this.owner.ClassID).equipment;
				}
			}
		}


		/*
		============================================================================
		Equipment part functions
		============================================================================
		*/
		/// <summary>
		/// Gets the available equipment parts.
		/// </summary>
		/// <returns>
		/// A list of IDs (indexes) of the equipment parts.
		/// </returns>
		public List<int> GetAvailableParts()
		{
			List<int> list = new List<int>();
			for(int i = 0; i < this.equipment.Length; i++)
			{
				if(this.equipment[i].Available)
				{
					list.Add(i);
				}
			}
			return list;
		}

		public void AddEquipmentPart(int partID)
		{
			if(!this.addedParts.Contains(partID))
			{
				this.addedParts.Add(partID);
				this.CheckAvailableParts(true);
			}
		}

		public void RemoveEquipmentPart(int partID)
		{
			if(this.addedParts.Contains(partID))
			{
				this.addedParts.Remove(partID);
				this.CheckAvailableParts(true);
			}
		}

		public void AddBlockedEquipmentPart(int partID)
		{
			if(!this.blockedParts.Contains(partID))
			{
				this.blockedParts.Add(partID);
				this.CheckAvailableParts(true);
			}
		}

		public void RemoveBlockedEquipmentPart(int partID)
		{
			if(this.blockedParts.Contains(partID))
			{
				this.blockedParts.Remove(partID);
				this.CheckAvailableParts(true);
			}
		}

		public void AddBlockedViewer(int partID)
		{
			if(!this.blockedViewers.Contains(partID))
			{
				this.blockedViewers.Add(partID);
				this.CheckViewerBlocks(true);
			}
		}

		public void RemoveBlockedViewer(int partID)
		{
			if(this.blockedViewers.Contains(partID))
			{
				this.blockedViewers.Remove(partID);
				this.CheckViewerBlocks(true);
			}
		}


		/*
		============================================================================
		Status functions
		============================================================================
		*/
		public void GetStatusChanges(ref StatusPreviewInformation info)
		{
			CombatantEquipment.GetStatusChanges(this.equipment, ref info);
		}

		public static void GetStatusChanges(EquipPartSlot[] equips, ref StatusPreviewInformation info)
		{
			for(int i = 0; i < equips.Length; i++)
			{
				if(equips[i].Equipped)
				{
					equips[i].Equipment.GetBonus(ref info);
					equips[i].Equipment.GetDefenceAttributeIDs(ref info.defIDs);
				}
			}
		}

		public void SetStartEffects()
		{
			for(int i = 0; i < this.equipment.Length; i++)
			{
				if(this.equipment[i].Equipped)
				{
					this.equipment[i].Equipment.SetStartEffects(this.owner);
				}
			}
		}

		public bool CanApplyEffect(int effectID)
		{
			for(int i = 0; i < this.equipment.Length; i++)
			{
				if(this.equipment[i].Equipped &&
					!this.equipment[i].Equipment.CanApplyEffect(this.owner, effectID))
				{
					return false;
				}
			}
			return true;
		}

		public bool CanRemoveEffect(int effectID)
		{
			for(int i = 0; i < this.equipment.Length; i++)
			{
				if(this.equipment[i].Equipped &&
					!this.equipment[i].Equipment.CanRemoveEffect(this.owner, effectID))
				{
					return false;
				}
			}
			return true;
		}

		public void UseAttackEffects(Combatant target)
		{
			for(int i = 0; i < this.equipment.Length; i++)
			{
				if(this.equipment[i].Equipped && this.equipment[i].Equipment != null)
				{
					EquipmentLevel lvl = this.equipment[i].Equipment.GetEquipmentLevel();
					if(lvl != null)
					{
						lvl.autoEffects.UseAttackEffects(this.owner, target);
					}
				}
			}
		}

		public void UseDefenceEffects(Combatant target)
		{
			for(int i = 0; i < this.equipment.Length; i++)
			{
				if(this.equipment[i].Equipped && this.equipment[i].Equipment != null)
				{
					EquipmentLevel lvl = this.equipment[i].Equipment.GetEquipmentLevel();
					if(lvl != null)
					{
						lvl.autoEffects.UseDefenceEffects(this.owner, target);
					}
				}
			}
		}


		/*
		============================================================================
		Animation functions
		============================================================================
		*/
		public void GetAnimationSettings(ref List<AnimationSetting> list)
		{
			for(int i = 0; i < this.equipment.Length; i++)
			{
				if(this.equipment[i].Equipped &&
					this.equipment[i].Equipment.Setting is Weapon)
				{
					Weapon weapon = this.equipment[i].Equipment.Setting as Weapon;
					if(this.owner.Battle.InBattle && weapon.ownAnimsBattle)
					{
						list.Add(ORK.Animations.Get(weapon.animationBattleID));
					}
					if(weapon.ownAnims)
					{
						list.Add(ORK.Animations.Get(weapon.animationID));
					}
				}
			}
		}


		/*
		============================================================================
		Equipment functions
		============================================================================
		*/
		public bool Equip(int partID, EquipShortcut equip, Inventory inventory, bool keepUnequipped, bool reset)
		{
			bool equipped = false;

			// get equipment
			if(equip != null && !equip.IsType(EquipSet.None) && equip.CanEquip(this.owner) &&
				equip.Setting.CheckLockedParts(partID, this.owner))
			{
				// check partID
				if(partID == -1)
				{
					// check for free part
					for(int i = 0; i < equip.Setting.equipPart.Length; i++)
					{
						if(equip.Setting.equipPart[i] &&
							this.equipment[i].Available &&
							!this.equipment[i].Equipped)
						{
							partID = i;
							break;
						}
					}
					// check for matching part if no free part available
					if(partID == -1)
					{
						for(int i = 0; i < equip.Setting.equipPart.Length; i++)
						{
							if(equip.Setting.equipPart[i] &&
								this.equipment[i].Available)
							{
								partID = i;
								break;
							}
						}
					}
				}

				if(partID >= 0 && partID <= equip.Setting.equipPart.Length &&
					equip.Setting.equipPart[partID] && this.equipment[partID].Available &&
					!this.IsPartLocked(partID))
				{
					equipped = true;

					this.Unequip(partID, keepUnequipped ? inventory : null, false, true);
					if(inventory != null)
					{
						inventory.Remove(equip, 1, false, false);
					}
					this.equipment[partID].Equipment = equip.GetCopy(1) as EquipShortcut;
					this.equipment[partID].Equipment.InitDurability(this.owner);

					if(this.equipment[partID].Equipment.Setting.IsMulti())
					{
						for(int i = 0; i < this.equipment[partID].Equipment.Setting.equipPart.Length; i++)
						{
							if(i != partID && this.equipment[partID].Equipment.Setting.equipPart[i])
							{
								this.Unequip(i, keepUnequipped ? inventory : null, false, true);
								this.equipment[i].LinkedTo(partID);
							}
						}
					}

					for(int i = 0; i < this.equipment[partID].Equipment.Setting.blockPart.Length; i++)
					{
						if(this.equipment[partID].Equipment.Setting.blockPart[i])
						{
							this.Unequip(i, keepUnequipped ? inventory : null, false, true);
							this.equipment[i].BlockBy(partID);
						}
					}
					this.equipment[partID].Equipment.RegisterStatusChanges(this.owner);
					this.equipment[partID].Equipment.SetStartEffects(this.owner);

					this.CheckViewerBlocks(false);
					this.FireChanged();
				}
			}

			if(reset)
			{
				this.owner.MarkResetStatus();
			}

			return equipped;
		}

		public void UnequipAll(Inventory inventory)
		{
			for(int i = 0; i < this.equipment.Length; i++)
			{
				this.Unequip(i, inventory, i == this.equipment.Length - 1);
			}
		}

		public void Unequip(EquipShortcut equip, Inventory inventory)
		{
			for(int i = 0; i < this.equipment.Length; i++)
			{
				if(this.equipment[i].Equipment == equip)
				{
					this.Unequip(i, inventory, true, false);
					break;
				}
			}
		}

		public void Unequip(int partID, Inventory inventory, bool reset)
		{
			this.Unequip(partID, inventory, reset, false);
		}

		public void Unequip(int partID, Inventory inventory, bool reset, bool force)
		{
			// get blocking partID if blocked
			this.equipment[partID].GetRealPartID(ref partID);

			if(this.equipment[partID].Equipped &&
				this.equipment[partID].Equipment.Setting.CheckLockedParts(partID, this.owner) &&
				(force || this.equipment[partID].Equipment.Setting.CheckAllowUnequip(partID)))
			{
				EquipShortcut equip = this.equipment[partID].Equipment;

				if(equip.Setting.IsSingle())
				{
					this.equipment[partID].Equipment = null;
				}
				else if(equip.Setting.IsMulti())
				{
					for(int i = 0; i < equip.Setting.equipPart.Length; i++)
					{
						if(equip.Setting.equipPart[i])
						{
							this.equipment[i].Equipment = null;
						}
					}
				}
				for(int i = 0; i < equip.Setting.blockPart.Length; i++)
				{
					if(equip.Setting.blockPart[i])
					{
						this.equipment[i].Equipment = null;
					}
				}

				equip.UnregisterStatusChanges(this.owner);
				equip.RemoveStartEffects(this.owner);
				if(inventory != null &&
					!equip.Setting.oneTimeEquip)
				{
					inventory.Add(equip, false, false);
				}

				this.CheckViewerBlocks(false);
				if(this.changedHandler != null)
				{
					this.changedHandler(this.owner);
				}
			}
			if(reset)
			{
				this.owner.MarkResetStatus();
				this.owner.CheckSpawnedPrefab();
			}
		}

		public EquipPartSlot[] GetFakeEquip(int partID, EquipShortcut equip)
		{
			EquipPartSlot[] list = new EquipPartSlot[this.equipment.Length];
			for(int i = 0; i < list.Length; i++)
			{
				list[i] = this.equipment[i].GetCopy();
			}

			if(equip != null && !equip.IsType(EquipSet.None) && equip.CanEquip(this.owner) &&
				equip.Setting.CheckLockedParts(partID, this.owner))
			{
				// check partID, if -1 get first partID that matches
				if(partID == -1)
				{
					for(int i = 0; i < equip.Setting.equipPart.Length; i++)
					{
						if(equip.Setting.equipPart[i] && this.equipment[i].Available)
						{
							partID = i;
							break;
						}
					}
				}

				if(partID >= 0 && partID <= equip.Setting.equipPart.Length &&
					equip.Setting.equipPart[partID] && this.equipment[partID].Available &&
					!this.IsPartLocked(partID))
				{
					// unequip old
					list[partID].GetRealPartID(ref partID);

					if(list[partID].Equipped)
					{
						EquipShortcut unequip = list[partID].Equipment;
						if(unequip.Setting.IsSingle())
						{
							list[partID].Equipment = null;
						}
						else if(unequip.Setting.IsMulti())
						{
							for(int i = 0; i < unequip.Setting.equipPart.Length; i++)
							{
								if(unequip.Setting.equipPart[i])
								{
									list[i].Equipment = null;
								}
							}
						}
						for(int i = 0; i < unequip.Setting.blockPart.Length; i++)
						{
							if(unequip.Setting.blockPart[i])
							{
								list[i].Equipment = null;
							}
						}
					}

					// equip new
					list[partID].Equipment = equip;
					if(equip.Setting.IsMulti())
					{
						for(int i = 0; i < equip.Setting.equipPart.Length; i++)
						{
							if(i != partID && equip.Setting.equipPart[i])
							{
								list[i].LinkedTo(partID);
							}
						}
					}
					for(int i = 0; i < equip.Setting.blockPart.Length; i++)
					{
						if(equip.Setting.blockPart[i])
						{
							list[i].BlockBy(partID);
						}
					}
				}
			}
			else if(equip != null && equip.IsType(EquipSet.None))
			{
				if(partID == -1)
				{
					for(int i = 0; i < this.equipment.Length; i++)
					{
						if(this.equipment[i].Available)
						{
							partID = i;
							break;
						}
					}
				}

				if(partID >= 0 && partID <= this.equipment.Length &&
					this.equipment[partID].Available && !this.IsPartLocked(partID))
				{
					// unequip old
					list[partID].GetRealPartID(ref partID);

					if(list[partID].Equipped)
					{
						EquipShortcut unequip = list[partID].Equipment;
						if(unequip.Setting.IsSingle())
						{
							list[partID].Equipment = null;
						}
						else if(unequip.Setting.IsMulti())
						{
							for(int i = 0; i < unequip.Setting.equipPart.Length; i++)
							{
								if(unequip.Setting.equipPart[i])
								{
									list[i].Equipment = null;
								}
							}
						}
						for(int i = 0; i < unequip.Setting.blockPart.Length; i++)
						{
							if(unequip.Setting.blockPart[i])
							{
								list[i].Equipment = null;
							}
						}
					}
				}
			}
			return list;
		}


		/*
		============================================================================
		Lock part functions
		============================================================================
		*/
		public void LockAll(bool lockParts)
		{
			for(int i = 0; i < this.equipment.Length; i++)
			{
				this.equipment[i].Locked = lockParts;
			}
		}

		public bool IsPartLocked(int partID)
		{
			if(partID >= 0 && partID < this.equipment.Length)
			{
				this.equipment[partID].GetRealPartID(ref partID);
				return this.equipment[partID].Locked;
			}
			return false;
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();

			DataObject[] tmp = new DataObject[this.equipment.Length];
			for(int i = 0; i < tmp.Length; i++)
			{
				tmp[i] = this.equipment[i].SaveGame();
			}
			data.Set("equipment", tmp);

			// extra parts
			data.Set("addedParts", this.addedParts.ToArray());
			data.Set("blockedParts", this.blockedParts.ToArray());
			data.Set("blockedViewers", this.blockedViewers.ToArray());

			return data;
		}

		public void LoadGame(DataObject data)
		{
			this.addedParts = new List<int>();
			this.blockedParts = new List<int>();
			this.blockedViewers = new List<int>();

			if(data != null)
			{
				DataObject[] tmp = data.GetFileArray("equipment");
				if(tmp != null)
				{
					for(int i = 0; i < this.equipment.Length; i++)
					{
						if(i < tmp.Length)
						{
							this.equipment[i].LoadGame(tmp[i]);
							if(this.equipment[i].Equipped)
							{
								this.equipment[i].Equipment.RegisterStatusChanges(this.owner);
							}
						}
					}
				}

				// extra parts
				int[] tmp2 = null;
				data.Get("addedParts", out tmp2);
				if(tmp2 != null)
				{
					this.addedParts.AddRange(tmp2);
				}
				tmp2 = null;
				data.Get("blockedParts", out tmp2);
				if(tmp2 != null)
				{
					this.blockedParts.AddRange(tmp2);
				}
				tmp2 = null;
				data.Get("blockedViewers", out tmp2);
				if(tmp2 != null)
				{
					this.blockedViewers.AddRange(tmp2);
				}
			}
		}
	}
}
