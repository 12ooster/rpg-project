
using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class Vector3Value : BaseData
	{
		[ORKEditorHelp("Value Type", "Select where the Vector3 value comes from:\n" +
			"- Value: A defined value.\n" +
			"- Game Variable: The value of a game variable (Vector3).\n" +
			"- Scene Position: The scene position of the current scene (or if not set: 0, 0, 0).\n" +
			"- Player Position: The current position of the player.\n" +
			"- Random: A randomly generated value between defined min/max values for each axis.", "")]
		public Vector3ValueType type = Vector3ValueType.Value;


		// value
		[ORKEditorHelp("Value", "The Vector3 value that will be used.", "")]
		[ORKEditorLayout("type", Vector3ValueType.Value, endCheckGroup=true)]
		public Vector3 value = Vector3.zero;


		// variable
		[ORKEditorHelp("Variable Key (Vector3)", "The key (name) of the game variable (Vector3) that contains the value.", "")]
		[ORKEditorInfo(expandWidth=true, isVariableField=true)]
		[ORKEditorLayout("type", Vector3ValueType.GameVariable, endCheckGroup=true, setDefault=true, defaultValue="")]
		public string variableKey = "";


		// random
		[ORKEditorHelp("X Minimum", "The minimum random value on the X-axis.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", Vector3ValueType.Random)]
		public float xMin = 0;

		[ORKEditorHelp("X Maximum", "The maximum random value on the X-axis.", "")]
		public float xMax = 0;

		[ORKEditorHelp("Y Minimum", "The minimum random value on the Y-axis.", "")]
		[ORKEditorInfo(separator=true)]
		public float yMin = 0;

		[ORKEditorHelp("Y Maximum", "The maximum random value on the Y-axis.", "")]
		public float yMax = 0;

		[ORKEditorHelp("Z Minimum", "The minimum random value on the Z-axis.", "")]
		[ORKEditorInfo(separator=true)]
		public float zMin = 0;

		[ORKEditorHelp("Z Maximum", "The maximum random value on the Z-axis.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public float zMax = 0;

		public Vector3Value()
		{

		}

		public Vector3Value(Vector3 value)
		{
			this.value = value;
		}

		public Vector3 GetValue()
		{
			if(Vector3ValueType.Value == this.type)
			{
				return this.value;
			}
			else if(Vector3ValueType.GameVariable == this.type)
			{
				return ORK.Game.Variables.GetVector3(this.variableKey);
			}
			else if(Vector3ValueType.ScenePosition == this.type)
			{
				SceneTarget st = ORK.Game.Scene.GetScenePosition(SceneManager.GetActiveScene().name);
				if(st != null)
				{
					return st.position;
				}
			}
			else if(Vector3ValueType.PlayerPosition == this.type)
			{
				if(ORK.Game.GetPlayer() != null)
				{
					return ORK.Game.GetPlayer().transform.position;
				}
			}
			else if(Vector3ValueType.Random == this.type)
			{
				return new Vector3(
					Random.Range(this.xMin, this.xMax),
					Random.Range(this.yMin, this.yMax),
					Random.Range(this.zMin, this.zMax));
			}
			return Vector3.zero;
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public string GetInfoText()
		{
			if(Vector3ValueType.Value == this.type)
			{
				return this.value.ToString();
			}
			else if(Vector3ValueType.GameVariable == this.type)
			{
				return this.variableKey;
			}
			else if(Vector3ValueType.Random == this.type)
			{
				return "(" + this.xMin + "~" + this.xMax + ", " +
					this.yMin + "~" + this.yMax + ", " +
					this.zMin + "~" + this.zMax + ")";
			}
			return this.type.ToString();
		}
	}
}
