
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	[System.Serializable]
	public class SimpleCheckGameVariable : CheckVariableBase
	{
		[ORKEditorInfo(labelText="Variable Key")]
		public StringValue key = new StringValue();
		
		public SimpleCheckGameVariable()
		{
			
		}
		
		public bool Check(VariableHandler handler)
		{
			return base.Check(this.key.GetValue(), handler);
		}
	}
}
