﻿
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class CombatantAI : ISaveData, IStatusChanged
	{
		private Combatant owner;


		// slots
		private AIBehaviourSlot[] aiBehaviourSlot = new AIBehaviourSlot[0];

		private AIRulesetSlot[] aiRulesetSlot = new AIRulesetSlot[0];


		// AI state
		private bool aiControlled = false;

		private bool blocked = false;


		// real time battles
		private Combatant realTimeCounterTarget;

		private float realTimeTimeout = 0;


		// events
		private CombatantChanged changedHandler;
		public event CombatantChanged Changed
		{
			add { this.changedHandler += value; }
			remove { this.changedHandler -= value; }
		}

		public CombatantAI(Combatant owner)
		{
			this.owner = owner;
			this.aiControlled = this.owner.Setting.aiControlled;
			this.blocked = this.owner.Setting.aiStartBlocked;
		}

		public void Init()
		{
			// AI behaviour slots
			this.aiBehaviourSlot = new AIBehaviourSlot[this.owner.Setting.aiBehaviourSlot.Length];
			for(int i = 0; i < this.owner.Setting.aiBehaviourSlot.Length; i++)
			{
				this.aiBehaviourSlot[i] = new AIBehaviourSlot();
				this.owner.Setting.aiBehaviourSlot[i].Use(this.owner, i, false);
			}

			// AI ruleset slots
			this.aiRulesetSlot = new AIRulesetSlot[this.owner.Setting.aiRulesetSlot.Length];
			for(int i = 0; i < this.owner.Setting.aiRulesetSlot.Length; i++)
			{
				this.aiRulesetSlot[i] = new AI.AIRulesetSlot();
				this.owner.Setting.aiRulesetSlot[i].Use(this.owner, i, false);
			}

			this.CheckSlots();
		}

		public void Clear()
		{
			this.realTimeCounterTarget = null;
			this.realTimeTimeout = this.owner.Setting.aiTimeout;
		}


		/*
		============================================================================
		Tool functions
		============================================================================
		*/
		/// <summary>
		/// Gets or sets whether the combatant is AI controlled (only for the player group).
		/// </summary>
		/// <value>
		/// <c>true</c> if AI controlled; otherwise, <c>false</c>.
		/// </value>
		public bool AIControlled
		{
			get { return this.aiControlled; }
			set { this.aiControlled = value; }
		}

		/// <summary>
		/// Gets or sets whether the combatant's battle AI is blocked.
		/// </summary>
		/// <value>
		/// <c>true</c> if blocked; otherwise, <c>false</c>.
		/// </value>
		public bool Blocked
		{
			get { return this.blocked; }
			set { this.blocked = value; }
		}

		/// <summary>
		/// Gets or sets the timeout between two AI actions in real time battles.
		/// </summary>
		/// <value>
		/// The timeout that will be used.
		/// </value>
		public float RealTimeTimeout
		{
			get { return this.realTimeTimeout; }
			set { this.realTimeTimeout = value; }
		}

		/// <summary>
		/// Sets a combatant to be the target of a counter attack in 'Real Time' battles.
		/// </summary>
		/// <value>
		/// The combatant that will be used as target.
		/// </value>
		public Combatant RealTimeCounterTarget
		{
			get { return this.realTimeCounterTarget; }
			set { this.realTimeCounterTarget = value; }
		}

		public bool IsAITypeEquipped(int aiTypeID, bool checkParent)
		{
			List<int> types = new List<int>();
			// AI behaviours
			for(int i = 0; i < this.aiBehaviourSlot.Length; i++)
			{
				if(this.aiBehaviourSlot[i].Equipped)
				{
					if(aiTypeID == -1 ||
						this.aiBehaviourSlot[i].AIBehaviour.TypeID == aiTypeID)
					{
						return true;
					}
					else if(checkParent)
					{
						if(!types.Contains(this.aiBehaviourSlot[i].AIBehaviour.TypeID))
						{
							if(ORK.AITypes.Get(this.aiBehaviourSlot[i].AIBehaviour.TypeID).IsSubTypeOf(aiTypeID))
							{
								return true;
							}
							else
							{
								types.Add(this.aiBehaviourSlot[i].AIBehaviour.TypeID);
							}
						}
					}
				}
			}
			// AI rulesets
			for(int i = 0; i < this.aiRulesetSlot.Length; i++)
			{
				if(this.aiRulesetSlot[i].Equipped)
				{
					if(aiTypeID == -1 ||
						this.aiRulesetSlot[i].AIRuleset.TypeID == aiTypeID)
					{
						return true;
					}
					else if(checkParent)
					{
						if(!types.Contains(this.aiRulesetSlot[i].AIRuleset.TypeID))
						{
							if(ORK.AITypes.Get(this.aiRulesetSlot[i].AIRuleset.TypeID).IsSubTypeOf(aiTypeID))
							{
								return true;
							}
							else
							{
								types.Add(this.aiRulesetSlot[i].AIRuleset.TypeID);
							}
						}
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Notification functions
		============================================================================
		*/
		public void FireChanged()
		{
			if(this.changedHandler != null)
			{
				this.changedHandler(this.owner);
			}
		}

		public void CheckSlots()
		{
			bool changed = false;
			// AI behaviours
			for(int i = 0; i < this.aiBehaviourSlot.Length; i++)
			{
				if(this.aiBehaviourSlot[i].Equipped)
				{
					if(this.aiBehaviourSlot[i].AIBehaviour.Setting.useEquipRequirements &&
						this.aiBehaviourSlot[i].AIBehaviour.Setting.autoUnequip &&
						!this.aiBehaviourSlot[i].AIBehaviour.Setting.CanEquip(this.owner))
					{
						this.UnequipAIBehaviour(i, true, false);
						changed = true;
					}
				}
			}
			// AI rulesets
			for(int i = 0; i < this.aiRulesetSlot.Length; i++)
			{
				if(this.aiRulesetSlot[i].Equipped)
				{
					if(this.aiRulesetSlot[i].AIRuleset.Setting.useEquipRequirements &&
						this.aiRulesetSlot[i].AIRuleset.Setting.autoUnequip &&
						!this.aiRulesetSlot[i].AIRuleset.Setting.CanEquip(this.owner))
					{
						this.UnequipAIRuleset(i, true, false);
						changed = true;
					}
				}
			}

			if(changed)
			{
				this.FireChanged();
			}
		}

		public void AttackAttributeChanged(Combatant c, int id, int id2, float change)
		{
			this.CheckSlots();
		}

		public void DefenceAttributeChanged(Combatant c, int id, int id2, float change)
		{
			this.CheckSlots();
		}

		public void DefenceAttributeIDChanged(Combatant c, int id, int id2)
		{
			this.CheckSlots();
		}

		public void StatusValueChanged(Combatant c, int id, int change)
		{
			this.CheckSlots();
		}

		public void StatusEffectChanged(Combatant c, int id)
		{
			this.CheckSlots();
		}

		public void LevelChanged(Combatant c, int id)
		{
			this.CheckSlots();
		}

		public void ClassLevelChanged(Combatant c, int id)
		{
			this.CheckSlots();
		}

		public void ClassChanged(Combatant c, int id)
		{
			this.CheckSlots();
		}

		public void AbilitiesChanged(Combatant c)
		{
			this.CheckSlots();
		}

		public void EquipmentChanged(Combatant c)
		{
			this.CheckSlots();
		}

		public void CombatantGroupChanged(Combatant combatant)
		{
			this.CheckSlots();
		}

		public void CombatantInventoryChanged(Combatant combatant)
		{
			this.CheckSlots();
		}

		public void CombatantBattleStateChanged(Combatant combatant)
		{
			this.CheckSlots();
		}

		public void CombatantActionStateChanged(Combatant combatant)
		{
			this.CheckSlots();
		}

		public void CombatantCastingStateChanged(Combatant combatant)
		{
			this.CheckSlots();
		}

		public void CombatantChoosingStateChanged(Combatant combatant)
		{
			this.CheckSlots();
		}

		public void CombatantTurnEndedStateChanged(Combatant combatant)
		{
			this.CheckSlots();
		}

		public void CombatantGridMoveRangeChanged(Combatant combatant)
		{
			this.CheckSlots();
		}

		public void CombatantResearchChanged(Combatant combatant)
		{
			this.CheckSlots();
		}

		public void CombatantAIChanged(Combatant combatant)
		{
			this.CheckSlots();
		}


		/*
		============================================================================
		AI behaviour functions
		============================================================================
		*/
		public AIBehaviourSlot[] AIBehaviourSlot
		{
			get { return this.aiBehaviourSlot; }
		}

		public void AddAIBehaviourSlots(AIBehaviourSlotSetting[] slot)
		{
			if(slot.Length > 0)
			{
				AIBehaviourSlot[] tmp = this.aiBehaviourSlot;
				this.aiBehaviourSlot = new AIBehaviourSlot[tmp.Length + slot.Length];

				for(int i = 0; i < this.aiBehaviourSlot.Length; i++)
				{
					// old slot
					if(i < tmp.Length)
					{
						this.aiBehaviourSlot[i] = tmp[i];
					}
					// new slot
					else
					{
						this.aiBehaviourSlot[i] = new AIBehaviourSlot();
						slot[i - tmp.Length].Use(this.owner, i, false);
					}
				}

				this.CheckSlots();
				this.FireChanged();
			}
		}

		public void RemoveAIBehaviourSlot(int slotIndex, bool collect)
		{
			if(slotIndex == -1)
			{
				slotIndex = this.aiBehaviourSlot.Length - 1;
			}
			if(slotIndex >= 0 &&
				slotIndex < this.aiBehaviourSlot.Length)
			{
				if(this.aiBehaviourSlot[slotIndex].Equipped)
				{
					this.UnequipAIBehaviour(slotIndex, collect, false);
				}
				ArrayHelper.RemoveAt(ref this.aiBehaviourSlot, slotIndex);
			}
			this.FireChanged();
		}

		public void RemoveAllAIBehaviourSlots(bool collect)
		{
			for(int i = 0; i < this.aiBehaviourSlot.Length; i++)
			{
				if(this.aiBehaviourSlot[i].Equipped)
				{
					this.UnequipAIBehaviour(i, collect, false);
				}
			}
			this.aiBehaviourSlot = new AIBehaviourSlot[0];
			this.FireChanged();
		}

		public bool IsAIBehaviourEquipped(int aiBehaviourID)
		{
			if(aiBehaviourID >= 0)
			{
				for(int i = 0; i < this.aiBehaviourSlot.Length; i++)
				{
					if(this.aiBehaviourSlot[i].Equipped &&
						this.aiBehaviourSlot[i].AIBehaviour.ID == aiBehaviourID)
					{
						return true;
					}
				}
			}
			return false;
		}

		public void EquipAIBehaviour(int aiBehaviourID, int slotIndex, bool collect, bool fromCollection, bool notify)
		{
			// get first free slot
			if(slotIndex == -1)
			{
				for(int i = 0; i < this.aiBehaviourSlot.Length; i++)
				{
					if(!this.aiBehaviourSlot[i].Equipped)
					{
						slotIndex = i;
						break;
					}
				}
			}
			// equip
			if(slotIndex >= 0 &&
				slotIndex < this.aiBehaviourSlot.Length &&
				ORK.AIBehaviours.Get(aiBehaviourID).CanEquip(this.owner))
			{
				if(this.owner.IsPlayerControlled())
				{
					// collect current
					if(this.aiBehaviourSlot[slotIndex].Equipped)
					{
						this.UnequipAIBehaviour(slotIndex, true, false);
					}

					// equip new
					if(!fromCollection ||
						this.owner.Inventory.AICollection.GetEquipAIBehaviour(aiBehaviourID))
					{
						this.aiBehaviourSlot[slotIndex].AIBehaviour = new AIBehaviourShortcut(aiBehaviourID, 1);
					}
				}
				else
				{
					this.aiBehaviourSlot[slotIndex].AIBehaviour = new AIBehaviourShortcut(aiBehaviourID, 1);
				}

				if(this.aiBehaviourSlot[slotIndex].Equipped)
				{
					if(this.aiBehaviourSlot[slotIndex].AIBehaviour.Setting.useEquipRequirements &&
						this.aiBehaviourSlot[slotIndex].AIBehaviour.Setting.autoUnequip)
					{
						this.aiBehaviourSlot[slotIndex].AIBehaviour.Setting.equipRequirement.
							RegisterChanges(this.owner, this, this.CheckSlots);
					}
				}

				if(notify)
				{
					this.FireChanged();
				}
			}
		}

		public void UnequipAIBehaviourID(int aiBehaviourID, bool collect, bool notify)
		{
			for(int i = 0; i < this.aiBehaviourSlot.Length; i++)
			{
				if(this.aiBehaviourSlot[i].Equipped &&
					this.aiBehaviourSlot[i].AIBehaviour.ID == aiBehaviourID)
				{
					this.UnequipAIBehaviour(i, collect, notify);
					break;
				}
			}
		}

		public void UnequipAIBehaviour(int slotIndex, bool collect, bool notify)
		{
			// get first equipped slot
			if(slotIndex == -1)
			{
				for(int i = 0; i < this.aiBehaviourSlot.Length; i++)
				{
					if(this.aiBehaviourSlot[i].Equipped)
					{
						slotIndex = i;
						break;
					}
				}
			}
			// unequip
			if(slotIndex >= 0 &&
				slotIndex < this.aiBehaviourSlot.Length &&
				this.aiBehaviourSlot[slotIndex].Equipped)
			{
				// player collect
				if(collect &&
					this.owner.IsPlayerControlled())
				{
					this.owner.Inventory.AICollection.AddAIBehaviour(this.aiBehaviourSlot[slotIndex].AIBehaviour.ID, 1, false, false);
				}

				// unregister auto unequip
				if(this.aiBehaviourSlot[slotIndex].AIBehaviour.Setting.useEquipRequirements &&
					this.aiBehaviourSlot[slotIndex].AIBehaviour.Setting.autoUnequip)
				{
					this.aiBehaviourSlot[slotIndex].AIBehaviour.Setting.equipRequirement.
						UnregisterChanges(this.owner, this, this.CheckSlots);
				}

				this.aiBehaviourSlot[slotIndex].AIBehaviour = null;

				if(notify)
				{
					this.FireChanged();
				}
			}
		}


		/*
		============================================================================
		AI ruleset functions
		============================================================================
		*/
		public AIRulesetSlot[] AIRulesetSlot
		{
			get { return this.aiRulesetSlot; }
		}

		public void AddAIRulesetSlots(AIRulesetSlotSetting[] slot)
		{
			if(slot.Length > 0)
			{
				AIRulesetSlot[] tmp = this.aiRulesetSlot;
				this.aiRulesetSlot = new AIRulesetSlot[tmp.Length + slot.Length];

				for(int i = 0; i < this.aiRulesetSlot.Length; i++)
				{
					// old slot
					if(i < tmp.Length)
					{
						this.aiRulesetSlot[i] = tmp[i];
					}
					// new slot
					else
					{
						this.aiRulesetSlot[i] = new AI.AIRulesetSlot();
						slot[i - tmp.Length].Use(this.owner, i, false);
					}
				}

				this.CheckSlots();
				this.FireChanged();
			}
		}

		public void RemoveAIRulesetSlot(int slotIndex, bool collect)
		{
			if(slotIndex == -1)
			{
				slotIndex = this.aiRulesetSlot.Length - 1;
			}
			if(slotIndex >= 0 &&
				slotIndex < this.aiRulesetSlot.Length)
			{
				if(this.aiRulesetSlot[slotIndex].Equipped)
				{
					this.UnequipAIRuleset(slotIndex, collect, false);
				}
				ArrayHelper.RemoveAt(ref this.aiRulesetSlot, slotIndex);
			}
			this.FireChanged();
		}

		public void RemoveAllAIRulesetSlots(bool collect)
		{
			for(int i = 0; i < this.aiRulesetSlot.Length; i++)
			{
				if(this.aiRulesetSlot[i].Equipped)
				{
					this.UnequipAIRuleset(i, collect, false);
				}
			}
			this.aiRulesetSlot = new AI.AIRulesetSlot[0];
			this.FireChanged();
		}

		public bool IsAIRulesetEquipped(int aiRulesetID)
		{
			if(aiRulesetID >= 0)
			{
				for(int i = 0; i < this.aiRulesetSlot.Length; i++)
				{
					if(this.aiRulesetSlot[i].Equipped &&
						this.aiRulesetSlot[i].AIRuleset.ID == aiRulesetID)
					{
						return true;
					}
				}
			}
			return false;
		}

		public void EquipAIRuleset(int aiRulesetID, int slotIndex, bool collect, bool fromCollection, bool notify)
		{
			// get first free slot
			if(slotIndex == -1)
			{
				for(int i = 0; i < this.aiRulesetSlot.Length; i++)
				{
					if(!this.aiRulesetSlot[i].Equipped)
					{
						slotIndex = i;
						break;
					}
				}
			}
			// equip
			if(slotIndex >= 0 &&
				slotIndex < this.aiRulesetSlot.Length &&
				ORK.AIRulesets.Get(aiRulesetID).CanEquip(this.owner))
			{
				if(this.owner.IsPlayerControlled())
				{
					// collect current
					if(collect &&
						this.aiRulesetSlot[slotIndex].Equipped)
					{
						this.UnequipAIRuleset(slotIndex, collect, false);
					}

					// equip new
					if(!fromCollection ||
						this.owner.Inventory.AICollection.GetEquipAIRuleset(aiRulesetID))
					{
						this.aiRulesetSlot[slotIndex].AIRuleset = new AIRulesetShortcut(aiRulesetID, 1);
					}
				}
				else
				{
					this.aiRulesetSlot[slotIndex].AIRuleset = new AIRulesetShortcut(aiRulesetID, 1);
				}

				if(this.aiRulesetSlot[slotIndex].Equipped)
				{
					if(this.aiRulesetSlot[slotIndex].AIRuleset.Setting.useEquipRequirements &&
						this.aiRulesetSlot[slotIndex].AIRuleset.Setting.autoUnequip)
					{
						this.aiRulesetSlot[slotIndex].AIRuleset.Setting.equipRequirement.
							RegisterChanges(this.owner, this, this.CheckSlots);
					}
				}

				if(notify)
				{
					this.FireChanged();
				}
			}
		}

		public void UnequipAIRulesetID(int aiRulesetID, bool collect, bool notify)
		{
			for(int i = 0; i < this.aiRulesetSlot.Length; i++)
			{
				if(this.aiRulesetSlot[i].Equipped &&
					this.aiRulesetSlot[i].AIRuleset.ID == aiRulesetID)
				{
					this.UnequipAIRuleset(i, collect, notify);
					break;
				}
			}
		}

		public void UnequipAIRuleset(int slotIndex, bool collect, bool notify)
		{
			// get first equipped slot
			if(slotIndex == -1)
			{
				for(int i = 0; i < this.aiRulesetSlot.Length; i++)
				{
					if(this.aiRulesetSlot[i].Equipped)
					{
						slotIndex = i;
						break;
					}
				}
			}
			// unequip
			if(slotIndex >= 0 &&
				slotIndex < this.aiRulesetSlot.Length &&
				this.aiRulesetSlot[slotIndex].Equipped)
			{
				// player collect
				if(collect &&
					this.owner.IsPlayerControlled())
				{
					this.owner.Inventory.AICollection.AddAIRuleset(this.aiRulesetSlot[slotIndex].AIRuleset.ID, 1, false, false);
				}

				// unregister auto unequip
				if(this.aiRulesetSlot[slotIndex].AIRuleset.Setting.useEquipRequirements &&
					this.aiRulesetSlot[slotIndex].AIRuleset.Setting.autoUnequip)
				{
					this.aiRulesetSlot[slotIndex].AIRuleset.Setting.equipRequirement.UnregisterChanges(this.owner, this, this.CheckSlots);
				}

				this.aiRulesetSlot[slotIndex].AIRuleset = null;

				if(notify)
				{
					this.FireChanged();
				}
			}
		}

		public bool SetActionTargets(BaseAction action, List<Combatant> preferredTargets,
			List<Combatant> allies, List<Combatant> enemies)
		{
			if(action != null)
			{
				if((!this.owner.Setting.attackGroupTarget || !action.SetGroupTarget()) &&
					(!this.owner.Setting.attackIndividualTarget || !action.SetIndividualTarget()))
				{
					if(action.forceFoundTargets &&
						action.ForceFoundTargets(preferredTargets, allies, enemies))
					{
						return true;
					}

					for(int i = 0; i < this.aiRulesetSlot.Length; i++)
					{
						if(!this.aiRulesetSlot[i].Blocked &&
							this.aiRulesetSlot[i].Equipped)
						{
							if(this.aiRulesetSlot[i].AIRuleset.Setting.SetActionTargets(
								action, this.owner, allies, enemies))
							{
								return true;
							}
						}
					}

					return action.AutoTarget(preferredTargets, allies, enemies);
				}
				else
				{
					return true;
				}
			}
			return false;
		}

		public bool CanUseAction(BaseAction action)
		{
			if(action != null)
			{
				// ability/attack/counter
				if(action is AbilityAction)
				{
					AbilityAction ability = (AbilityAction)action;
					// ability
					if(ability.IsType(ActionType.Ability))
					{
						return this.CanUseAbility(ability.Ability.ID);
					}
					// attack
					else if(ability.IsType(ActionType.Attack))
					{
						return this.CanUseAttack();
					}
					// counter attack
					else if(ability.IsType(ActionType.CounterAttack))
					{
						return this.CanUseCounterAttack();
					}
				}
				// item
				else if(action is ItemAction)
				{
					return this.CanUseItem(((ItemAction)action).Item.ID);
				}
			}
			return true;
		}

		public bool CanUseAbility(int abilityID)
		{
			for(int i = 0; i < this.aiRulesetSlot.Length; i++)
			{
				if(!this.aiRulesetSlot[i].Blocked &&
					this.aiRulesetSlot[i].Equipped)
				{
					if(!this.aiRulesetSlot[i].AIRuleset.Setting.CanUseAbility(this.owner, abilityID))
					{
						return false;
					}
				}
			}
			return true;
		}

		public bool CanUseAttack()
		{
			for(int i = 0; i < this.aiRulesetSlot.Length; i++)
			{
				if(!this.aiRulesetSlot[i].Blocked &&
					this.aiRulesetSlot[i].Equipped)
				{
					if(!this.aiRulesetSlot[i].AIRuleset.Setting.CanUseAttack(this.owner))
					{
						return false;
					}
				}
			}
			return true;
		}

		public bool CanUseCounterAttack()
		{
			for(int i = 0; i < this.aiRulesetSlot.Length; i++)
			{
				if(!this.aiRulesetSlot[i].Blocked &&
					this.aiRulesetSlot[i].Equipped)
				{
					if(!this.aiRulesetSlot[i].AIRuleset.Setting.CanUseCounterAttack(this.owner))
					{
						return false;
					}
				}
			}
			return true;
		}

		public bool CanUseItem(int itemID)
		{
			for(int i = 0; i < this.aiRulesetSlot.Length; i++)
			{
				if(!this.aiRulesetSlot[i].Blocked &&
					this.aiRulesetSlot[i].Equipped)
				{
					if(!this.aiRulesetSlot[i].AIRuleset.Setting.CanUseItem(this.owner, itemID))
					{
						return false;
					}
				}
			}
			return true;
		}


		/*
		============================================================================
		Action functions
		============================================================================
		*/
		public void Tick(float battleTime)
		{
			// real time AI
			if(this.owner.Battle.InBattle &&
				ORK.Control.InBattle &&
				this.owner.Actions.CanChoose &&
				ORK.Battle.IsRealTime() &&
				ORK.Battle.IsBattleRunning() &&
				!this.owner.Dead &&
				this.owner.IsAggressive &&
				(!this.owner.Setting.limitAIRange ||
					this.owner.IsLeader ||
					this.owner.Setting.aiRange.InRange(this.owner, this.owner.Group.Leader)))
			{
				if(this.realTimeTimeout > 0)
				{
					this.realTimeTimeout -= battleTime;
				}
				if((this.realTimeTimeout <= 0 || this.owner.AI.RealTimeCounterTarget != null) &&
					this.owner.IsAIControlled())
				{
					this.owner.Actions.Choose(true, true);
				}
			}
		}

		/// <summary>
		/// Gets a battle action based on the AI settings and BattleAI of the combatant.
		/// </summary>
		/// <returns>
		/// The selected battle action.
		/// </returns>
		/// <param name='allies'>
		/// A list of combatants allied to the combatant.
		/// </param>
		/// <param name='enemies'>
		/// A list of combatants who are enemies of the combatant.
		/// </param>
		public BaseAction GetAction(List<Combatant> allies, List<Combatant> enemies)
		{
			// get in battle range
			allies = TargetHelper.GetCombatantsInRange(this.owner, allies);
			enemies = TargetHelper.GetCombatantsInRange(this.owner, enemies);

			BaseAction action = null;

			if(ORK.BattleSettings.aiRange.InRange(this.owner, ORK.Game.ActiveGroup.Leader))
			{
				if(this.realTimeCounterTarget != null)
				{
					action = BaseAction.CreateAbility(this.owner, this.owner.Abilities.GetCounterAttack(), -2);
					if(action != null)
					{
						action.SetTarget(this.realTimeCounterTarget);
					}
				}
				else if(this.blocked)
				{
					action = new NoneAction(this.owner);
				}
				else
				{
					// AI rulesets
					for(int i = 0; i < this.aiRulesetSlot.Length; i++)
					{
						if(!this.aiRulesetSlot[i].Blocked &&
							this.aiRulesetSlot[i].Equipped)
						{
							action = this.aiRulesetSlot[i].AIRuleset.Setting.GetAction(this.owner, allies, enemies);
							if(action != null)
							{
								break;
							}
						}
					}
					// AI behaviours
					if(action == null)
					{
						for(int i = 0; i < this.aiBehaviourSlot.Length; i++)
						{
							if(!this.aiBehaviourSlot[i].Blocked &&
								this.aiBehaviourSlot[i].Equipped)
							{
								action = this.aiBehaviourSlot[i].AIBehaviour.Setting.GetAction(this.owner, allies, enemies);
								if(action != null)
								{
									break;
								}
							}
						}
					}
					// battle AI
					if(action == null)
					{
						for(int i = 0; i < this.owner.Setting.aiBehaviour.Length; i++)
						{
							action = this.owner.Setting.aiBehaviour[i].GetAction(this.owner, allies, enemies);
							if(action != null)
							{
								break;
							}
						}
					}

					// set up base attack if no action was found
					if(action == null)
					{
						if(this.owner.Status.BlockAttack || enemies.Count == 0)
						{
							action = new NoneAction(this.owner);
						}
						else
						{
							action = BaseAction.CreateAbility(this.owner, this.owner.Abilities.GetCurrentBaseAttack(), -2);
							if(action != null)
							{
								if((!this.owner.Setting.attackGroupTarget || !action.SetGroupTarget()) &&
									(!this.owner.Setting.attackIndividualTarget || !action.SetIndividualTarget()))
								{
									List<Combatant> targets = new List<Combatant>();
									if(this.owner.Setting.attackLastTarget &&
										this.owner.Battle.LastTargets.Count > 0)
									{
										targets.AddRange(this.owner.Battle.LastTargets);
									}
									action.AutoTarget(targets, allies, enemies);
								}
							}
							else
							{
								action = new NoneAction(this.owner);
							}
						}
					}
				}

				if(action != null && !action.IsType(ActionType.None))
				{
					if(!action.HasTargets() &&
						(!action.HasOutOfRangeTargets() || !ORK.Battle.CanUseMoveAI(this.owner)))
					{
						action = new NoneAction(this.owner);
					}
					else if(ORK.Battle.CanUseMoveAI(this.owner) && !action.InRange())
					{
						if(this.owner.MoveAI != null &&
							this.owner.MoveAI.SetActionTarget(action))
						{
							action.moveToTarget = true;
						}
						else
						{
							action = new NoneAction(this.owner);
						}
					}
					else if(this.owner.MoveAI != null)
					{
						this.owner.MoveAI.Stop();
					}
				}

				// set AI timeout timer
				if(this.realTimeCounterTarget != null)
				{
					this.realTimeCounterTarget = null;
					this.realTimeTimeout = 0;
				}
				else
				{
					this.realTimeTimeout = this.owner.Setting.aiTimeout;
				}
			}
			else
			{
				action = new NoneAction(this.owner);
				this.realTimeTimeout = ORK.BattleSettings.aiRecheckTime;
			}

			if(action != null)
			{
				if(ORK.Battle.IsActiveTime())
				{
					if(this.owner.Battle.UsedActionBar + action.ActionCost > ORK.BattleSystem.activeTime.maxTimebar)
					{
						action = new NoneAction(this.owner);
					}
				}
				else if(ORK.Battle.IsTurnBased() || ORK.Battle.IsPhase())
				{
					if(this.owner.Battle.UsedActionBar + action.ActionCost > this.owner.Battle.ActionBar)
					{
						action = new NoneAction(this.owner);
					}
				}
			}

			if(action == null)
			{
				this.owner.Battle.EndTurnCommand();
			}

			return action;
		}


		/*
		============================================================================
		Move AI functions
		============================================================================
		*/
		/// <summary>
		/// Changes the used move AI and use mode of the combatant based on equipped 
		/// AI rulesets and AI behaviours (in that order). The first found change will be used.
		/// </summary>
		/// <returns><c>true</c> if the move AI was changed.</returns>
		public bool ChangeMoveAI()
		{
			bool changed = false;

			// AI rulesets
			for(int i = 0; i < this.aiRulesetSlot.Length; i++)
			{
				if(!this.aiRulesetSlot[i].Blocked &&
					this.aiRulesetSlot[i].Equipped &&
					this.aiRulesetSlot[i].AIRuleset.Setting.ChangeMoveAI(this.owner))
				{
					changed = true;
					break;
				}
			}

			// AI behaviours
			if(!changed)
			{
				for(int i = 0; i < this.aiBehaviourSlot.Length; i++)
				{
					if(!this.aiBehaviourSlot[i].Blocked &&
						this.aiBehaviourSlot[i].Equipped &&
						this.aiBehaviourSlot[i].AIBehaviour.Setting.ChangeMoveAI(this.owner))
					{
						changed = true;
						break;
					}
				}
			}

			return changed;
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();

			data.Set("aiControlled", this.aiControlled);
			data.Set("blocked", this.blocked);

			if(ORK.SaveGameMenu.aiBehaviours)
			{
				DataObject[] behaviours = new DataObject[this.aiBehaviourSlot.Length];
				for(int i = 0; i < this.aiBehaviourSlot.Length; i++)
				{
					behaviours[i] = this.aiBehaviourSlot[i].SaveGame();
				}
				data.Set("aiBehaviourSlot", behaviours);
			}
			if(ORK.SaveGameMenu.aiRulesets)
			{
				DataObject[] rulesets = new DataObject[this.aiRulesetSlot.Length];
				for(int i = 0; i < this.aiRulesetSlot.Length; i++)
				{
					rulesets[i] = this.aiRulesetSlot[i].SaveGame();
				}
				data.Set("aiRulesetSlot", rulesets);
			}
			return data;
		}

		public void LoadGame(DataObject data)
		{
			this.Init();
			if(data != null)
			{
				data.Get("aiControlled", ref this.aiControlled);
				data.Get("blocked", ref this.blocked);

				if(ORK.SaveGameMenu.aiBehaviours)
				{
					DataObject[] behaviours = data.GetFileArray("aiBehaviourSlot");
					if(behaviours != null)
					{
						this.aiBehaviourSlot = new AIBehaviourSlot[behaviours.Length];
						for(int i = 0; i < behaviours.Length; i++)
						{
							this.aiBehaviourSlot[i] = new AIBehaviourSlot();
							this.aiBehaviourSlot[i].LoadGame(behaviours[i]);
						}
					}
				}
				if(ORK.SaveGameMenu.aiRulesets)
				{
					DataObject[] rulesets = data.GetFileArray("aiRulesetSlot");
					if(rulesets != null)
					{
						this.aiRulesetSlot = new AIRulesetSlot[rulesets.Length];
						for(int i = 0; i < rulesets.Length; i++)
						{
							this.aiRulesetSlot[i] = new AIRulesetSlot();
							this.aiRulesetSlot[i].LoadGame(rulesets[i]);
						}
					}
				}


				// register
				for(int i = 0; i < this.aiBehaviourSlot.Length; i++)
				{
					if(this.aiBehaviourSlot[i].Equipped &&
						this.aiBehaviourSlot[i].AIBehaviour.Setting.useEquipRequirements &&
						this.aiBehaviourSlot[i].AIBehaviour.Setting.autoUnequip)
					{
						this.aiBehaviourSlot[i].AIBehaviour.Setting.equipRequirement.
							RegisterChanges(this.owner, this, this.CheckSlots);
					}
				}
				for(int i = 0; i < this.aiRulesetSlot.Length; i++)
				{
					if(this.aiRulesetSlot[i].Equipped &&
						this.aiRulesetSlot[i].AIRuleset.Setting.useEquipRequirements &&
						this.aiRulesetSlot[i].AIRuleset.Setting.autoUnequip)
					{
						this.aiRulesetSlot[i].AIRuleset.Setting.equipRequirement.
							RegisterChanges(this.owner, this, this.CheckSlots);
					}
				}
			}
		}
	}
}
