﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridMoveAction : BaseAction
	{
		private List<BattleGridCellComponent> path;

		private BattleGridCellComponent targetCell;

		private float moveCost;

		private GridMoveShortcut gridMoveShortcut;

		public GridMoveAction(Combatant user, List<BattleGridCellComponent> path,
			float moveCost, GridMoveShortcut gridMoveShortcut)
		{
			this.user = user;
			this.target = new List<Combatant>();
			this.target.Add(user);

			this.gridMoveShortcut = gridMoveShortcut;
			if(this.gridMoveShortcut == null)
			{
				this.gridMoveShortcut = this.user.Shortcuts.GridMoveShortcut;
			}

			this.path = path;
			this.moveCost = moveCost;
			if(this.path != null && this.path.Count > 0)
			{
				this.targetCell = this.path[this.path.Count - 1];
				this.targetCell.MarkedForCombatant = this.user;
			}

			this.actionCost = ORK.Battle.GetGridMoveActionCost(user);
		}

		public override bool IsType(ActionType t)
		{
			return ActionType.GridMove == t;
		}

		public override IShortcut Shortcut
		{
			get { return this.gridMoveShortcut; }
		}


		/*
		============================================================================
		Action performing functions
		============================================================================
		*/
		public override bool CanUse()
		{
			return this.user != null && !this.user.Dead &&
				!this.user.Status.StopMove &&
				!this.user.Status.StopMovement &&
				this.user.Battle.GridMoveState != GridMoveState.Performed;
		}

		protected override void ActionStartSetup()
		{
			if(ORK.BattleTexts.showInfo)
			{
				ORK.BattleTexts.gridMoveInfo.Show(this.user, "");
			}

			if(ORK.ConsoleSettings.displayActions)
			{
				if(this.user.Setting.ownConsoleGridMove)
				{
					this.user.Setting.consoleGridMove.Print(this.user, this.target, null);
				}
				else
				{
					ORK.ConsoleSettings.actionGridMove.Print(this.user, this.target, null);
				}
			}

			this.user.GetGridMoveBattleEvent(ref this.events);
		}

		public override void Calculate(List<Combatant> ts, float damageFactor, bool animate,
			VariableHandler localVariables, SelectedDataHandler selectedData)
		{

		}

		protected override void ActionEndSetup()
		{
			if(this.user != null)
			{
				if(ORK.BattleSystem.gridSettings.moveCommand.useOnlyOnce)
				{
					this.user.Battle.GridMoveState = GridMoveState.Performed;
				}
				else
				{
					this.user.Battle.GridMoveState = GridMoveState.Available;
				}
				this.user.GridCell = this.targetCell;
				this.user.Battle.GridMoveRange -= this.moveCost;

				if(this.user.GridCell != null &&
					this.user.GameObject != null)
				{
					this.user.GameObject.transform.position = this.user.GridCell.transform.position;
				}
			}
		}


		/*
		============================================================================
		Path functions
		============================================================================
		*/
		public int GetRemainingPathLength()
		{
			return this.path != null ? this.path.Count : 0;
		}

		public BattleGridCellComponent GetNextPathCell(bool remove)
		{
			if(this.path != null && this.path.Count > 0)
			{
				BattleGridCellComponent cell = this.path[0];
				if(remove)
				{
					this.path.RemoveAt(0);
				}
				return cell;
			}
			return null;
		}

		public BattleGridCellComponent GetLastPathCell(bool remove)
		{
			if(this.path != null && this.path.Count > 0)
			{
				int index = this.path.Count - 1;
				BattleGridCellComponent cell = this.path[index];
				if(remove)
				{
					this.path.RemoveAt(index);
				}
				return cell;
			}
			return null;
		}

		public List<BattleGridCellComponent> GetRemainingPath(bool remove)
		{
			List<BattleGridCellComponent> list = this.path;
			if(remove)
			{
				this.path = null;
			}
			return list;
		}

		public void RemoveCell(GridPathCellSelection selection)
		{
			if(GridPathCellSelection.Next == selection)
			{
				if(this.path != null && this.path.Count > 0)
				{
					this.path.RemoveAt(0);
				}
			}
			else if(GridPathCellSelection.Last == selection)
			{
				if(this.path != null && this.path.Count > 0)
				{
					this.path.RemoveAt(this.path.Count - 1);
				}
			}
			else if(GridPathCellSelection.All == selection)
			{
				this.path = null;
			}
		}
	}
}
