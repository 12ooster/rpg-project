﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CombatantShortcuts : ISaveData
	{
		private Combatant owner;

		private IShortcut activeShortcut;


		// lists
		private CombatantShortcutList[] shortcutList;

		private int shortcutIndex = 0;

		private Dictionary<int, CombatantShortcutList[]> classShortcutList = new Dictionary<int, CombatantShortcutList[]>();


		// special actions
		private DefendShortcut defendShortcut;

		private EscapeShortcut escapeShortcut;

		private NoneShortcut noneShortcut;

		private GridMoveShortcut gridMoveShortcut;

		private GridOrientationShortcut gridOrientationShortcut;

		private GridExamineShortcut gridExamineShortcut;

		public CombatantShortcuts(Combatant owner)
		{
			this.owner = owner;
		}

		public void ClearClassLists()
		{
			this.classShortcutList = new Dictionary<int, CombatantShortcutList[]>();
		}

		public IShortcut Active
		{
			get { return this.activeShortcut; }
			set { this.activeShortcut = value; }
		}

		public void DisableActive()
		{
			if(this.activeShortcut != null)
			{
				if(this.owner.BattleMenu != null)
				{
					this.owner.BattleMenu.StopTargetSelection();
				}
				this.activeShortcut = null;
			}
		}


		/*
		============================================================================
		Init functions
		============================================================================
		*/
		public void Init(Class cl)
		{
			if(this.owner.Setting.useClassShortcuts)
			{
				if(this.classShortcutList.ContainsKey(this.owner.ClassID))
				{
					this.shortcutList = this.classShortcutList[this.owner.ClassID];
				}
				else
				{
					this.shortcutList = new CombatantShortcutList[cl.ownShortcutListCount ?
						cl.shortcutListCount : ORK.ShortcutSettings.shortcutListCount];
					for(int i = 0; i < this.shortcutList.Length; i++)
					{
						this.shortcutList[i] = new CombatantShortcutList(this.owner);
					}

					// set default shortcuts
					if(!cl.replaceDefaultShortcuts)
					{
						for(int i = 0; i < ORK.ShortcutSettings.defaultShortcut.Length; i++)
						{
							ORK.ShortcutSettings.defaultShortcut[i].Assign(this.owner);
						}
					}
					for(int i = 0; i < cl.defaultShortcut.Length; i++)
					{
						cl.defaultShortcut[i].Assign(this.owner);
					}
				}
			}
			else
			{
				this.shortcutList = new CombatantShortcutList[this.owner.Setting.ownShortcutListCount ?
					this.owner.Setting.shortcutListCount : ORK.ShortcutSettings.shortcutListCount];
				for(int i = 0; i < this.shortcutList.Length; i++)
				{
					this.shortcutList[i] = new CombatantShortcutList(this.owner);
				}

				// set default shortcuts
				if(!this.owner.Setting.replaceDefaultShortcuts)
				{
					for(int i = 0; i < ORK.ShortcutSettings.defaultShortcut.Length; i++)
					{
						ORK.ShortcutSettings.defaultShortcut[i].Assign(this.owner);
					}
				}
				for(int i = 0; i < this.owner.Setting.defaultShortcut.Length; i++)
				{
					this.owner.Setting.defaultShortcut[i].Assign(this.owner);
				}
			}
		}

		public void ChangeClass(int prevClassID, Class newClass)
		{
			if(this.owner.Setting.useClassShortcuts)
			{
				if(this.classShortcutList.ContainsKey(prevClassID))
				{
					this.classShortcutList[prevClassID] = this.shortcutList;
				}
				else
				{
					this.classShortcutList.Add(prevClassID, this.shortcutList);
				}

				if(this.classShortcutList.ContainsKey(this.owner.ClassID))
				{
					this.shortcutList = this.classShortcutList[this.owner.ClassID];
				}
				else
				{
					this.shortcutList = new CombatantShortcutList[newClass.ownShortcutListCount ?
						newClass.shortcutListCount : ORK.ShortcutSettings.shortcutListCount];
					for(int i = 0; i < this.shortcutList.Length; i++)
					{
						this.shortcutList[i] = new CombatantShortcutList(this.owner);
					}

					// set default shortcuts
					if(!newClass.replaceDefaultShortcuts)
					{
						for(int i = 0; i < ORK.ShortcutSettings.defaultShortcut.Length; i++)
						{
							ORK.ShortcutSettings.defaultShortcut[i].Assign(this.owner);
						}
					}
					for(int i = 0; i < newClass.defaultShortcut.Length; i++)
					{
						newClass.defaultShortcut[i].Assign(this.owner);
					}
				}
			}
		}


		/*
		============================================================================
		List functions
		============================================================================
		*/
		public CombatantShortcutList Current
		{
			get
			{
				if(this.shortcutIndex >= 0 &&
					this.shortcutIndex < this.shortcutList.Length)
				{
					return this.shortcutList[this.shortcutIndex];
				}
				else
				{
					return this.shortcutList[0];
				}
			}
		}

		public CombatantShortcutList GetList(int index)
		{
			if(index >= 0 && index < this.shortcutList.Length)
			{
				return this.shortcutList[index];
			}
			return null;
		}

		public void ChangeList(int change, bool loop)
		{
			this.shortcutIndex += change;

			if(this.shortcutIndex < 0)
			{
				this.shortcutIndex = loop ? this.shortcutList.Length - 1 : 0;
			}
			else if(this.shortcutIndex >= this.shortcutList.Length)
			{
				this.shortcutIndex = loop ? 0 : this.shortcutList.Length - 1;
			}
			this.owner.MarkHUDUpdate();
		}

		public void SetList(int index)
		{
			this.shortcutIndex = index;

			if(this.shortcutIndex < 0)
			{
				this.shortcutIndex = 0;
			}
			else if(this.shortcutIndex >= this.shortcutList.Length)
			{
				this.shortcutIndex = this.shortcutList.Length - 1;
			}
			this.owner.MarkHUDUpdate();
		}


		/*
		============================================================================
		Auto functions
		============================================================================
		*/
		public void AutoAdd(Combatant combatant, IShortcut shortcut)
		{
			if(this.owner == combatant &&
				shortcut != null)
			{
				if(this.owner.Setting.useClassShortcuts)
				{
					Class cl = ORK.Classes.Get(this.owner.ClassID);
					if(!cl.replaceDefaultAutoAddSlots)
					{
						for(int i = 0; i < ORK.ShortcutSettings.autoAddShortcuts.Length; i++)
						{
							if(ORK.ShortcutSettings.autoAddShortcuts[i].AutoAdd(this.owner, shortcut))
							{
								return;
							}
						}
					}
					for(int i = 0; i < cl.autoAddShortcuts.Length; i++)
					{
						if(cl.autoAddShortcuts[i].AutoAdd(this.owner, shortcut))
						{
							return;
						}
					}
				}
				else
				{
					if(!this.owner.Setting.replaceDefaultAutoAddSlots)
					{
						for(int i = 0; i < ORK.ShortcutSettings.autoAddShortcuts.Length; i++)
						{
							if(ORK.ShortcutSettings.autoAddShortcuts[i].AutoAdd(this.owner, shortcut))
							{
								return;
							}
						}
					}
					for(int i = 0; i < this.owner.Setting.autoAddShortcuts.Length; i++)
					{
						if(this.owner.Setting.autoAddShortcuts[i].AutoAdd(this.owner, shortcut))
						{
							return;
						}
					}
				}
			}
		}

		public void AutoArrange()
		{
			if(this.owner.Setting.useClassShortcuts)
			{
				Class cl = ORK.Classes.Get(this.owner.ClassID);
				if(!cl.replaceDefaultAutoArrangeSlots)
				{
					for(int i = 0; i < ORK.ShortcutSettings.autoArrangeShortcuts.Length; i++)
					{
						ORK.ShortcutSettings.autoArrangeShortcuts[i].AutoArrange(this.owner);
					}
				}
				for(int i = 0; i < cl.autoArrangeShortcuts.Length; i++)
				{
					cl.autoArrangeShortcuts[i].AutoArrange(this.owner);
				}
			}
			else
			{
				if(!this.owner.Setting.replaceDefaultAutoArrangeSlots)
				{
					for(int i = 0; i < ORK.ShortcutSettings.autoArrangeShortcuts.Length; i++)
					{
						ORK.ShortcutSettings.autoArrangeShortcuts[i].AutoArrange(this.owner);
					}
				}
				for(int i = 0; i < this.owner.Setting.autoArrangeShortcuts.Length; i++)
				{
					this.owner.Setting.autoArrangeShortcuts[i].AutoArrange(this.owner);
				}
			}
		}


		/*
		============================================================================
		Special action functions
		============================================================================
		*/
		public DefendShortcut DefendShortcut
		{
			get
			{
				if(this.defendShortcut == null)
				{
					this.defendShortcut = new DefendShortcut();
				}
				return defendShortcut;
			}
		}

		public EscapeShortcut EscapeShortcut
		{
			get
			{
				if(this.escapeShortcut == null)
				{
					this.escapeShortcut = new EscapeShortcut();
				}
				return escapeShortcut;
			}
		}

		public NoneShortcut NoneShortcut
		{
			get
			{
				if(this.noneShortcut == null)
				{
					this.noneShortcut = new NoneShortcut();
				}
				return noneShortcut;
			}
		}

		public GridMoveShortcut GridMoveShortcut
		{
			get { return this.gridMoveShortcut; }
			set { this.gridMoveShortcut = value; }
		}

		public GridOrientationShortcut GridOrientationShortcut
		{
			get { return this.gridOrientationShortcut; }
			set { this.gridOrientationShortcut = value; }
		}

		public GridExamineShortcut GridExamineShortcut
		{
			get
			{
				if(this.gridExamineShortcut == null)
				{
					this.gridExamineShortcut = new GridExamineShortcut();
				}
				return gridExamineShortcut;
			}
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();

			DataObject[] tmp = new DataObject[this.shortcutList.Length];
			for(int i = 0; i < this.shortcutList.Length; i++)
			{
				tmp[i] = this.shortcutList[i].SaveGame();
			}
			data.Set("shortcutList", tmp);

			DataObject cshortcutList = new DataObject();
			foreach(KeyValuePair<int, CombatantShortcutList[]> pair in this.classShortcutList)
			{
				tmp = new DataObject[pair.Value.Length];
				for(int i = 0; i < pair.Value.Length; i++)
				{
					tmp[i] = pair.Value[i].SaveGame();
				}

				cshortcutList.Set(pair.Key.ToString(), tmp);
			}
			data.Set("cshortcutList", cshortcutList);

			return data;
		}

		public void LoadGame(DataObject data)
		{
			this.classShortcutList = new Dictionary<int, CombatantShortcutList[]>();

			if(data != null)
			{
				if(data.Contains<DataObject>("shortcuts"))
				{
					this.shortcutList[0].LoadGame(data.GetFile("shortcuts"));
				}
				else
				{
					DataObject[] shortcutListData = data.GetFileArray("shortcutList");
					if(shortcutListData != null)
					{
						for(int i = 0; i < shortcutListData.Length; i++)
						{
							if(i < this.shortcutList.Length)
							{
								this.shortcutList[i].LoadGame(shortcutListData[i]);
							}
						}
					}

					DataObject classShortcutListData = data.GetFile("cshortcutList");
					if(classShortcutListData != null)
					{
						Dictionary<string, DataObject[]> list = classShortcutListData.GetArrayData<DataObject>(typeof(DataObject));
						if(list != null && list.Count > 0)
						{
							foreach(KeyValuePair<string, DataObject[]> pair in list)
							{
								CombatantShortcutList[] tmpList = new CombatantShortcutList[pair.Value.Length];
								for(int i = 0; i < tmpList.Length; i++)
								{
									tmpList[i] = new CombatantShortcutList(this.owner);
									tmpList[i].LoadGame(pair.Value[i]);
								}
								this.classShortcutList.Add(int.Parse(pair.Key), tmpList);
							}
						}
					}
				}
			}
		}
	}
}
