﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class AIRulesetSlotSetting : BaseData
	{
		// unequip
		[ORKEditorHelp("Unequip", "This AI ruleset slot will be unequipped.", "")]
		public bool unequip = false;

		[ORKEditorHelp("Collect", "Collect the currently equipped AI ruleset.\n" +
			"Only used for combatants of the player group.", "")]
		public bool collect = false;


		// equip
		[ORKEditorHelp("AI Ruleset", "Select the AI ruleset that will be equipped.", "")]
		[ORKEditorInfo(ORKDataType.AIRuleset)]
		[ORKEditorLayout("unequip", false)]
		public int aiRulesetID = 0;

		[ORKEditorHelp("From Collection", "The AI ruleset will be taken from the collection, " +
			"i.e. it must be collected and available to be equipped.\n" +
			"This is only used for combatants of the player group.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool fromCollection = false;

		public AIRulesetSlotSetting()
		{

		}

		public void Use(Combatant user, int slotIndex, bool notify)
		{
			if(this.unequip)
			{
				user.AI.UnequipAIRuleset(slotIndex, this.collect, notify);
			}
			else
			{
				user.AI.EquipAIRuleset(this.aiRulesetID, slotIndex, this.collect, this.fromCollection, notify);
			}
		}

		public string GetInfoText()
		{
			return this.unequip ? "Unequip" : ORK.AIRulesets.GetName(this.aiRulesetID);
		}
	}
}
