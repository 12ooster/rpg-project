﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class InteractionSettings : BaseData
	{
		// interaction settings
		[ORKEditorHelp("Interact Key", "The key used to start interactions.", "")]
		[ORKEditorInfo(ORKDataType.InputKey)]
		public int interactKey = 3;

		[ORKEditorHelp("Max Event Steps", "The maximum number of event steps executed without an update cycle.\n" +
			"This setting influences how fast game/battle event steps (without a wait time) will execute after the previous step - " +
			"the lower the number, the slower the event execution.\n" +
			"Reduce this number if you experience stack overflow errors in events.", "")]
		[ORKEditorLimit(0, false)]
		public int maxSteps = 100;

		[ORKEditorHelp("Max Click Distance", "The maximum distance in world units to allow " +
			"starting an 'Interaction' type interaction by clicking/touching the game object.\n" +
			"Set to 0 to not allow clicking.\n\n" +
			"Set to -1 to allow clicking without checking the distance." +
			"This setting can be overridden by the individual interactions.", "")]
		[ORKEditorLimit(-1.0f, false)]
		public float maxClickDistance = 3;


		// interaction controller
		[ORKEditorHelp("Add Automatically", "The interaction controller is automatically added to the player." +
			"If disabled, you need to manually add an interaction controller to the prefab of the player.", "")]
		[ORKEditorInfo(separator=true, labelText="Interaction Controller")]
		public bool addIC = false;

		[ORKEditorHelp("IC Prefab", "The prefab used as interaction controller.", "")]
		[ORKEditorLayout("addIC", true)]
		public GameObject icPrefab;

		[ORKEditorLayout(endCheckGroup=true)]
		public MountSettings icMount = new MountSettings();


		// move to interaction
		[ORKEditorInfo("Move To Interaction", "The player can optionally move to an interaction " +
			"(e.g. event interaction, item collector) before starting the interaction.", "", endFoldout=true)]
		public MoveToInteractionSettings moveToInteraction = new MoveToInteractionSettings();

		public InteractionSettings()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(!data.Contains<int>("interactKey"))
			{
				this.interactKey = -1;
			}
		}

		public void AddInteractionController(GameObject player)
		{
			if(this.addIC && player != null && this.icPrefab != null &&
				player.GetComponentInChildren<InteractionController>() == null)
			{
				GameObject ic = (GameObject)GameObject.Instantiate(this.icPrefab);
				if(ic != null)
				{
					this.icMount.MountTo(player.transform, ic.transform);
				}
			}
		}
	}
}
