
using UnityEngine;

namespace ORKFramework
{
	public class GroupSpots : BaseData
	{
		[ORKEditorInfo(labelText="Standard Battle Spot")]
		public BattleSpot spot = new BattleSpot();


		// player advantage
		[ORKEditorHelp("Use PA Spots", "Player advantage battles use extra battle spots.", "")]
		[ORKEditorInfo(separator=true, labelText="Player Advantage Spots")]
		public bool usePA = false;

		[ORKEditorLayout("usePA", true, endCheckGroup=true, autoInit=true)]
		public BattleSpot paSpot;


		// enemy advantage
		[ORKEditorHelp("Use EA Spots", "Enemy advantage battles use extra battle spots.", "")]
		[ORKEditorInfo(separator=true, labelText="Enemy Advantage Spots")]
		public bool useEA = false;

		[ORKEditorLayout("useEA", true, endCheckGroup=true, autoInit=true)]
		public BattleSpot eaSpot;

		public GroupSpots()
		{

		}

		public void SetSpot(GroupAdvantageType advantage, Transform arenaTransform, Transform spotTransform)
		{
			if(this.usePA &&
				GroupAdvantageType.Player == advantage)
			{
				this.paSpot.SetSpot(arenaTransform, spotTransform);
			}
			else if(this.useEA &&
				GroupAdvantageType.Enemy == advantage)
			{
				this.eaSpot.SetSpot(arenaTransform, spotTransform);
			}
			else
			{
				this.spot.SetSpot(arenaTransform, spotTransform);
			}
		}
	}
}
