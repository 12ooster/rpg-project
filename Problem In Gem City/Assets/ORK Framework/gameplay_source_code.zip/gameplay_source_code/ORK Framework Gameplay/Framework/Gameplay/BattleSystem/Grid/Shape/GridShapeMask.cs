﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridShapeMask : BaseData
	{
		public int range = 1;

		public GridShapeCell[] cell = new GridShapeCell[0];

		public GridShapeMask()
		{
			this.Create(1);
		}

		public GridShapeMask(int range)
		{
			this.Create(range);
		}


		/*
		============================================================================
		Editor functions
		============================================================================
		*/
		public void Create(int range)
		{
			this.range = range;

			if(BattleGridType.Square == ORK.BattleSystem.gridSettings.type)
			{
				int cellCount = this.range * 2 + 1;
				this.cell = new GridShapeCell[cellCount * cellCount];
				int i = 0;

				for(int dx = -this.range; dx <= this.range; dx++)
				{
					for(int dy = -this.range; dy <= this.range; dy++)
					{
						this.cell[i++] = new GridShapeCell(new CubeCoord(dx, dy, 0));
					}
				}
			}
			else if(BattleGridType.Hexagonal == ORK.BattleSystem.gridSettings.type)
			{
				List<GridShapeCell> list = new List<GridShapeCell>();

				for(int dx = -range; dx <= range; dx++)
				{
					int max = Mathf.Max(-range, -dx - range);
					int min = Mathf.Min(range, -dx + range);

					for(int dy = max; dy <= min; dy++)
					{
						list.Add(new GridShapeCell(new CubeCoord(dx, dy, -dx-dy)));
					}
				}
				this.cell = list.ToArray();
			}
		}
		
		public void SelectAll(bool state)
		{
			for(int i = 0; i < this.cell.Length; i++)
			{
				if(this.cell[i] != null)
				{
					this.cell[i].selected = state;
				}
			}
		}
	}
}
