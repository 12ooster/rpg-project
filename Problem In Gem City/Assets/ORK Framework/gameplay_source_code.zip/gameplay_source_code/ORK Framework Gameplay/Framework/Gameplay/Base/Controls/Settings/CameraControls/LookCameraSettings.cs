﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class LookCameraSettings : BaseData
	{
		[ORKEditorHelp("Use Child Object", "The camera will be positioned using a child object of the player (e.g. body/head).\n" +
			"Leave empty if you don't want to use a child object and place the camera using the root of the player object.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string onChild = "";

		[ORKEditorHelp("Smooth", "Camera changes will use damping.", "")]
		[ORKEditorInfo(separator=true)]
		public bool smooth = true;

		[ORKEditorHelp("Damping", "Used for smoother camera changes.\n" +
			"Higher values mean quicker changes, set to 0 to disable.", "")]
		[ORKEditorLayout("smooth", true, endCheckGroup=true)]
		[ORKEditorLimit(0.0f, false)]
		public float damping = 6.0f;

		public LookCameraSettings()
		{

		}

		public void Setup(GameObject camera)
		{
			if(camera != null)
			{
				SmoothLookAt comp = camera.GetComponent<SmoothLookAt>();
				if(comp == null)
				{
					comp = camera.AddComponent<SmoothLookAt>();

					comp.onChild = this.onChild;
					comp.damping = this.damping;
					comp.smooth = this.smooth;

					ORK.Control.AddCameraControl(comp);
				}
			}
		}
	}
}
