﻿
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Learn Ability", "A combatant will learn a defined ability.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Combatant/Ability")]
	public class LearnAbilityStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="Combatant")]
		public EventObjectSetting usedObject = new EventObjectSetting();


		// ability settings
		[ORKEditorHelp("Use Selected Data", "Use abilities stored in selected data.", "")]
		[ORKEditorInfo(separator=true, labelText="Ability Settings")]
		public bool useSelectedData = false;

		[ORKEditorInfo(labelText="Selected Key")]
		[ORKEditorLayout("useSelectedData", true, autoInit=true)]
		public StringValue selectedKey;

		[ORKEditorHelp("Ability", "Select the ability the combatant will learn.", "")]
		[ORKEditorInfo(ORKDataType.Ability)]
		[ORKEditorLayout(elseCheckGroup=true)]
		public int abilityID = 0;

		[ORKEditorHelp("Level", "The level of the ability that will be learned.", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout(endCheckGroup=true)]
		public int lvl = 1;

		[ORKEditorHelp("Group Ability", "The ability will be learned by the group of the actor, " +
			"i.e. all group members will have access to it.\n" +
			"If disabled, only one combatant learns the ability.", "")]
		public bool isGroupAbility = false;

		[ORKEditorHelp("Show Notification", "Learning the ability will display a notification.", "")]
		public bool showNotification = true;

		[ORKEditorHelp("Show Console", "Learning the ability will be displayed in the console.", "")]
		public bool showConsole = true;

		public LearnAbilityStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("id"))
			{
				this.usedObject.type = StepObjectType.Actor;
				data.Get("id", ref this.usedObject.aID);
				data.Get("id2", ref this.abilityID);
			}
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = this.usedObject.GetCombatant(baseEvent);

			if(this.useSelectedData)
			{
				List<AbilityShortcut> abilities = SelectedDataHelper.GetAbilities(
					baseEvent.SelectedData.Get(this.selectedKey.GetValue()));

				if(abilities != null && abilities.Count > 0)
				{
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							for(int j = 0; j < abilities.Count; j++)
							{
								if(this.isGroupAbility)
								{
									list[i].Group.Abilities.Learn(abilities[j], 
										this.showNotification, this.showConsole);
								}
								else
								{
									list[i].Abilities.Learn(abilities[j], 
										this.showNotification, this.showConsole);
								}
							}
						}
					}
				}
			}
			else
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						if(this.isGroupAbility)
						{
							list[i].Group.Abilities.Learn(this.abilityID, this.lvl, 
								this.showNotification, this.showConsole);
						}
						else
						{
							list[i].Abilities.Learn(this.abilityID, this.lvl, 
								this.showNotification, this.showConsole);
						}
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.usedObject.GetInfoText() + ": " +
				(this.useSelectedData ?
					this.selectedKey.GetInfoText() :
					ORK.Abilities.Get(this.abilityID).GetName(lvl));
		}
	}

	[ORKEditorHelp("Forget Ability", "A combatant will forget a defined ability.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Combatant/Ability")]
	public class ForgetAbilityStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="Combatant")]
		public EventObjectSetting usedObject = new EventObjectSetting();


		// ability settings
		[ORKEditorHelp("Use Selected Data", "Use abilities stored in selected data.", "")]
		[ORKEditorInfo(separator=true, labelText="Ability Settings")]
		public bool useSelectedData = false;

		[ORKEditorInfo(labelText="Selected Key")]
		[ORKEditorLayout("useSelectedData", true, autoInit=true)]
		public StringValue selectedKey;

		[ORKEditorHelp("Ability", "Select the ability the combatant will forget.", "")]
		[ORKEditorInfo(ORKDataType.Ability)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int abilityID = 0;

		[ORKEditorHelp("Group Ability", "The ability will be forgotten by the group of the actor, " +
			"i.e. all group members that only had the ability through " +
			"group abilities will not be able to use it any longer.\n" +
			"If disabled, only one combatant learns the ability.", "")]
		public bool isGroupAbility = false;

		[ORKEditorHelp("Show Notification", "Forgetting this ability will display a notification.", "")]
		public bool showNotification = true;

		[ORKEditorHelp("Show Console", "Forgetting this ability will be displayed in the console.", "")]
		public bool showConsole = true;

		public ForgetAbilityStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("id"))
			{
				this.usedObject.type = StepObjectType.Actor;
				data.Get("id", ref this.usedObject.aID);
				data.Get("id2", ref this.abilityID);
			}
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = this.usedObject.GetCombatant(baseEvent);

			if(this.useSelectedData)
			{
				List<AbilityShortcut> abilities = SelectedDataHelper.GetAbilities(
					baseEvent.SelectedData.Get(this.selectedKey.GetValue()));

				if(abilities != null && abilities.Count > 0)
				{
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							for(int j = 0; j < abilities.Count; j++)
							{
								if(this.isGroupAbility)
								{
									list[i].Group.Abilities.Forget(abilities[j].ID, 
										this.showNotification, this.showConsole);
								}
								else
								{
									list[i].Abilities.Forget(abilities[j].ID, 
										this.showNotification, this.showConsole);
								}
							}
						}
					}
				}
			}
			else
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						if(this.isGroupAbility)
						{
							list[i].Group.Abilities.Forget(this.abilityID, 
								this.showNotification, this.showConsole);
						}
						else
						{
							list[i].Abilities.Forget(this.abilityID, 
								this.showNotification, this.showConsole);
						}
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.usedObject.GetInfoText() + ": " +
				(this.useSelectedData ?
					this.selectedKey.GetInfoText() :
					ORK.Abilities.GetName(this.abilityID));
		}
	}

	[ORKEditorHelp("Learn Ability Tree", "A combatant will learn a defined ability tree.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Combatant/Ability")]
	public class LearnAbilityTreeStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="Combatant")]
		public EventObjectSetting usedObject = new EventObjectSetting();

		[ORKEditorHelp("Ability Tree", "Select the ability tree the combatant will learn.", "")]
		[ORKEditorInfo(ORKDataType.AbilityTree)]
		public int abilityTreeID = 0;

		[ORKEditorHelp("Show Console", "Learning this ability tree will be displayed in the console.", "")]
		public bool showConsole = true;

		public LearnAbilityTreeStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("id"))
			{
				this.usedObject.type = StepObjectType.Actor;
				data.Get("id", ref this.usedObject.aID);
				data.Get("id2", ref this.abilityTreeID);
			}
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = this.usedObject.GetCombatant(baseEvent);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					list[i].Abilities.LearnTree(this.abilityTreeID, this.showConsole);
				}
			}
			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.usedObject.GetInfoText() + ": " + ORK.AbilityTrees.GetName(this.abilityTreeID);
		}
	}

	[ORKEditorHelp("Forget Ability Tree", "A combatant will forget a defined ability tree.\n" +
		"Abilities already learned through the ability tree will still be available to the combatant.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Combatant/Ability")]
	public class ForgetAbilityTreeStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="Combatant")]
		public EventObjectSetting usedObject = new EventObjectSetting();

		[ORKEditorHelp("Ability Tree", "Select the ability tree the combatant will forget.\n" +
			"Abilities already learned through the ability tree will still be available to the combatant.", "")]
		[ORKEditorInfo(ORKDataType.AbilityTree)]
		public int abilityTreeID = 0;

		[ORKEditorHelp("Show Console", "Forgetting this ability tree will be displayed in the console.", "")]
		public bool showConsole = true;

		public ForgetAbilityTreeStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("id"))
			{
				this.usedObject.type = StepObjectType.Actor;
				data.Get("id", ref this.usedObject.aID);
				data.Get("id2", ref this.abilityTreeID);
			}
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = this.usedObject.GetCombatant(baseEvent);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					list[i].Abilities.ForgetTree(this.abilityTreeID, this.showConsole);
				}
			}
			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.usedObject.GetInfoText() + ": " + ORK.AbilityTrees.GetName(this.abilityTreeID);
		}
	}

	[ORKEditorHelp("Add Temporary Ability", "Adds a temporary ability to a combatant.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Combatant/Ability")]
	public class AddTemporaryAbilityStep : BaseEventStep
	{
		// ability settings
		[ORKEditorHelp("Use Selected Data", "Use abilities stored in selected data.", "")]
		[ORKEditorInfo(labelText="Ability Settings")]
		public bool useSelectedData = false;

		[ORKEditorInfo(labelText="Selected Key")]
		[ORKEditorLayout("useSelectedData", true, autoInit=true)]
		public StringValue selectedKey;

		[ORKEditorHelp("Ability", "Select the ability that will be added as temporary ability.", "")]
		[ORKEditorInfo(ORKDataType.Ability)]
		[ORKEditorLayout(elseCheckGroup=true)]
		public int abilityID = 0;

		[ORKEditorHelp("Level", "The level of the ability that will be added.", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout(endCheckGroup=true)]
		public int level = 1;

		[ORKEditorHelp("Auto Remove After", "The ability will automatically be removed after:" +
			"- None: Doesn't remove the ability automatically.\n" +
			"- Turn: Removes the ability after a defined amount of turns.\n" +
			"- Time: Removes the ability after a defined amount of time in seconds.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public EndAfter removeType = EndAfter.None;

		[ORKEditorLayout("removeType", EndAfter.None, elseCheckGroup=true, endCheckGroup=true, autoInit=true)]
		public EventFloat removeAfter;


		// combatant
		[ORKEditorInfo(separator=true, labelText="Combatant")]
		public EventObjectSetting useObject = new EventObjectSetting();

		public AddTemporaryAbilityStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = this.useObject.GetCombatant(baseEvent);

			if(this.useSelectedData)
			{
				List<AbilityShortcut> abilities = SelectedDataHelper.GetAbilities(
					baseEvent.SelectedData.Get(this.selectedKey.GetValue()));

				if(abilities != null && abilities.Count > 0)
				{
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							for(int j = 0; j < abilities.Count; j++)
							{
								list[i].Abilities.AddTemporaryAbility(abilities[j], this.removeType,
									EndAfter.None != this.removeType ? this.removeAfter.GetValue(baseEvent) : -1);
							}
						}
					}
				}
			}
			else
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						list[i].Abilities.AddTemporaryAbility(this.abilityID, this.level, this.removeType,
							EndAfter.None != this.removeType ? this.removeAfter.GetValue(baseEvent) : -1);
					}
				}
			}

			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.useObject.GetInfoText() + ": " +
				ORK.Abilities.Get(this.abilityID).GetName(level);
		}
	}

	[ORKEditorHelp("Remove Temporary Ability", "Removes a temporary ability from a combatant.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Combatant/Ability")]
	public class RemoveTemporaryAbilityStep : BaseEventStep
	{
		[ORKEditorHelp("Remove All", "All temporary abilities will be removed.", "")]
		[ORKEditorInfo(labelText="Ability Settings")]
		public bool all = false;

		// ability settings
		[ORKEditorHelp("Use Selected Data", "Use abilities stored in selected data.", "")]
		[ORKEditorLayout("all", false, setDefault=true, defaultValue=false)]
		public bool useSelectedData = false;

		[ORKEditorInfo(labelText="Selected Key")]
		[ORKEditorLayout("useSelectedData", true, autoInit=true)]
		public StringValue selectedKey;

		[ORKEditorHelp("Ability", "Select the ability that will be removed from the temporary abilities.", "")]
		[ORKEditorInfo(ORKDataType.Ability)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, endGroups=2)]
		public int abilityID = 0;


		// combatant
		[ORKEditorInfo(separator=true, labelText="Combatant")]
		public EventObjectSetting useObject = new EventObjectSetting();

		public RemoveTemporaryAbilityStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = this.useObject.GetCombatant(baseEvent);

			if(this.all)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						list[i].Abilities.ClearTemporaryAbilities();
					}
				}
			}
			else if(this.useSelectedData)
			{
				List<AbilityShortcut> abilities = SelectedDataHelper.GetAbilities(
					baseEvent.SelectedData.Get(this.selectedKey.GetValue()));

				if(abilities != null && abilities.Count > 0)
				{
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							for(int j=0; j<abilities.Count; j++)
							{
								list[i].Abilities.RemoveTemporaryAbility(abilities[j].ID);
							}
						}
					}
				}
			}
			else
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						list[i].Abilities.RemoveTemporaryAbility(this.abilityID);
					}
				}
			}

			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.useObject.GetInfoText() +
				(this.all ? ": All" : ": " + ORK.Abilities.Get(this.abilityID).GetName());
		}
	}

	[ORKEditorHelp("Block Ability Reuse", "Blocks a defined ability's reuse for a defined " +
		"amount of turns or time, or removes the reuse block from a combatant.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Combatant/Status", "Combatant/Ability")]
	public class BlockAbilityReuseStep : BaseEventStep
	{
		//object
		[ORKEditorInfo(labelText="Combatant")]
		public EventObjectSetting useObject = new EventObjectSetting();


		// ability settings
		[ORKEditorHelp("Use Selected Data", "Use abilities stored in selected data.", "")]
		[ORKEditorInfo(separator=true, labelText="Ability Settings")]
		public bool useSelectedData = false;

		[ORKEditorInfo(labelText="Selected Key")]
		[ORKEditorLayout("useSelectedData", true, autoInit=true)]
		public StringValue selectedKey;

		[ORKEditorHelp("Ability", "Select the ability that will be used.", "")]
		[ORKEditorInfo(ORKDataType.Ability)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int abilityID = 0;

		[ORKEditorHelp("Reuse After", "The ability can be reused after:" +
			"- None: The ability can be reused immediately (i.e. removes reuse block).\n" +
			"- Turn: The ability can be reused after a set amount of turns.\n" +
			"- Time: The ability can be reused after a set amount of time.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public EndAfter reuseType = EndAfter.None;

		[ORKEditorHelp("Block Scope", "Select the scope that will be blocked:\n" +
			"- Single: This ability is blocked.\n" +
			"- Type: All abilities of this ability's ability type are blocked.\n" +
			"- Root Type: All abilities of this ability's root ability type are blocked " +
			"(i.e. the uppermost type in the ability type tree and all it's sub-types).\n" +
			"- All: All abilites are blocked.", "")]
		[ORKEditorLayout("reuseType", EndAfter.None, elseCheckGroup=true)]
		public UseBlockScope reuseScope = UseBlockScope.Single;

		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public EventFloat reuseAfter;

		public BlockAbilityReuseStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = this.useObject.GetCombatant(baseEvent);
			if(this.useSelectedData)
			{
				List<AbilityShortcut> abilities = SelectedDataHelper.GetAbilities(
					baseEvent.SelectedData.Get(this.selectedKey.GetValue()));

				if(abilities != null && abilities.Count > 0)
				{
					for(int i = 0; i < list.Count; i++)
					{
						if(list[i] != null)
						{
							for(int j = 0; j < abilities.Count; j++)
							{
								if(EndAfter.None == this.reuseType)
								{
									list[i].Battle.RemoveUseBlock(UseBlockType.Ability, abilities[j].ID);
								}
								else
								{
									list[i].Battle.AddUseBlock(new UseBlock(
										UseBlockType.Ability, this.reuseScope, abilities[j].ID,
										this.reuseAfter.GetValue(baseEvent), this.reuseType));
								}
							}
						}
					}
				}
			}
			else
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						if(EndAfter.None == this.reuseType)
						{
							list[i].Battle.RemoveUseBlock(UseBlockType.Ability, this.abilityID);
						}
						else
						{
							list[i].Battle.AddUseBlock(new UseBlock(
								UseBlockType.Ability, this.reuseScope, this.abilityID,
								this.reuseAfter.GetValue(baseEvent), this.reuseType));
						}
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.useObject.GetInfoText() + ": " +
				(this.useSelectedData ? 
					this.selectedKey.GetInfoText() : 
					ORK.Abilities.GetName(this.abilityID));
		}
	}

	[ORKEditorHelp("Clear Ability Reuse", "Clears the ability reuse blocks of a combatant.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Combatant/Status", "Combatant/Ability")]
	public class ClearAbilityReuseStep : BaseEventStep
	{
		//object
		[ORKEditorInfo(labelText="Combatant")]
		public EventObjectSetting useObject = new EventObjectSetting();

		public ClearAbilityReuseStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = this.useObject.GetCombatant(baseEvent);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					list[i].Battle.ClearUseBlock(UseBlockType.Ability);
				}
			}
			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.useObject.GetInfoText();
		}
	}

	[ORKEditorHelp("Cancel Ability Cast", "Cancels casting an ability on a combatant.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Combatant/Ability")]
	public class CancelAbilityCastStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="Combatant")]
		public EventObjectSetting onObject = new EventObjectSetting();

		public CancelAbilityCastStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = this.onObject.GetCombatant(baseEvent);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					list[i].Actions.CancelCast();
				}
			}
			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.onObject.GetInfoText();
		}
	}

	[ORKEditorHelp("Is Casting Ability", "Checks if a combatant is casting an ability.\n" +
		"If the combatant is casting an ability, 'Casting' will be executed, otherwise 'Not Casting'.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Combatant/Ability", "Check/Combatant")]
	public class IsCastingAbilityStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Check Scope", "Select the scope that will be checked:\n" +
			"- Single: A defined ability.\n" +
			"- Type: Any ability of a defined ability type.\n" +
			"- Root Type: Any ability of a defined ability type and all it's sub-types.\n" +
			"- All: Any ability.", "")]
		public UseBlockScope checkScope = UseBlockScope.All;

		[ORKEditorHelp("Ability", "Select the ability that will be checked for.", "")]
		[ORKEditorInfo(ORKDataType.Ability)]
		[ORKEditorLayout("checkScope", UseBlockScope.Single, endCheckGroup=true)]
		public int abilityID = 0;

		[ORKEditorHelp("Ability Type", "Select the ability type that will be checked for.", "")]
		[ORKEditorInfo(ORKDataType.AbilityType)]
		[ORKEditorLayout(new string[] {"checkScope", "checkScope" },
			new System.Object[] { UseBlockScope.Type, UseBlockScope.RootType },
			needed=Needed.One, endCheckGroup=true)]
		public int abilityTypeID = 0;


		// combatant
		[ORKEditorHelp("Needed", "Either all or only one of the combatants must cast an ability.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75, separator=true, labelText="Combatant")]
		public Needed needed = Needed.All;

		public EventObjectSetting onObject = new EventObjectSetting();

		public IsCastingAbilityStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.DoCheck(this.onObject.GetCombatant(baseEvent)))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}

		private bool DoCheck(List<Combatant> list)
		{
			if(list.Count > 0)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						AbilityShortcut ability = list[i].Actions.GetCastingAbility();
						if(ability != null &&
							((UseBlockScope.All == this.checkScope) ||
							(UseBlockScope.Single == this.checkScope &&
								ability.ID == this.abilityID) ||
							(UseBlockScope.Type == this.checkScope &&
								ability.TypeID == this.abilityTypeID) ||
							(UseBlockScope.RootType == this.checkScope &&
								ORK.AbilityTypes.Get(ability.TypeID).RootType == this.abilityTypeID)))
						{
							if(Needed.One == needed)
							{
								return true;
							}
						}
						else if(Needed.All == needed)
						{
							return false;
						}
					}
				}
				if(Needed.All == needed)
				{
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Casting";
			}
			else if(index == 1)
			{
				return "Not Casting";
			}
			return "";
		}

		public override string GetNodeDetails()
		{
			return this.onObject.GetInfoText() + ": " + this.checkScope.ToString();
		}
	}
}
