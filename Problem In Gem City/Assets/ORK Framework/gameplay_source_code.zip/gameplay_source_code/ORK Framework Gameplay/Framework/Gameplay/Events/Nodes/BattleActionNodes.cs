﻿
using UnityEngine;
using ORKFramework;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Check User", "Checks if the user is player or computer controlled.\n" +
		"If the check is true, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle/Action", "Check/Battle")]
	public class CheckUserStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Player Controlled", "The user is controlled by the player.\n" +
			"If disabled, the user is controlled by the computer.", "")]
		[ORKEditorLayout("checkControl", true, endCheckGroup=true)]
		public bool pCon = true;

		public CheckUserStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			Combatant c = null;
			List<Combatant> list = baseEvent.GetActorCombatant(0);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					c = list[i];
					break;
				}
			}

			if(c != null && this.pCon == c.IsPlayerControlled())
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.pCon ? "Player Controlled" : "Not Player Controlled";
		}
	}

	[ORKEditorHelp("Calculate", "Calculates the actual battle action outcome " +
		"(i.e. the attack, ability or item use, etc.) and the damage done " +
		"(damage, refresh, miss or status effect texts are displayed).\n" +
		"This step can automatically animate the target according to what happened in the battle action " +
		"(e.g. play the damage animation defined for the combatant).\n" +
		"Don't use this step if you want to use DamageDealer and DamageZone " +
		"components to handle a battle actions outcome.\n" +
		"You can use multiple Calculate steps to create multi-damage attacks " +
		"(i.e. attacks/abilities with more then one damage).\n" +
		"The next step that will be executed can optionally depend on the outcome of the calculation - " +
		"'Next' is executed on a standard hit or if no other criteria matched.\n" +
		"When using 'Critical', 'Miss' and 'Block' next steps, the one with the highest count (e.g. 2 criticals > 1 miss) is used.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle/Action")]
	public class CalculateStep : BaseEventStep
	{
		// animation
		[ORKEditorHelp("Animate Target", "Automatically play an animation according to the result of the " +
			"battle action calculation (e.g. damage, evade, etc.).\n" +
			"The animation that will be played is defined in the combatant's animation settings.", "")]
		public bool animate = true;

		[ORKEditorHelp("Reconsume", "Using the action will consume the " +
			"use costs or item again, even if it already has been consumed.\n" +
			"If disabled, the action will only consume the use costs or " +
			"item the first time the calculation happens.", "")]
		public bool reconsume = false;

		[ORKEditorHelp("Set Damage Factor", "The outcome of the calculation will be multiplied by a defined value, e.g.:\n" +
			"- A damage factor of 1 means normal damage.\n" +
			"- A damage factor of 2 means double damage.\n" +
			"- A damage factor of 0.5 means half damage.", "")]
		[ORKEditorInfo(separator=true, labelText="Damage Factor")]
		public bool setFactor = false;

		[ORKEditorLayout("setFactor", true, endCheckGroup=true, autoInit=true)]
		public EventFloat dmgFactor;


		// other targets
		[ORKEditorHelp("Use Other Targets", "Define combatants as targets instead of using the targets the action originally found.", "")]
		[ORKEditorInfo(separator=true, labelText="Other Targets")]
		public bool useOtherTargets = false;

		[ORKEditorLayout("useOtherTargets", true, endCheckGroup=true, autoInit=true)]
		public EventObjectSetting otherTargets;


		// critical next step
		[ORKEditorHelp("Use 'Critical' Next", "Enables using a different 'Next' step " +
			"when the calculation results in a critical hit.", "")]
		[ORKEditorInfo(separator=true, labelText="Additional 'Next' Steps")]
		public bool useCritical = false;

		[ORKEditorInfo(hide=true)]
		public int nextCritical = -1;


		// miss next step
		[ORKEditorHelp("Use 'Miss' Next", "Enables using a different 'Next' step " +
			"when the calculation results in a miss.", "")]
		public bool useMiss = false;

		[ORKEditorInfo(hide=true)]
		public int nextMiss = -1;

		// block next step
		[ORKEditorHelp("Use 'Block' Next", "Enables using a different 'Next' step " +
			"when the calculation results in a block.", "")]
		public bool useBlock = false;

		[ORKEditorInfo(hide=true)]
		public int nextBlock = -1;

		public CalculateStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			int tmpNext = this.next;

			if(baseEvent is BattleEvent)
			{
				BattleEvent evt = baseEvent as BattleEvent;
				evt.calcNeeded = false;

				List<Combatant> targets = this.useOtherTargets ?
					this.otherTargets.GetCombatant(baseEvent) :
					evt.Action.target;

				if(evt.Action.HasTargets(targets))
				{
					float dmgFactor = 1;
					if(this.setFactor)
					{
						dmgFactor = this.dmgFactor.GetValue(baseEvent);
					}

					if(this.reconsume)
					{
						evt.Action.ConsumeDone = false;
					}
					evt.Action.Calculate(targets, dmgFactor, this.animate,
						baseEvent.Variables, baseEvent.SelectedData);
				}

				if(evt.Action.results != null)
				{
					BattleActionResult result = evt.Action.results.GetResult();
					if(BattleActionResult.Critical == result && this.useCritical)
					{
						tmpNext = this.nextCritical;
					}
					else if(BattleActionResult.Miss == result && this.useMiss)
					{
						tmpNext = this.nextMiss;
					}
					else if(BattleActionResult.Block == result && this.useBlock)
					{
						tmpNext = this.nextBlock;
					}
				}
			}

			baseEvent.StepFinished(tmpNext);
		}


		/*
		============================================================================
		Node next functions
		============================================================================
		*/
		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Next";
			}
			else if(index == 1)
			{
				if(this.useCritical)
				{
					return "Critical";
				}
				else if(this.useMiss)
				{
					return "Miss";
				}
				else
				{
					return "Block";
				}
			}
			else if(index == 2)
			{
				if(this.useCritical && this.useMiss)
				{
					return "Miss";
				}
				else
				{
					return "Block";
				}
			}
			else if(index == 3)
			{
				return "Block";
			}
			return "";
		}

		public override int GetNextCount()
		{
			int count = 1;
			if(this.useCritical)
			{
				count++;
			}
			if(this.useMiss)
			{
				count++;
			}
			if(this.useBlock)
			{
				count++;
			}
			return count;
		}

		public override int GetNext(int index)
		{
			if(index == 0)
			{
				return this.next;
			}
			else if(index == 1)
			{
				if(this.useCritical)
				{
					return this.nextCritical;
				}
				else if(this.useMiss)
				{
					return this.nextMiss;
				}
				else
				{
					return this.nextBlock;
				}
			}
			else if(index == 2)
			{
				if(this.useCritical && this.useMiss)
				{
					return this.nextMiss;
				}
				else
				{
					return this.nextBlock;
				}
			}
			else if(index == 3)
			{
				return this.nextBlock;
			}
			return -1;
		}

		public override void SetNext(int index, int next)
		{
			if(index == 0)
			{
				this.next = next;
			}
			else if(index == 1)
			{
				if(this.useCritical)
				{
					this.nextCritical = next;
				}
				else if(this.useMiss)
				{
					this.nextMiss = next;
				}
				else
				{
					this.nextBlock = next;
				}
			}
			else if(index == 2)
			{
				if(this.useCritical && this.useMiss)
				{
					this.nextMiss = next;
				}
				else
				{
					this.nextBlock = next;
				}
			}
			else if(index == 3)
			{
				this.nextBlock = next;
			}
		}
	}

	[ORKEditorHelp("Consume Costs", "Consumes the use costs of the action " +
		"(e.g. ability use costs, consumes the used item).\n" +
		"The 'Calculate' step will no longer consume the use costs when they've already been consumed. " +
		"This step will consume them each time it's used.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle/Action")]
	public class ConsumeCostsStep : BaseEventStep
	{
		public ConsumeCostsStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(baseEvent is BattleEvent)
			{
				((BattleEvent)baseEvent).Action.ConsumeCosts(baseEvent.Variables, baseEvent.SelectedData);
			}
			baseEvent.StepFinished(this.next);
		}
	}

	[ORKEditorHelp("No Time Consume", "The action will not consume time, i.e.:" +
		"In 'Active Time Battles', the timebar will not be reduced by the actions costs.\n" +
		"In 'Turn Based Battles', the action cost will not reduce the actions per turn.\n" +
		"In 'Turn Based Battles' using 'Multi Turns', the 'Turn Value' will not be reset after the action.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle/Action")]
	public class NoTimeConsumeStep : BaseEventStep
	{
		public NoTimeConsumeStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(baseEvent is BattleEvent)
			{
				((BattleEvent)baseEvent).Action.ConsumeTime = false;
			}
			baseEvent.StepFinished(this.next);
		}
	}

	[ORKEditorHelp("Damage Multiplier", "Set the damage multiplier of the battle action this battle event belongs to.\n" +
		"The damage multiplier is used to manipulate the outcome of every damage calculation (e.g. Calculate step), e.g.:\n" +
		"- A damage multiplier of 1 means normal damage.\n" +
		"- A damage multiplier of 2 means double damage.\n" +
		"- A damage multiplier of 0.5 means half damage.\n" +
		"You can use this step to e.g. increase the damage of an attack when a " +
		"button was pressed (Wait for Button step).", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle/Action")]
	public class DamageMultiplierStep : BaseEventStep
	{
		[ORKEditorHelp("Multiply By", "The damage multiplier will be set to this number, e.g.:\n" +
			"- A damage multiplier of 1 means normal damage.\n" +
			"- A damage multiplier of 2 means double damage.\n" +
			"- A damage multiplier of 0.5 means half damage.", "")]
		public float mult = 1;

		public DamageMultiplierStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(baseEvent is BattleEvent)
			{
				((BattleEvent)baseEvent).Action.damageMultiplier = this.mult;
			}
			baseEvent.StepFinished(this.next);
		}
	}

	[ORKEditorHelp("Can Use Action", "Checks if the user can use the action of the battle event.\n" +
		"If the user can use the action, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle/Action", "Check/Battle")]
	public class CanUseActionStep : BaseEventCheckStep
	{
		public CanUseActionStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(baseEvent is BattleEvent &&
				((BattleEvent)baseEvent).Action.CanUse())
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}
	}

	[ORKEditorHelp("Activate Damage Dealer", "Activates/deactivates DamageDealer components of the user of the " +
		"battle action (or spawned prefabs).\n" +
		"DamageDealers can't do damage without being activated.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle/Action")]
	public class ActivateDamageDealerStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="Activate/Deactivate On")]
		public EventObjectSetting onObject = new EventObjectSetting();


		// activation
		[ORKEditorHelp("Activate", "The DamageDealer components will be set active (i.e. they will do damage).\n" +
			"If disabled, the DamageDealer components will be set inactive (i.e. they wont do damage).", "")]
		[ORKEditorInfo(separator=true)]
		public bool activate = true;


		// tags
		[ORKEditorHelp("Use Action Tags", "Use the tags of the battle action " +
			"(i.e. the tags defined in an ability's or item's 'Damage Dealer Settings').", "")]
		[ORKEditorInfo(separator=true, labelText="Activation Tags")]
		public bool useActionTags = true;

		[ORKEditorHelp("Tag", "Define the tag that will be used to activate/deactivate the damage dealer.\n" +
			"Damage dealers that match one of the defined tags will be activated/deactivated, " +
			"ignoring if they're set up for this ability/item or not.", "")]
		[ORKEditorInfo(hideName=true)]
		[ORKEditorArray(false, "Add Tag", "Adds a tag.\n" +
			"Damage dealers that match one of the defined tags will be activated/deactivated, " +
			"ignoring if they're set up for this ability/item or not.", "",
			"Remove", "Removes this tag.", "", isHorizontal=true)]
		public string[] activationTags = new string[0];


		// audio settings
		[ORKEditorHelp("Add Audio", "An audio clip is played on the game object hit by the damage dealer (when doing damage).", "")]
		[ORKEditorInfo(separator=true, labelText="Audio Settings")]
		[ORKEditorLayout("activate", true)]
		public bool addAudio = false;

		[ORKEditorHelp("Use Action Audio", "Use the audio settings of the battle action " +
			"(i.e. the audio settings defined in an ability's or item's 'Damage Dealer Settings').", "")]
		[ORKEditorLayout("addAudio", true)]
		public bool useActionAudio = false;

		[ORKEditorHelp("Use Sound Type", "The target combatant's defined sound of a selected sound type will be used.", "")]
		[ORKEditorLayout("useActionAudio", false)]
		public bool useSoundType = false;

		[ORKEditorHelp("Sound Type", "Select the sound type that will be played.", "")]
		[ORKEditorInfo(ORKDataType.SoundType)]
		[ORKEditorLayout("useSoundType", true)]
		public int soundTypeID = 0;

		[ORKEditorHelp("Use Target", "Use the target combatant's audio clip.\n" +
			"If disabled, the user combatant's audio clip is used.", "")]
		public bool targetSound = false;

		[ORKEditorHelp("Audio Clip", "Select the audio clip that will be played.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=3)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public int id3 = 0;

		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2, autoInit=true)]
		public PlayAudioSettings audio;


		// prefab settings
		[ORKEditorHelp("Add Prefab", "A prefab is spawned on the position it hit an object when doing damage.\n" +
			"This prefab can't be used by the battle event.\n" +
			"Please note that only using 'Collision' to deal damage will use the hit position, " +
			"using 'Trigger' will use the position of the combatant.", "")]
		[ORKEditorInfo(separator=true, labelText="Prefab Settings")]
		public bool addPrefab = false;

		[ORKEditorHelp("Use Action Prefab", "Use the prefab settings of the battle action " +
			"(i.e. the prefab settings defined in an ability's or item's 'Damage Dealer Settings').", "")]
		[ORKEditorLayout("addPrefab", true)]
		public bool useActionPrefab = false;

		[ORKEditorHelp("Prefab", "Select the prefab that will be used.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=2)]
		[ORKEditorLayout("useActionPrefab", false)]
		public int id4 = 0;

		[ORKEditorHelp("Mount Prefab", "Parent/mount the prefab to the combatant that was hit.", "")]
		public bool mountPrefab = false;

		[ORKEditorHelp("Stop Particles", "Particles emitting from the prefab will stop emitting.", "")]
		public bool stopParticles = false;

		[ORKEditorHelp("Stop After (s)", "The time in seconds before emitting particles will stop.", "")]
		[ORKEditorLayout("stopParticles", true, endCheckGroup=true)]
		public float stopAfter = 1;

		[ORKEditorHelp("Destroy After (s)", "The spawned prefab will be destroyed after the set amout of time in seconds.\n" +
			"Set to 0 if you don't want to destroy it after time.", "")]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		public float after = 0;

		public ActivateDamageDealerStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(baseEvent is BattleEvent)
			{
				BattleEvent evt = baseEvent as BattleEvent;

				List<GameObject> list = this.onObject.GetObject(baseEvent);

				for(int i = 0; i < list.Count; i++)
				{
					if(list[i] != null)
					{
						DamageDealer[] damage = list[i].GetComponentsInChildren<DamageDealer>();
						for(int j = 0; j < damage.Length; j++)
						{
							if(this.activate)
							{
								DamageDealerActivation ddActivation = evt.Action.GetDamageDealerActivation();

								damage[j].SetAction(evt.Action);

								if(this.addAudio)
								{
									if(this.useActionAudio)
									{
										if(ddActivation != null)
										{
											ddActivation.AddAudio(damage[j], evt.Action.user);
										}
									}
									else if(this.useSoundType)
									{
										if(this.targetSound)
										{
											damage[j].SetAudioType(this.soundTypeID, this.audio);
										}
										else
										{
											damage[j].SetAudioClip(
												evt.Action.user.Animations.GetAudioClip(this.soundTypeID), this.audio);
										}
									}
									else
									{
										damage[j].SetAudioClip(evt.GetAudioClip(this.id3), this.audio);
									}
								}

								if(this.addPrefab)
								{
									if(this.useActionPrefab)
									{
										if(ddActivation != null)
										{
											ddActivation.AddPrefab(damage[j]);
										}
									}
									else
									{

										damage[j].SetPrefab(evt.GetPrefab(this.id4), this.mountPrefab, 
											this.after, this.stopParticles ? this.stopAfter : -1);
									}
								}
							}
							else
							{
								damage[j].SetAction(null);
							}

							if(this.useActionTags)
							{
								string[] tags = evt.Action.GetActivationTags();
								if(tags.Length > 0)
								{
									List<string> tmp = new List<string>(tags);
									tmp.AddRange(this.activationTags);
									damage[j].SetDamageActive(this.activate, tmp.ToArray());
								}
								else
								{
									damage[j].SetDamageActive(this.activate, this.activationTags);
								}
							}
							else
							{
								damage[j].SetDamageActive(this.activate, this.activationTags);
							}
						}
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
	}

	[ORKEditorHelp("Clear Battle Actions", "All battle actions that haven't started will be removed from the running battle.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle/Action")]
	public class ClearBattleActionsStep : BaseEventStep
	{
		public ClearBattleActionsStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			ORK.Battle.Actions.ClearStack();
			baseEvent.StepFinished(this.next);
		}
	}

	[ORKEditorHelp("Stop Battle Actions", "All battle actions that are currently performing will be stopped.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle/Action")]
	public class StopBattleActionsStep : BaseEventStep
	{
		public StopBattleActionsStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			ORK.Battle.Actions.StopActiveActions();
			baseEvent.StepFinished(this.next);
		}
	}

	[ORKEditorHelp("Change Action Targets", "A combatant is added or removed as a target of the action, " +
		"or all targets can be removed.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle/Action")]
	public class AddTargetToActionStep : BaseEventStep
	{
		[ORKEditorHelp("Change Type", "Select how the targets will be changed:\n" +
			"- Add: A combatant will be added as a target.\n" +
			"- Remove: A combatant will be removed as a target.\n" +
			"- Clear: All targets will be removed.\n" +
			"- Set: A combatant will be set as a target, removing previous targets.", "")]
		public ListChangeType changeType = ListChangeType.Add;

		[ORKEditorInfo(separator=true, labelText="Target Object")]
		[ORKEditorLayout("changeType", ListChangeType.Clear,
			elseCheckGroup=true, endCheckGroup=true, autoInit=true)]
		public EventObjectSetting targetObject;

		public AddTargetToActionStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(baseEvent is BattleEvent)
			{
				BattleEvent battleEvent = baseEvent as BattleEvent;

				if(ListChangeType.Clear == this.changeType)
				{
					battleEvent.Action.target.Clear();
				}
				else
				{
					if(ListChangeType.Set == this.changeType)
					{
						battleEvent.Action.target.Clear();
					}
					List<Combatant> list = this.targetObject.GetCombatant(baseEvent);
					for(int i = 0; i < list.Count; i++)
					{
						if(ListChangeType.Add == this.changeType ||
							ListChangeType.Set == this.changeType)
						{
							battleEvent.Action.target.Add(list[i]);
						}
						else if(ListChangeType.Remove == this.changeType)
						{
							battleEvent.Action.target.Remove(list[i]);
						}
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.changeType.ToString();
		}
	}

	[ORKEditorHelp("Use Battle Action", "Tries to use a battle action or adds it to a combatant's next action list.\n" +
		"Using the action depends on the current state of the combatant and battle system - " +
		"it might not be used at all.\n" +
		"Adding the action to a combatant's next action list will use the action the " +
		"next time the combatant can perform an action (i.e. called through the battle system).", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Battle/Action")]
	public class UseBattleActionStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="Action Settings")]
		public ActionSelection actionSettings = new ActionSelection();

		// options
		[ORKEditorHelp("Init New Turn", "Initializes a new turn for the user combatant.\n" +
			"This will e.g. increase the turn counter, update status effects and reuse blocks.", "")]
		[ORKEditorInfo(separator=true)]
		public bool newTurn = false;

		[ORKEditorHelp("Check Time", "Checks if the combatant can use the action due " +
			"to timebar consume (in 'Active Time Battles') or if it's the combatant's turn " +
			"('Turn Based Battles' and 'Phase Battles').", "")]
		public bool checkTime = true;

		[ORKEditorHelp("No Use Costs", "The action will not consume use costs, " +
			"e.g. consume items or use cost status changes.", "")]
		public bool noUseCosts = false;

		[ORKEditorHelp("No Time Consume", "The action will not consume time, i.e.:" +
			"In 'Active Time Battles', the timebar will not be reduced by the actions costs.\n" +
			"In 'Turn Based Battles', the action cost will not reduce the actions per turn.\n" +
			"In 'Turn Based Battles' using 'Multi Turns', the 'Turn Value' will not be reset after the action.", "")]
		public bool noTimeConsume = false;

		// next action
		[ORKEditorHelp("Add Next Action", "Add the battle action as next action of the combatant.\n" +
			"The action will be performed the next time the combatant " +
			"is able to choose an action (i.e. when it's his turn).\n" +
			"Depending on the current battle system type, it can take " +
			"a while before the action is performed.\n" +
			"If disabled, the combatant will try to use the action immediately.", "")]
		[ORKEditorInfo(separator=true)]
		public bool addNextAction = false;

		[ORKEditorHelp("Next Action Change", "Select how the battle action will be added to the combatant's next action list:\n" +
			"- Add: The action will be added at the end of the list (i.e. it will be used after the previously added actions where used).\n" +
			"- Set: The combatant will remove all current actions on the list before adding the action " +
			"(i.e. it will be used next, previously added actions will be gone).\n" +
			"- First: The action will be added at the start of the list (i.e. it will be used next).", "")]
		[ORKEditorLayout("addNextAction", true, endCheckGroup=true)]
		public NextBattleActionChange nextActionChange = NextBattleActionChange.Add;


		// user
		[ORKEditorInfo(separator=true, labelText="User")]
		public EventObjectSetting userObject = new EventObjectSetting();


		//target
		[ORKEditorHelp("Set Target", "Set the target(s) of the action " +
			"(only for ability and item actions).\n" +
			"If disabled, the action will use auto targeting.", "")]
		[ORKEditorInfo(separator=true, labelText="Target")]
		public bool setTarget = false;

		[ORKEditorLayout("setTarget", true, endCheckGroup=true, autoInit=true)]
		public EventObjectSetting targetObject;

		public UseBattleActionStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> user = this.userObject.GetCombatant(baseEvent);

			for(int i = 0; i < user.Count; i++)
			{
				if(user[i] != null)
				{
					BaseAction action = this.actionSettings.GetAction(user[i], this.checkTime);

					if(action != null)
					{
						if(this.setTarget &&
							(action is AbilityAction || action is ItemAction))
						{
							action.SetTargets(this.targetObject.GetCombatant(baseEvent));
						}

						if(this.noUseCosts)
						{
							action.ConsumeDone = true;
						}
						if(this.noTimeConsume)
						{
							action.ConsumeTime = false;
						}

						if(this.addNextAction)
						{
							user[i].Actions.AddNextAction(action, this.nextActionChange);
						}
						else
						{
							user[i].Actions.Add(action, this.newTurn);
						}
					}
				}
			}

			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.userObject.GetInfoText() + ": " + this.actionSettings.GetInfoText();
		}
	}

	[ORKEditorHelp("Use Ability Calculation", "Uses an ability (without animation) - " +
		"the user/target changes will be calculated.\n" +
		"The user doesn't need to know the ability or ability level.\n" +
		"Counters wont work when used in a game event (i.e. not a battle event tied to a battle action).", "")]
	[ORKEventStep(typeof(BattleEvent), typeof(GameEvent))]
	[ORKNodeInfo("Battle/Action", "Combatant/Ability")]
	public class UseAbilityCalculationStep : BaseEventStep
	{
		// ability
		[ORKEditorHelp("Ability", "Select the ability that will be used.", "")]
		[ORKEditorInfo(ORKDataType.Ability, labelText="Ability Settings")]
		public int abilityID = 0;

		[ORKEditorHelp("Action Type", "Select the action type of the ability:\n" +
			"- Base Attack: Used as a base attack.\n" +
			"- Counter Attack: Used as a counter attack.\n" +
			"- Ability: Used as an ability.\n" +
			"Please note that this can have influence on the used ability, " +
			"e.g. due to the target blocking base attack damage.", "")]
		public AbilityActionType actionType = AbilityActionType.Ability;

		[ORKEditorHelp("Ability Level", "The level of the ability that will be used.", "")]
		[ORKEditorLimit(1, false)]
		public int abilityLevel = 1;

		[ORKEditorHelp("Consume Costs", "The use costs of the ability will be consumed.", "")]
		public bool useCosts = false;

		[ORKEditorHelp("Animate Target", "Automatically play an animation according to the result of the " +
			"calculation (e.g. damage, evade, etc.).\n" +
			"The animation that will be played is defined in the combatant's animation settings.", "")]
		public bool animate = true;

		[ORKEditorHelp("Do Counters", "Targets can counter the ability (if set up accordingly).", "")]
		public bool doCounters = true;

		[ORKEditorHelp("Set Damage Factor", "The outcome of the calculation will be multiplied by a defined value, e.g.:\n" +
			"- A damage factor of 1 means normal damage.\n" +
			"- A damage factor of 2 means double damage.\n" +
			"- A damage factor of 0.5 means half damage.", "")]
		[ORKEditorInfo(separator=true, labelText="Damage Factor")]
		public bool setFactor = false;

		[ORKEditorLayout("setFactor", true, endCheckGroup=true, autoInit=true)]
		public EventFloat dmgFactor;


		// user
		[ORKEditorInfo(separator=true, labelText="User")]
		public EventObjectSetting userObject = new EventObjectSetting();


		//target
		[ORKEditorInfo(separator=true, labelText="Target")]
		public EventObjectSetting targetObject = new EventObjectSetting();

		public UseAbilityCalculationStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			BaseAction action = baseEvent is BattleEvent ?
				((BattleEvent)baseEvent).Action : null;

			List<Combatant> user = this.userObject.GetCombatant(baseEvent);
			List<Combatant> target = this.targetObject.GetCombatant(baseEvent);

			for(int i = 0; i < user.Count; i++)
			{
				if(user[i] != null)
				{
					ORK.Abilities.Get(this.abilityID).Use(user[i], target, this.animate,
						action, this.actionType, this.doCounters, this.useCosts, this.abilityLevel,
						this.setFactor ? this.dmgFactor.GetValue(baseEvent) : 1,
						action != null ? action.damageMultiplier : 1,
						baseEvent.Variables, baseEvent.SelectedData);
				}
			}

			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.Abilities.GetName(this.abilityID);
		}
	}

	[ORKEditorHelp("Use Item Calculation", "Uses an item (without animation) - " +
		"the user/target changes will be calculated.", "")]
	[ORKEventStep(typeof(BattleEvent), typeof(GameEvent))]
	[ORKNodeInfo("Battle/Action", "Combatant/Inventory")]
	public class UseItemCalculationStep : BaseEventStep
	{
		// ability
		[ORKEditorHelp("Item", "Select the item that will be used.", "")]
		[ORKEditorInfo(ORKDataType.Item, labelText="Item Settings")]
		public int itemID = 0;

		[ORKEditorHelp("Consume Item", "If the user has the item in his inventory, " +
			"it will be consumed (when set up accordingly).", "")]
		public bool consume = false;

		[ORKEditorHelp("Animate Target", "Automatically play an animation according to the result of the " +
			"calculation (e.g. damage, evade, etc.).\n" +
			"The animation that will be played is defined in the combatant's animation settings.", "")]
		public bool animate = true;

		[ORKEditorHelp("Set Damage Factor", "The outcome of the calculation will be multiplied by a defined value, e.g.:\n" +
			"- A damage factor of 1 means normal damage.\n" +
			"- A damage factor of 2 means double damage.\n" +
			"- A damage factor of 0.5 means half damage.", "")]
		[ORKEditorInfo(separator=true, labelText="Damage Factor")]
		public bool setFactor = false;

		[ORKEditorLayout("setFactor", true, endCheckGroup=true, autoInit=true)]
		public EventFloat dmgFactor;


		// user
		[ORKEditorInfo(separator=true, labelText="User")]
		public EventObjectSetting userObject = new EventObjectSetting();


		//target
		[ORKEditorInfo(separator=true, labelText="Target")]
		public EventObjectSetting targetObject = new EventObjectSetting();

		public UseItemCalculationStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			BaseAction action = baseEvent is BattleEvent ?
				((BattleEvent)baseEvent).Action : null;

			List<Combatant> user = this.userObject.GetCombatant(baseEvent);
			List<Combatant> target = this.targetObject.GetCombatant(baseEvent);

			for(int i = 0; i < user.Count; i++)
			{
				if(user[i] != null)
				{
					ORK.Items.Get(this.itemID).Use(null, user[i], target,
						this.animate, this.consume, action,
						this.setFactor ? this.dmgFactor.GetValue(baseEvent) : 1,
						action != null ? action.damageMultiplier : 1,
						baseEvent.Variables, baseEvent.SelectedData);
				}
			}

			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return ORK.Items.GetName(this.itemID);
		}
	}

	[ORKEditorHelp("End Battle Action", "The battle action will end after this event.\n" +
		"All battle events of the action that would run after this event will be removed.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle/Action")]
	public class EndBattleActionStep : BaseEventStep
	{
		public EndBattleActionStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			BaseAction action = baseEvent is BattleEvent ?
				((BattleEvent)baseEvent).Action : null;

			if(action != null)
			{
				action.ClearEvents();
			}

			baseEvent.StepFinished(this.next);
		}
	}

	[ORKEditorHelp("Enable Auto Attack", "Enables or disables auto attacks of a combatant.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Battle/Action")]
	public class EnableAutoAttackStep : BaseEventStep
	{
		[ORKEditorHelp("Auto Attack", "Select the auto attack state:\n" +
			"- Enable: Auto attacks will be enabled.\n" +
			"- Disable: Auto attacks will be disabled.\n" +
			"- Toggle: Toggles the state, i.e. enabled auto attacks will be disabled, " +
			"disabled auto attacks willbe enabled.", "")]
		public EnableSelection autoAttack = EnableSelection.Enable;


		// user
		[ORKEditorInfo(separator=true, labelText="Combatant")]
		public EventObjectSetting usedObject = new EventObjectSetting();

		public EnableAutoAttackStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = this.usedObject.GetCombatant(baseEvent);

			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					bool tmp = list[i].Battle.EnableAutoAttack;
					ValueHelper.Enable(ref tmp, this.autoAttack);
					list[i].Battle.EnableAutoAttack = tmp;
				}
			}

			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.usedObject.GetInfoText() + ": " + this.autoAttack;
		}
	}

	[ORKEditorHelp("End Turn", "Ends the turn of a combatant.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Battle/Action")]
	public class EndTurnStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="Combatant")]
		public EventObjectSetting usedObject = new EventObjectSetting();

		public EndTurnStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = this.usedObject.GetCombatant(baseEvent);

			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					list[i].Battle.EndTurnCommand();
				}
			}

			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.usedObject.GetInfoText();
		}
	}
}
