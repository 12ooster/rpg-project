﻿
using UnityEngine;
using System.Collections.Generic;
using System;

namespace ORKFramework
{
	public class AbilityResearchItem : BaseData, IContent
	{
		[ORKEditorHelp("Ability", "Select the ability that can be learned.", "")]
		[ORKEditorInfo(ORKDataType.Ability)]
		public int abilityID = 0;

		[ORKEditorHelp("Ability Level", "The level of the ability that will be learned.", "")]
		[ORKEditorLimit(1, false)]
		public int level = 1;

		[ORKEditorHelp("Group Ability", "The ability will be learned by the group, " +
			"i.e. all group members will have access to it.\n" +
			"If disabled, only one combatant learns the ability.", "")]
		public bool isGroupAbility = false;

		[ORKEditorHelp("Show Notification", "Learning the ability will display a notification.", "")]
		public bool showNotification = true;

		[ORKEditorHelp("Show Console", "Learning the ability will be displayed in the console.", "")]
		public bool showConsole = true;

		public AbilityResearchItem()
		{

		}

		public bool HasLearned(Combatant combatant)
		{
			if(this.isGroupAbility)
			{
				return combatant.Group.Abilities.HasLearned(this.abilityID, this.level);
			}
			else
			{
				return combatant.Abilities.HasLearned(this.abilityID, this.level);
			}
		}

		public Portrait GetPortrait()
		{
			Ability ability = ORK.Abilities.Get(this.abilityID);
			if(ability.usePortrait)
			{
				return ability.portrait;
			}
			return null;
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public int ID
		{
			get { return this.abilityID; }
		}

		public int TypeID
		{
			get { return ORK.Abilities.Get(this.abilityID).abilityType; }
		}

		public string GetName()
		{
			return new AbilityShortcut(this.abilityID, this.level, AbilityActionType.Ability).GetName();
		}

		public string GetDescription()
		{
			return new AbilityShortcut(this.abilityID, this.level, AbilityActionType.Ability).GetDescription();
		}

		public string GetIconTextCode()
		{
			return new AbilityShortcut(this.abilityID, this.level, AbilityActionType.Ability).GetIconTextCode();
		}

		public Texture GetIcon()
		{
			return new AbilityShortcut(this.abilityID, this.level, AbilityActionType.Ability).GetIcon();
		}

		public GUIContent GetContent()
		{
			return new AbilityShortcut(this.abilityID, this.level, AbilityActionType.Ability).GetContent();
		}

		public IContentSimple GetTypeContent()
		{
			return ORK.AbilityTypes.Get(ORK.Abilities.Get(this.abilityID).abilityType);
		}

		public string GetInfo(Combatant c)
		{
			return "";
		}


		/*
		============================================================================
		Learning functions
		============================================================================
		*/
		public void ResearchFinished(Combatant combatant)
		{
			if(this.isGroupAbility)
			{
				combatant.Group.Abilities.Learn(this.abilityID, this.level, 
					this.showNotification, this.showConsole);
			}
			else
			{
				combatant.Abilities.Learn(this.abilityID, this.level, 
					this.showNotification, this.showConsole);
			}
		}
	}
}
