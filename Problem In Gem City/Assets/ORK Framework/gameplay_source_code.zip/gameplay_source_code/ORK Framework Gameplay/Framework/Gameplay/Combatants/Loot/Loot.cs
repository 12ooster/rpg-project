
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class Loot : BaseIndexData
	{
		// base settings
		[ORKEditorHelp("Name", "The name of the AI movement.", "")]
		[ORKEditorInfo("Base Settings", "Set the name and base settings of the battle AI.", "",
			expandWidth=true)]
		public string name = "";

		[ORKEditorHelp("Use First Found Table", "Use the first loot table that matches the combatant's level.\n" +
			"If disabled, all matching loot tables will be used.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool useFirstFoundTable = true;


		// loot tables
		[ORKEditorArray(false, "Add Loot Table", "Adds a loot table.\n" +
			"Loot tables define the loot of a combatant within a certain level range.", "",
			"Remove", "Removes this loot table.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Loot Table", "A loot table defines a combatant's loot within a certain level range.", ""
		})]
		public LootTable[] table = new LootTable[0];

		public Loot()
		{

		}

		public Loot(string name)
		{
			this.name = name;
		}

		public void Get(ref List<IShortcut> list, Combatant combatant, bool useAddType)
		{
			if(combatant != null)
			{
				for(int i = 0; i < this.table.Length; i++)
				{
					if(this.table[i].Get(ref list, combatant, useAddType))
					{
						if(this.useFirstFoundTable)
						{
							return;
						}
					}
				}
			}
		}
	}
}
