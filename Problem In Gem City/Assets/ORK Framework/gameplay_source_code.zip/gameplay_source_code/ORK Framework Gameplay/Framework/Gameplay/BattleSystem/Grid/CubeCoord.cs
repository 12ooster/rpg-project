﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class CubeCoord : BaseData
	{
		public int x = 0;

		public int y = 0;

		public int z = 0;

		public CubeCoord()
		{

		}

		public CubeCoord(int x, int y, int z)
		{
			this.x = x;
			this.y = y;
			this.z = z;
		}

		public CubeCoord(CubeCoord coord)
		{
			this.x = coord.x;
			this.y = coord.y;
			this.z = coord.z;
		}

		public bool IsZero
		{
			get { return this.x == 0 && this.y == 0 && this.z == 0; }
		}

		public override string ToString()
		{
			return "(x=" + this.x + ",y=" + this.y + ",z=" + this.z + ")";
		}


		/*
		============================================================================
		Get offset functions
		============================================================================
		*/
		public void ToOffset(ref int row, ref int column)
		{
			if(BattleGridType.Square == ORK.BattleSystem.gridSettings.type)
			{
				row = this.x;
				column = this.y;
			}
			else if(BattleGridType.Hexagonal == ORK.BattleSystem.gridSettings.type)
			{
				if(HexagonalGridType.HorizontalEven == ORK.BattleSystem.gridSettings.hexagonalType)
				{
					this.TotHorizontalEven(ref row, ref column);
				}
				else if(HexagonalGridType.HorizontalOdd == ORK.BattleSystem.gridSettings.hexagonalType)
				{
					this.TotHorizontalOdd(ref row, ref column);
				}
				else if(HexagonalGridType.VerticalEven == ORK.BattleSystem.gridSettings.hexagonalType)
				{
					this.ToVerticalEven(ref row, ref column);
				}
				else if(HexagonalGridType.VerticalOdd == ORK.BattleSystem.gridSettings.hexagonalType)
				{
					this.ToVerticalOdd(ref row, ref column);
				}
			}
		}

		public void TotHorizontalEven(ref int row, ref int column)
		{
			column = this.x + (this.z + (this.z % 2)) / 2;
			row = this.z;
		}

		public void TotHorizontalOdd(ref int row, ref int column)
		{
			column = this.x + (this.z - (this.z % 2)) / 2;
			row = this.z;
		}

		public void ToVerticalEven(ref int row, ref int column)
		{
			column = this.x;
			row = this.z + (this.x + (this.x % 2)) / 2;
		}

		public void ToVerticalOdd(ref int row, ref int column)
		{
			column = this.x;
			row = this.z + (this.x - (this.x % 2)) / 2;
		}


		/*
		============================================================================
		Conversion functions
		============================================================================
		*/
		public static CubeCoord FromOffset(int row, int column)
		{
			if(BattleGridType.Square == ORK.BattleSystem.gridSettings.type)
			{
				return new CubeCoord(row, column, 0);
			}
			else
			{
				CubeCoord cube = new CubeCoord();

				if(BattleGridType.Hexagonal == ORK.BattleSystem.gridSettings.type)
				{
					if(HexagonalGridType.HorizontalEven == ORK.BattleSystem.gridSettings.hexagonalType)
					{
						cube.x = column - (row + (row & 1)) / 2;
						cube.z = row;
						cube.y = -cube.x - cube.z;
					}
					else if(HexagonalGridType.HorizontalOdd == ORK.BattleSystem.gridSettings.hexagonalType)
					{
						cube.x = column - (row - (row % 2)) / 2;
						cube.z = row;
						cube.y = -cube.x - cube.z;
					}
					else if(HexagonalGridType.VerticalEven == ORK.BattleSystem.gridSettings.hexagonalType)
					{
						cube.x = column;
						cube.z = row - (column + (column % 2)) / 2;
						cube.y = -cube.x - cube.z;
					}
					else if(HexagonalGridType.VerticalOdd == ORK.BattleSystem.gridSettings.hexagonalType)
					{
						cube.x = column;
						cube.z = row - (column - (column % 2)) / 2;
						cube.y = -cube.x - cube.z;
					}
				}
				return cube;
			}
		}


		/*
		============================================================================
		Distance functions
		============================================================================
		*/
		public int Distance(CubeCoord target)
		{
			if(BattleGridType.Square == ORK.BattleSystem.gridSettings.type)
			{
				return this.DistanceSquare(target);
			}
			else if(BattleGridType.Hexagonal == ORK.BattleSystem.gridSettings.type)
			{
				return this.DistanceHexagonal(target);
			}
			return 0;
		}

		public int DistanceSquare(CubeCoord target)
		{
			return Mathf.Abs(this.x - target.x) + Mathf.Abs(this.y - target.y);
		}

		public int DistanceSquare(int row, int column)
		{
			return Mathf.Abs(this.x - row) + Mathf.Abs(this.y - column);
		}

		public int DistanceHexagonal(CubeCoord target)
		{
			return (Mathf.Abs(this.x - target.x) +
				Mathf.Abs(this.y - target.y) +
				Mathf.Abs(this.z - target.z)) / 2;
		}

		public static int Distance(CubeCoord origin, CubeCoord target)
		{
			if(BattleGridType.Square == ORK.BattleSystem.gridSettings.type)
			{
				return CubeCoord.DistanceSquare(origin, target);
			}
			else if(BattleGridType.Hexagonal == ORK.BattleSystem.gridSettings.type)
			{
				return CubeCoord.DistanceHexagonal(origin, target);
			}
			return 0;
		}

		public static int DistanceSquare(CubeCoord origin, CubeCoord target)
		{
			return Mathf.Abs(origin.x - target.x) + Mathf.Abs(origin.y - target.y);
		}

		public static int DistanceSquare(int originRow, int originColumn, int targetRow, int targetColumn)
		{
			return Mathf.Abs(originRow - targetRow) + Mathf.Abs(originColumn - targetColumn);
		}

		public static int DistanceHexagonal(CubeCoord origin, CubeCoord target)
		{
			return (Mathf.Abs(origin.x - target.x) +
				Mathf.Abs(origin.y - target.y) +
				Mathf.Abs(origin.z - target.z)) / 2;
		}


		/*
		============================================================================
		Rotation functions
		============================================================================
		*/
		public CubeCoord Rotate(int turns)
		{
			if(BattleGridType.Square == ORK.BattleSystem.gridSettings.type)
			{
				return this.RotateSquare(turns);
			}
			else if(BattleGridType.Hexagonal == ORK.BattleSystem.gridSettings.type)
			{
				return this.RotateHexagonal(turns);
			}
			return new CubeCoord(this);
		}

		public CubeCoord RotateSquare(int turns)
		{
			turns -= (turns / 4) * 4;

			if(turns == 3 || turns == -1)
			{
				return new CubeCoord(-this.y, this.x, 0);
			}
			else if(turns == 2 || turns == -2)
			{
				return new CubeCoord(-this.x, -this.y, 0);
			}
			else if(turns == 1 || turns == -3)
			{
				return new CubeCoord(this.y, -this.x, 0);
			}

			return new CubeCoord(this);
		}

		public CubeCoord RotateHexagonal(int turns)
		{
			turns -= (turns / 6) * 6;

			if(turns == 1 || turns == -5)
			{
				return new CubeCoord(-this.z, -this.x, -this.y);
			}
			else if(turns == 2 || turns == -4)
			{
				return new CubeCoord(this.y, this.z, this.x);
			}
			else if(turns == 3 || turns == -3)
			{
				return new CubeCoord(-this.x, -this.y, -this.z);
			}
			else if(turns == 4 || turns == -2)
			{
				return new CubeCoord(this.z, this.x, this.y);
			}
			else if(turns == 5 || turns == -1)
			{
				return new CubeCoord(-this.y, -this.z, -this.x);
			}

			return new CubeCoord(this);
		}


		/*
		============================================================================
		Math functions
		============================================================================
		*/
		public static CubeCoord operator +(CubeCoord c1, CubeCoord c2)
		{
			return new CubeCoord(c1.x + c2.x, c1.y + c2.y, c1.z + c2.z);
		}

		public static CubeCoord operator -(CubeCoord c1, CubeCoord c2)
		{
			return new CubeCoord(c1.x - c2.x, c1.y - c2.y, c1.z - c2.z);
		}

		public static CubeCoord operator *(CubeCoord c, int scale)
		{
			return new CubeCoord(c.x * scale, c.y * scale, c.z * scale);
		}

		public static CubeCoord Round(Vector3 coord)
		{
			int rx = Mathf.RoundToInt(coord.x);
			int ry = Mathf.RoundToInt(coord.y);
			int rz = Mathf.RoundToInt(coord.z);

			float x_diff = Mathf.Abs(rx - coord.x);
			float y_diff = Mathf.Abs(ry - coord.y);
			float z_diff = Mathf.Abs(rz - coord.z);

			if(x_diff > y_diff && x_diff > z_diff)
			{
				rx = -ry - rz;
			}
			else if(y_diff > z_diff)
			{
				ry = -rx - rz;
			}
			else
			{
				rz = -rx - ry;
			}

			return new CubeCoord(rx, ry, rz);
		}

		public static Vector3 Lerp(CubeCoord origin, CubeCoord target, float time)
		{
			return new Vector3(
				origin.x + (target.x - origin.x) * time,
				origin.y + (target.y - origin.y) * time,
				origin.z + (target.z - origin.z) * time);
		}
	}
}
