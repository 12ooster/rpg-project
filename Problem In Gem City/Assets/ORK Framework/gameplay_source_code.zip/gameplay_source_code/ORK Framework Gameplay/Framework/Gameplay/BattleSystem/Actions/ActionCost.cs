﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ActionCost : BaseData
	{
		[ORKEditorHelp("Use Remaining", "Uses the remaining actions per turn (APT) - " + 
			"the defined value will be the minimum required APT a combatant must have.\n" + 
			"E.g.: A combatant has 1.5 APT left and 1 is the minimum requirement, the action can be performed and costs 1.5 APT.\n" + 
			"A combatant has 0.5 APT left and 1 is the minimum requirement, the action can't be performed.", "")]
		public bool useRemaining = false;

		public FloatValue cost = new FloatValue(1);

		public ActionCost()
		{

		}

		public float GetCost(Combatant user)
		{
			float value = cost.GetValue(user, user, null, null);
			if(this.useRemaining)
			{
				float tmp = user.Battle.ActionBar - user.Battle.UsedActionBar;
				if(value < tmp)
				{
					value = tmp;
				}
			}
			return value;
		}

		public float GetCost(Combatant user, VariableHandler localVariables, SelectedDataHandler selectedData)
		{
			float value = cost.GetValue(user, user, localVariables, selectedData);
			if(this.useRemaining)
			{
				float tmp = user.Battle.ActionBar - user.Battle.UsedActionBar;
				if(value < tmp)
				{
					value = tmp;
				}
			}
			return value;
		}
	}
}
