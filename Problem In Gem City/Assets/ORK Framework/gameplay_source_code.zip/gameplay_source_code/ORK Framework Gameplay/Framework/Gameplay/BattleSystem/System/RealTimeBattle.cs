
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class RealTimeBattle : BaseBattle
	{
		// menu keys
		[ORKEditorHelp("Battle Menu Key", "Key to call the battle menu.\n" +
			"The key is only used in 'Real Time' type battles.", "")]
		[ORKEditorInfo("Real Time Settings", "Settings for the real time battle system.\n" +
			"A combatant will perform actions at any time.", "",
			ORKDataType.InputKey, labelText="Battle Menu Settings")]
		public int battleMenuKey = 0;

		[ORKEditorHelp("2nd Press Closes", "A second press on the same menu key closes the menu.", "")]
		public bool keyCloses = false;

		[ORKEditorHelp("Pause On Menu", "The battle is paused while displaying the battle menu " +
			"(i.e. the battle pauses while you select your actions).", "")]
		public bool menuPause = true;

		[ORKEditorHelp("Freeze Action", "The game freezes (animations, moves, etc. will stop) when the battle menu is called.", "")]
		[ORKEditorLayout("menuPause", true)]
		public bool freezeAction = false;

		[ORKEditorHelp("Change Time Scale", "Change the time scale while displaying a battle menu.\n" +
			"This can be used to slow down or speed up the battle.", "")]
		[ORKEditorLayout(elseCheckGroup=true)]
		public bool setMenuTimeScale = false;

		[ORKEditorHelp("Time Scale", "Define the time scale that will be used while displaying the battle menu.\n" +
			"A time scale of 1 is normal speed, 0.5 is half speed, 2 is double speed.\n" +
			"A time scale of 0 will freeze time (same as using freeze action).", "")]
		[ORKEditorLayout("setMenuTimeScale", true, endCheckGroup=true, endGroups=2)]
		[ORKEditorLimit(0.0f, false)]
		public float menuTimeScale = 1;


		// options
		[ORKEditorHelp("Can Counter", "Combatants can counter attack in 'Real Time' battles.\n" +
			"If disabled, combatants can't counter attack.", "")]
		[ORKEditorInfo(separator=true, labelText="Options")]
		public bool canCounter = true;

		[ORKEditorHelp("Defeat on Player Death", "The player is defeated if the player combatant is dead.\n" +
			"If disabled, the whole player battle group has to be dead.", "")]
		public bool defeatPlayerDead = false;

		[ORKEditorHelp("Death Immediately", "A combatant's death action will be performed immediately when dying.\n" +
			"If disabled, the death action will be performed after the current action ends.", "")]
		public bool deathImmediately = false;

		[ORKEditorHelp("End Immediately", "The battle will end immediately, stopping the actions that are still performing.\n" +
			"If disabled, the battle will wait for all active actions to end.", "")]
		public bool endImmediately = false;

		[ORKEditorHelp("Defend First", "The defend command will perform before other actions.\n" +
			"Doesn't take already performing actions into account.", "")]
		public bool defendFirst = false;

		[ORKEditorHelp("Block Menu", "In-game menus are blocked while the player is in a battle.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public bool blockMenu = false;


		// auto attack settings
		[ORKEditorHelp("Can Auto Attack", "Combatants can perform auto attacks.", "")]
		[ORKEditorInfo("Auto Attack Settings", "Set if combatants can use auto attacks in a battle of this system type.", "")]
		public bool canAutoAttack = true;

		[ORKEditorHelp("Menu Block Auto Atk", "A combatant's auto attack is blocked while his battle menu is opened.\n" +
			"Another combatant's menu wont block auto attacks.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("canAutoAttack", true, endCheckGroup=true)]
		public bool blockAutoAttackMenu = false;


		// leave area gains collection
		[ORKEditorHelp("Collect Gains", "Collect battle gains when leaving a real time area.", "")]
		[ORKEditorInfo("Leave Area Settings", "Defines what happens when the player leaves a real time battle area.", "")]
		public bool leaveAreaCollectGains = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("leaveAreaCollectGains", true, endCheckGroup=true, autoInit=true)]
		public CollectBattleGainsSettings collectGainsLeaveArea;

		public RealTimeBattle()
		{

		}

		public override bool CanCounter
		{
			get { return this.canCounter; }
		}

		public override bool DeathImmediately
		{
			get { return this.deathImmediately; }
		}

		public override bool EndImmediately
		{
			get { return this.endImmediately; }
		}

		public override bool IsMenuBackAllowed
		{
			get { return true; }
		}

		public override bool MenuBlockAutoAttack
		{
			get
			{
				return this.blockAutoAttackMenu;
			}
		}

		public override bool CanAutoAttack
		{
			get
			{
				return this.canAutoAttack;
			}
		}

		public override bool DefeatOnPlayerDeath
		{
			get { return this.defeatPlayerDead; }
		}

		public override bool DefendFirst
		{
			get { return this.defendFirst; }
		}

		public override Combatant SelectingCombatant
		{
			get { return ORK.Game.ActiveGroup.Leader; }
		}


		/*
		============================================================================
		Tick functions
		============================================================================
		*/
		public override void Tick()
		{
			// battle menu key
			Combatant player = ORK.Game.ActiveGroup.Leader;
			if(player != null &&
				!player.Dead)
			{
				if(ORK.InputKeys.Get(this.battleMenuKey).GetButton())
				{
					if(player.Actions.CanChoose)
					{
						player.Actions.Choose(true, true);
					}
					else if(player.Actions.IsChoosing &&
						this.keyCloses)
					{
						player.EndBattleMenu(true);
					}
				}
			}

			// actions
			this.PerformNextAction3();
		}

		public override bool DoCombatantTick()
		{
			if(this.menuPause && ORK.Battle.MenuActive)
			{
				return false;
			}
			return base.DoCombatantTick();
		}


		/*
		============================================================================
		Action handling functions
		============================================================================
		*/
		public override void ActionAdded(BaseAction action)
		{
			this.PerformNextAction3();
		}

		public override void ActionUnshifted(BaseAction action)
		{
			this.PerformNextAction3();
		}

		protected override void PerformNextAction3()
		{
			if(!ORK.Battle.BattleEnd)
			{
				if(ORK.Battle.Actions.Has())
				{
					BaseAction action = ORK.Battle.Actions.NextPerformable();
					if(action != null && !action.IsCastingAbility())
					{
						this.PerformAction(action);
					}
				}
			}
		}
	}
}
