
namespace ORKFramework.UI
{
	public class BaseBMItem : BMItem
	{
		private BMItemType type = BMItemType.End;

		public BaseBMItem(ChoiceContent content, BMItemType type)
		{
			this.content = content;
			this.type = type;
		}

		public override bool ActiveCheck(Combatant owner)
		{
			bool tmp = this.content.Active;
			if(BMItemType.Defend == this.type)
			{
				this.content.Active = !owner.Status.BlockDefend &&
					owner.Battle.CanUse(ORK.Battle.GetDefendActionCost(owner));
			}
			else if(BMItemType.Escape == this.type)
			{
				this.content.Active = ORK.Battle.CanEscape && !owner.Status.BlockEscape &&
					owner.Battle.CanUse(ORK.Battle.GetEscapeActionCost(owner));
			}
			else if(BMItemType.End == this.type)
			{
				this.content.Active = owner.Battle.CanUse(ORK.Battle.GetNoneActionCost(owner));
			}
			else if(BMItemType.GridMove == this.type)
			{
				this.content.Active = owner.Battle.GridMoveRange > 0 &&
					!owner.Status.StopMove &&
					!owner.Status.StopMovement &&
					owner.Battle.GridMoveState == GridMoveState.Available;
			}
			else if(BMItemType.GridOrientation == this.type)
			{
				this.content.Active = !owner.Status.StopMove &&
					!owner.Status.StopMovement;
			}
			return tmp != this.content.Active;
		}

		public override bool Accepted(Combatant owner)
		{
			if(BMItemType.Defend == this.type)
			{
				owner.BattleMenu.AddAction(new DefendAction(owner));
			}
			else if(BMItemType.Escape == this.type)
			{
				owner.BattleMenu.AddAction(new EscapeAction(owner));
			}
			else if(BMItemType.End == this.type)
			{
				owner.Battle.EndTurnCommand();
			}
			else if(BMItemType.GridMove == this.type)
			{
				owner.BattleMenu.StartGridMoveSelection(null, true);
			}
			else if(BMItemType.GridOrientation == this.type)
			{
				owner.BattleMenu.StartGridOrientationSelection(null, true);
			}
			else if(BMItemType.GridExamine == this.type)
			{
				owner.BattleMenu.StartGridExamine(owner.GridCell, true);
			}
			return true;
		}
	}
}
