﻿
using UnityEngine;
using ORKFramework;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.AI
{
	public class MoveAIChange : BaseData
	{
		// change move AI
		[ORKEditorHelp("Change Move AI", "Change the used move AI.", "")]
		public bool changeMoveAI = false;

		[ORKEditorHelp("Move AI", "Select the move AI that will be used.", "")]
		[ORKEditorInfo(ORKDataType.MoveAI)]
		[ORKEditorLayout("changeMoveAI", true, endCheckGroup=true)]
		public int moveID = 0;


		// change use mode
		[ORKEditorHelp("Change Use Mode", "Change the use mode of the move AI.", "")]
		[ORKEditorInfo(separator=true)]
		public bool changeUseMode = false;

		[ORKEditorHelp("Use Mode", "Select the use mode of the move AI:\n" +
			"- Auto: Automatically uses the different behaviours (e.g. hunting, fleeing).\n" +
			"- Idle: Forces idle mode, only following waypoints (if used).\n" +
			"- Hunt: Forces hunting.\n" +
			"- Flee: Forces fleeing.\n" +
			"- Caution: Forces caution.", "")]
		[ORKEditorLayout("changeUseMode", true, endCheckGroup=true)]
		public MoveAIUseMode useMode = MoveAIUseMode.Auto;

		public MoveAIChange()
		{

		}

		public bool Change(Combatant combatant)
		{
			bool changed = false;

			if(combatant != null &&
				combatant.MoveAI != null)
			{
				if(this.changeMoveAI)
				{
					combatant.MoveAI.ChangeMoveAI(this.moveID);
					changed = true;
				}

				if(this.changeUseMode)
				{
					combatant.MoveAI.useMode = this.useMode;
					changed = true;
				}
			}
			return changed;
		}
	}
}
