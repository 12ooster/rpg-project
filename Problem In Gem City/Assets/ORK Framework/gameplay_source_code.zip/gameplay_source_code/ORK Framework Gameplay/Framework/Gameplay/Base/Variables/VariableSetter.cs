
using UnityEngine;

namespace ORKFramework
{
	[System.Serializable]
	public class VariableSetter : BaseData
	{
		[ORKEditorArray(false, "Add Game Variable", "Adds a game variable to the list.", "",
			"Remove", "Removes the game variable from the list.", "", isMove=true, isCopy=true,
			foldout=true, foldoutText=new string[] {
				"Change Variable", "Define the game variable that will be changed.", ""
		})]
		public ChangeGameVariable[] gameVariable = new ChangeGameVariable[0];

		public VariableSetter()
		{

		}

		public bool HasChanges
		{
			get { return this.gameVariable.Length > 0; }
		}

		/*
		============================================================================
		Set functions
		============================================================================
		*/
		public void SetVariables()
		{
			this.SetVariables(ORK.Game.Variables);
		}

		public void SetVariables(VariableHandler handler)
		{
			for(int i = 0; i < this.gameVariable.Length; i++)
			{
				this.gameVariable[i].Change(handler);
			}
		}
	}
}
