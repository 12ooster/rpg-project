
using UnityEngine;
using ORKFramework.Animations;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Combatant Animation", "Plays or stops an animation on a combatant.\n" +
		"If the selected object isn't a combatant, or the selected animation type isn't defined, " +
		"no animation will be played/stopped.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Animation + Audio/Animation", "Combatant/Combatant")]
	public class CombatantAnimationStep : BaseEventStep
	{
		public EventObjectSetting animate = new EventObjectSetting();

		[ORKEditorHelp("Time Between (s)", "The time in seconds between animating two objects.\n" +
			"Only used if greater than 0 and more than one object will be animated.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;

		[ORKEditorHelp("Wait Between", "Wait for all objects to start animating before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;


		// animation
		[ORKEditorHelp("Stop", "Stops the animation.\n" +
			"If disabled, the animation will be played.", "")]
		[ORKEditorInfo(separator=true, labelText="Animation")]
		public bool stop = false;

		[ORKEditorHelp("Wait", "Wait until the animation has finished before the next step is executed.\n" +
			"Please note that there is no wait time if the played animation is a mecanim animation.", "")]
		[ORKEditorLayout(new string[] {"waitBetween", "stop"},
			new System.Object[] {true, false}, needed=Needed.All, endCheckGroup=true,
			setDefault=true, defaultValue=false)]
		public bool wait = false;

		[ORKEditorHelp("Animation Type", "Select the animation type that will be played.\n" +
			"If the combatant has no animation of this type, no animation will be played.", "")]
		[ORKEditorInfo(ORKDataType.AnimationType)]
		public int typeID = 0;


		// ingame
		private List<Combatant> list;

		private int index = 0;

		private float tmpTime = 0;

		public CombatantAnimationStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.tmpTime = 0;
			this.list = this.animate.GetCombatant(baseEvent);
			this.index = 0;

			if(this.list.Count > 0)
			{
				this.Continue(baseEvent);

				if(!this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}

		public override void Continue(BaseEvent baseEvent)
		{
			if(this.list[this.index] != null)
			{
				if(this.stop)
				{
					this.list[this.index].Animations.Stop(this.typeID);
				}
				else
				{
					AnimInfo info = this.list[this.index].Animations.Play(this.typeID);
					if(info.length > this.tmpTime)
					{
						this.tmpTime = info.length;
					}
				}
			}

			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					if(!this.stop && this.wait && this.tmpTime > 0)
					{
						baseEvent.StartTime(this.tmpTime, this.next);
					}
					else
					{
						baseEvent.StepFinished(this.next);
					}
				}
				// clear data
				this.list = null;
				this.index = 0;
				this.tmpTime = 0;
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return (this.stop ? "Stop " : "Play ") + ORK.AnimationTypes.GetName(this.typeID) +
				(this.wait ? " (wait)" : "");
		}
	}

	[ORKEditorHelp("Legacy Animation", "Plays or stops a legacy animation on a game object.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Animation + Audio/Animation")]
	public class LegacyAnimationStep : BaseEventStep
	{
		public EventObjectSetting animate = new EventObjectSetting();

		[ORKEditorHelp("Time Between (s)", "The time in seconds between animating two objects.\n" +
			"Only used if greater than 0 and more than one object will be animated.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;

		[ORKEditorHelp("Wait Between", "Wait for all objects to start animating before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;


		// animation
		[ORKEditorHelp("Wait", "Wait until the animation has finished before the next step is executed.", "")]
		[ORKEditorInfo(separator=true, labelText="Animation")]
		[ORKEditorLayout("waitBetween", true, endCheckGroup=true)]
		public bool wait = false;

		public LegacyAnimationBase legacy = new LegacyAnimationBase();


		// ingame
		private List<GameObject> list;

		private int index = 0;

		private float tmpTime = 0;

		public LegacyAnimationStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.tmpTime = 0;
			this.list = this.animate.GetObject(baseEvent);
			this.index = 0;

			if(this.list.Count > 0)
			{
				this.Continue(baseEvent);

				if(!this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}

		public override void Continue(BaseEvent baseEvent)
		{
			Animation animation = ComponentHelper.GetInChildren<Animation>(this.list[this.index]);
			if(animation != null)
			{
				this.legacy.Init(ComponentHelper.GetCombatant(this.list[this.index]), animation);
				AnimInfo info = this.legacy.Play(animation);
				if(info.length > this.tmpTime)
				{
					this.tmpTime = info.length;
				}
			}

			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					if(this.wait && this.tmpTime > 0)
					{
						baseEvent.StartTime(this.tmpTime, this.next);
					}
					else
					{
						baseEvent.StepFinished(this.next);
					}
				}
				// clear data
				this.list = null;
				this.index = 0;
				this.tmpTime = 0;
			}
		}

		public override bool ExecuteOnStop
		{
			get { return LegacyAnimationPlayMode.Stop == this.legacy.playType; }
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.legacy.playType + " " + this.legacy.name + (this.wait ? " (wait)" : "");
		}
	}

	[ORKEditorHelp("Mecanim Animation", "Changes parameters of a mecanim animator on a game object.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Animation + Audio/Animation")]
	public class MecanimAnimationStep : BaseEventStep
	{
		public EventObjectSetting animate = new EventObjectSetting();

		[ORKEditorHelp("Time Between (s)", "The time in seconds between animating two objects.\n" +
			"Only used if greater than 0 and more than one object will be animated.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float timeBetween = 0;

		[ORKEditorHelp("Wait Between", "Wait for all objects to start animating before executing the next step.\n" +
			"If disabled, the next step will execute immediately while this step continues.", "")]
		public bool waitBetween = true;


		// play
		[ORKEditorHelp("Use Play", "Use Animator.Play to play the animation directly.\n" +
			"If disabled, you have to set up parameters that will be set on the animator.", "")]
		[ORKEditorInfo(separator=true)]
		public bool usePlay = false;

		[ORKEditorHelp("State Name", "The name of the animation state (without layer name).", "")]
		[ORKEditorInfo(expandWidth=true)]
		[ORKEditorLayout("usePlay", true)]
		public string name = "";

		[ORKEditorHelp("Layer Index", "The index of the AnimatorController layer the animation state is on.", "")]
		public int layer = 0;

		[ORKEditorHelp("Set Normalized Time", "Set the normalized time of the animation state when playing it.", "")]
		public bool setNormalizedTime = false;

		[ORKEditorHelp("Normalized Time", "The normalized time the animation state will be set to when playing (0-1).\n" +
			"E.g. 1 will be the end of the animation, 0.5 in the middle of the animation.", "")]
		[ORKEditorLayout("setNormalizedTime", true, endCheckGroup=true, endGroups=2)]
		[ORKEditorLimit(0.0f, 1.0f)]
		public float normalizedTime = 0;


		// set parameters
		[ORKEditorArray(false, "Add Parameter", "Adds a parameter that will be set.", "",
			"Remove", "Removes this parameter.", "",
			foldout=true, foldoutText=new string[] {"Set Parameter", "The parameter will be set to the defined value.", ""})]
		public MecanimParameter[] parameter = new MecanimParameter[0];


		// ingame
		private List<GameObject> list;

		private int index = 0;

		public MecanimAnimationStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			this.list = this.animate.GetObject(baseEvent);
			this.index = 0;

			if(this.list.Count > 0)
			{
				this.Continue(baseEvent);

				if(!this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}

		public override void Continue(BaseEvent baseEvent)
		{
			Animator animator = ComponentHelper.GetInChildren<Animator>(this.list[this.index]);
			if(animator != null)
			{
				for(int i = 0; i < this.parameter.Length; i++)
				{
					this.parameter[i].Set(animator);
				}

				if(this.usePlay)
				{
					if(this.setNormalizedTime)
					{
						animator.Play(this.name, this.layer, this.normalizedTime);
					}
					else
					{
						animator.Play(this.name, this.layer);
					}
				}
			}

			this.index++;
			// execute next
			if(this.index < this.list.Count)
			{
				if(this.timeBetween > 0)
				{
					baseEvent.StartContinue(this.timeBetween, this);
				}
				else
				{
					this.Continue(baseEvent);
				}
			}
			// finish
			else
			{
				if(this.waitBetween)
				{
					baseEvent.StepFinished(this.next);
				}
				// clear data
				this.list = null;
				this.index = 0;
			}
		}

		public override bool ExecuteOnStop
		{
			get { return true; }
		}
	}

	[ORKEditorHelp("Auto Animation", "Enables or disables the auto move animation of a combatant.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Animation + Audio/Animation")]
	public class AutoAnimationEventStep : BaseEventStep
	{
		[ORKEditorHelp("Enable/Disable", "If enabled, the auto move animation of a combatant will be turned on.\n" +
			"If disabled, the auto move animation of a combatant will be turned off.", "")]
		public bool autoMoveAnimation;

		[ORKEditorInfo(separator=true, labelText="Used Object")]
		public EventObjectSetting usedObject = new EventObjectSetting();

		public AutoAnimationEventStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = this.usedObject.GetCombatant(baseEvent);

			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					list[i].Animations.autoMoveAnimation = this.autoMoveAnimation;
				}
			}

			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.usedObject.GetInfoText() + ": " +
				(this.autoMoveAnimation ? "Enable" : "Disable");
		}
	}

	[ORKEditorHelp("Death Animation", "Plays the death animation on dead combatants.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Animation + Audio/Animation", "Combatant/Combatant")]
	public class DeathAnimationEventStep : BaseEventStep
	{
		[ORKEditorHelp("Stop Move Animations", "Stop the combatant's idle, walk, run and sprint animations.", "")]
		public bool stopMoveAnimations = false;

		[ORKEditorHelp("Stop Auto Animation", "Disables the auto move animation of the combatant.", "")]
		public bool stopAutoAnimation = false;

		[ORKEditorHelp("Wait", "Wait for the death animation to finish before executing the next step.", "")]
		public bool wait = false;


		// object
		[ORKEditorInfo(separator=true, labelText="Combatant Object")]
		public EventObjectSetting usedObject = new EventObjectSetting();

		public DeathAnimationEventStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			float tmpTime = 0;
			List<Combatant> list = this.usedObject.GetCombatant(baseEvent);

			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null && list[i].Dead)
				{
					if(this.stopMoveAnimations)
					{
						list[i].Animations.Stop(ORK.AnimationTypes.sprintID);
						list[i].Animations.Stop(ORK.AnimationTypes.runID);
						list[i].Animations.Stop(ORK.AnimationTypes.walkID);
						list[i].Animations.Stop(ORK.AnimationTypes.idleID);
					}
					if(this.stopAutoAnimation)
					{
						list[i].Animations.autoMoveAnimation = false;
					}

					AnimInfo info = list[i].Animations.Play(ORK.AnimationTypes.deathID);
					if(info != null && tmpTime < info.length)
					{
						tmpTime = info.length;
					}
				}
			}

			if(this.wait && tmpTime > 0)
			{
				baseEvent.StartTime(tmpTime, this.next);
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.usedObject.GetInfoText() +
				(this.wait ? " (wait)" : "");
		}
	}

	[ORKEditorHelp("Revive Animation", "Plays the revive animation on dead combatants.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Animation + Audio/Animation", "Combatant/Combatant")]
	public class ReviveAnimationEventStep : BaseEventStep
	{
		[ORKEditorHelp("Start Auto Animation", "Enables the auto move animation of the combatant.", "")]
		public bool startAutoAnimation = false;

		[ORKEditorHelp("Wait", "Wait for the death animation to finish before executing the next step.", "")]
		public bool wait = false;


		// object
		[ORKEditorInfo(separator=true, labelText="Combatant Object")]
		public EventObjectSetting usedObject = new EventObjectSetting();

		public ReviveAnimationEventStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			float tmpTime = 0;
			List<Combatant> list = this.usedObject.GetCombatant(baseEvent);

			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null && list[i].Dead)
				{
					if(this.startAutoAnimation)
					{
						list[i].Animations.autoMoveAnimation = true;
					}

					AnimInfo info = list[i].Animations.Play(ORK.AnimationTypes.reviveID);
					if(info != null && tmpTime < info.length)
					{
						tmpTime = info.length;
					}
				}
			}

			if(this.wait && tmpTime > 0)
			{
				baseEvent.StartTime(tmpTime, this.next);
			}
			else
			{
				baseEvent.StepFinished(this.next);
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.usedObject.GetInfoText() +
				(this.wait ? " (wait)" : "");
		}
	}
}
