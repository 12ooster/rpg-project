﻿
using UnityEngine;
using System.Collections.Generic;
using System;

namespace ORKFramework
{
	public class ResearchTreeSetting : BaseLanguageData, IContent
	{
		[ORKEditorHelp("Research Type", "Select the research type of this research tree.", "")]
		[ORKEditorInfo("Base Settings", "The base settings of this research tree.", "",
			ORKDataType.ResearchType)]
		public int researchTypeID = 0;

		[ORKEditorHelp("Auto Remove", "Automatically remove this research tree " +
			"from a combatant when it was fully researched.\n" +
			"A research tree is fully researched if all research items have been " +
			"fully researched (i.e. reached their limited times).\n" +
			"If a research item doesn't limit the number of times it can be researched, " +
			"the research tree will never be fully researched.", "")]
		public bool autoRemove = false;

		[ORKEditorHelp("Show Notification", "Auto removing this research tree will display a notification.", "")]
		[ORKEditorLayout("autoRemove", true)]
		public bool removeShowNotification = true;

		[ORKEditorHelp("Show Console", "Auto removing this research tree will display a console text.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool removeShowConsole = true;


		// research limit
		[ORKEditorHelp("Limit Research", "Researching items is limited to a defined number at the same time.\n" +
			"If disabled, there's no limit to how many research items can be researched simultaneously.", "")]
		[ORKEditorInfo(separator=true, labelText="Research Limit")]
		public bool limitResearch = true;

		[ORKEditorHelp("Global Limit", " The research limit takes all research of the combatant into account.\n" +
			"E.g. if the limit is 1 and another research tree is currently researching an item, " +
			"this tree can't start researching an item.", "")]
		[ORKEditorLayout("limitResearch", true)]
		public bool globalLimit = true;

		[ORKEditorHelp("Research Limit", "Define how many research items can be researched at the same time.", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout(endCheckGroup=true)]
		public int researchLimit = 1;


		// portrait
		[ORKEditorHelp("Use Portrait", "This research tree has a portrait that can be displayed in menus.", "")]
		[ORKEditorInfo("Portrait Settings", "The research tree can display a portrait in menus when it's selected.", "")]
		public bool usePortrait = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("usePortrait", true, endCheckGroup=true, autoInit=true)]
		public Portrait portrait;


		// notifications
		[ORKEditorHelp("Own Notifications", "This research tree overrides the default research notifications.", "")]
		[ORKEditorInfo("Notification Settings", "Research trees can override the default research notifications.", "")]
		public bool ownNotifications = false;

		[ORKEditorInfo("Research Tree Added", "This notification will be displayed " +
			"when a research tree was added to the player combatants.", "",
			endFoldout=true)]
		[ORKEditorLayout("ownNotifications", true, autoInit=true)]
		public ResearchTreeNotification researchTreeAdded;

		[ORKEditorInfo("Research Tree Removed", "This notification will be displayed " +
			"when a research tree was removed from the player combatants.", "",
			endFoldout=true)]
		[ORKEditorLayout(autoInit=true)]
		public ResearchTreeNotification researchTreeRemoved;

		[ORKEditorInfo("Research Started", "This notification will be displayed " +
			"when a player combatant started research of a research item.", "",
			endFoldout=true)]
		[ORKEditorLayout(autoInit=true)]
		public ResearchItemNotification researchStarted;

		[ORKEditorInfo("Research Canceled", "This notification will be displayed " +
			"when a player combatant canceled research of a research item.", "",
			endFoldout=true)]
		[ORKEditorLayout(autoInit=true)]
		public ResearchItemNotification researchCanceled;

		[ORKEditorInfo("Research Finished", "This notification will be displayed " +
			"when a player combatant finished research of a research item.", "",
			endFoldout=true, endFolds=2)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public ResearchItemNotification researchFinished;


		// console texts
		[ORKEditorHelp("Own Console Texts", "This research tree overrides the default console texts.", "")]
		[ORKEditorInfo("Console Texts", "A research tree can override the default console texts.", "")]
		public bool ownConsoleTexts = false;

		[ORKEditorInfo("Add Research Tree Text", "The text displayed for adding this research tree.", "",
			endFoldout=true)]
		[ORKEditorLayout("ownConsoleTexts", true, autoInit=true)]
		public ConsoleTextLearning consoleAddTree;

		[ORKEditorInfo("Remove Research Tree Text", "The text displayed for removing this research tree.", "",
			endFoldout=true)]
		[ORKEditorLayout(autoInit=true)]
		public ConsoleTextLearning consoleRemoveTree;

		[ORKEditorInfo("Start Research Text", "The text displayed for starting research of a research item of this research tree.", "",
			endFoldout=true)]
		[ORKEditorLayout(autoInit=true)]
		public ConsoleTextResearchItem consoleStartResearch;

		[ORKEditorInfo("Cancel Research Text", "The text displayed for canceling research of a research item of this research tree.", "",
			endFoldout=true)]
		[ORKEditorLayout(autoInit=true)]
		public ConsoleTextResearchItem consoleCancelResearch;

		[ORKEditorInfo("Finish Research Text", "The text displayed for finishing research of a research item of this research tree.", "",
			endFoldout=true, endFolds=2)]
		[ORKEditorLayout(endCheckGroup=true, autoInit=true)]
		public ConsoleTextResearchItem consoleFinishResearch;


		// research item
		[ORKEditorArray(false, "Add Research Item", "Adds a research item.", "",
			"Remove", "Removes this reserach item.", "", isCopy=true,
			callbackAdd="researchitem:added", callbackRemove="researchitem:removed",
			foldout=true, foldoutText=new string[] {
				"Research Item", "Select what will be researched, the learning costs and requirements.", ""
		})]
		public ResearchItemSetting[] item = new ResearchItemSetting[0];

		public ResearchTreeSetting()
		{

		}

		public ResearchTreeSetting(string name) : base(name)
		{

		}


		/*
		============================================================================
		Notification/console functions
		============================================================================
		*/
		public void ShowTreeAdded(Combatant user, ResearchTree tree, bool showNotification, bool showConsole)
		{
			// notification
			if(showNotification)
			{
				if(this.ownNotifications)
				{
					this.researchTreeAdded.Show(user, tree);
				}
				else
				{
					ORK.InventorySettings.notifications.researchTreeAdded.Show(user, tree);
				}
			}
			// console
			if(showConsole && ORK.ConsoleSettings.displayResearch)
			{
				if(this.ownConsoleTexts)
				{
					this.consoleAddTree.PrintLearnRange(user, this);
				}
				else
				{
					ORK.ConsoleSettings.addResearchTree.PrintLearnRange(user, this);
				}
			}
		}

		public void ShowTreeRemoved(Combatant user, ResearchTree tree, bool showNotification, bool showConsole)
		{
			// notification
			if(showNotification)
			{
				if(this.ownNotifications)
				{
					this.researchTreeRemoved.Show(user, tree);
				}
				else
				{
					ORK.InventorySettings.notifications.researchTreeRemoved.Show(user, tree);
				}
			}
			// console
			if(showConsole && ORK.ConsoleSettings.displayResearch)
			{
				if(this.ownConsoleTexts)
				{
					this.consoleRemoveTree.PrintLearnRange(user, this);
				}
				else
				{
					ORK.ConsoleSettings.removeResearchTree.PrintLearnRange(user, this);
				}
			}
		}

		public void ShowResearchStarted(Combatant user, ResearchItem item)
		{
			// notification
			if(this.ownNotifications)
			{
				this.researchStarted.Show(user, item);
			}
			else
			{
				ORK.InventorySettings.notifications.researchStarted.Show(user, item);
			}
			// console
			if(ORK.ConsoleSettings.displayResearch)
			{
				if(this.ownConsoleTexts)
				{
					this.consoleStartResearch.Print(user, item);
				}
				else
				{
					ORK.ConsoleSettings.startResearch.Print(user, item);
				}
			}
		}

		public void ShowResearchCanceled(Combatant user, ResearchItem item)
		{
			// notification
			if(this.ownNotifications)
			{
				this.researchCanceled.Show(user, item);
			}
			else
			{
				ORK.InventorySettings.notifications.researchCanceled.Show(user, item);
			}
			// console
			if(ORK.ConsoleSettings.displayResearch)
			{
				if(this.ownConsoleTexts)
				{
					this.consoleCancelResearch.Print(user, item);
				}
				else
				{
					ORK.ConsoleSettings.cancelResearch.Print(user, item);
				}
			}
		}

		public void ShowResearchFinished(Combatant user, ResearchItem item)
		{
			// notification
			if(this.ownNotifications)
			{
				this.researchFinished.Show(user, item);
			}
			else
			{
				ORK.InventorySettings.notifications.researchFinished.Show(user, item);
			}
			// console
			if(ORK.ConsoleSettings.displayResearch)
			{
				if(this.ownConsoleTexts)
				{
					this.consoleFinishResearch.Print(user, item);
				}
				else
				{
					ORK.ConsoleSettings.finishResearch.Print(user, item);
				}
			}
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public int ID
		{
			get { return this.realID; }
		}

		public int TypeID
		{
			get { return this.researchTypeID; }
		}

		public string GetName()
		{
			return this.languageInfo[ORK.Game.Language].GetName();
		}

		public string GetDescription()
		{
			return this.languageInfo[ORK.Game.Language].GetDescription();
		}

		public string GetIconTextCode()
		{
			return TextCode.ResearchTreeIcon + this.realID + "#";
		}

		public Texture GetIcon()
		{
			return this.languageInfo[ORK.Game.Language].GetIcon();
		}

		public GUIContent GetContent()
		{
			return this.languageInfo[ORK.Game.Language].GetContent();
		}

		public IContentSimple GetTypeContent()
		{
			return ORK.ResearchTypes.Get(this.researchTypeID);
		}

		public string GetInfo(Combatant c)
		{
			return "";
		}


		/*
		============================================================================
		Item content functions
		============================================================================
		*/
		public string GetName(int index)
		{
			if(index >= 0 && index < this.item.Length)
			{
				return this.item[index].GetName();
			}
			return "";
		}

		public string GetDescription(int index)
		{
			if(index >= 0 && index < this.item.Length)
			{
				return this.item[index].GetDescription();
			}
			return "";
		}

		public string GetIconTextCode(int index)
		{
			if(index >= 0 && index < this.item.Length)
			{
				return this.item[index].GetIconTextCode(this.RealID, index);
			}
			return "";
		}

		public Texture GetIcon(int index)
		{
			if(index >= 0 && index < this.item.Length)
			{
				return this.item[index].GetIcon();
			}
			return null;
		}

		public GUIContent GetContent(int index)
		{
			if(index >= 0 && index < this.item.Length)
			{
				return this.item[index].GetContent();
			}
			return null;
		}
	}
}
