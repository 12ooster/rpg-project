﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class TargetHighlight
	{
		private Combatant owner;

		private IShortcut shortcut;


		// target highlight
		private List<Combatant> availableTargets = new List<Combatant>();

		private List<Combatant> selectedTargets = new List<Combatant>();


		// grid cell highlight
		private List<BattleGridCellComponent> useRangeCells = new List<BattleGridCellComponent>();

		private List<BattleGridCellComponent> affectRangeCells = new List<BattleGridCellComponent>();

		public TargetHighlight(Combatant owner)
		{
			this.owner = owner;
		}

		public void Clear()
		{
			ORK.GUI.ForcedPreviewShortcut = null;
			this.shortcut = null;

			// clear old data
			if(this.useRangeCells.Count > 0)
			{
				this.HighlightUseRangeCells(false);
				this.useRangeCells.Clear();
			}
			if(this.affectRangeCells.Count > 0)
			{
				this.HighlightAffectRangeCells(false);
				this.affectRangeCells.Clear();
			}
			if(this.availableTargets.Count > 0)
			{
				this.availableTargets.Clear();
			}
			this.ClearSelectedTargets();
			ORK.BattleSettings.targetInformation.Close();
		}

		public List<Combatant> AvailableTargets
		{
			get { return this.availableTargets; }
		}


		/*
		============================================================================
		Target functions
		============================================================================
		*/
		public void SelectTarget(Combatant combatant, IShortcut shortcut)
		{
			this.ClearSelectedTargets();
			this.shortcut = shortcut;
			if(combatant != null)
			{
				this.selectedTargets.Add(combatant);
			}

			this.HighlightSelectedTargets();
		}

		public void SelectTargets(List<Combatant> list, IShortcut shortcut)
		{
			this.ClearSelectedTargets();
			this.shortcut = shortcut;
			this.selectedTargets.AddRange(list);

			if(ORK.MenuSettings.preview.targetSelectionPreview &&
				shortcut != null)
			{
				ORK.GUI.ForcedPreviewShortcut = new PreviewSelection(
					this.owner, this.availableTargets, this.shortcut);
			}

			this.HighlightSelectedTargets();
		}

		private void HighlightSelectedTargets()
		{
			ORK.BattleSettings.targetInformation.Show(this.owner, this.selectedTargets, this.shortcut);

			TargetSettings targetSettings = null;
			if(ORK.Battle.Grid != null)
			{
				// ability
				if(this.shortcut is AbilityShortcut)
				{
					ActiveAbility activeLevel = ((AbilityShortcut)this.shortcut).GetActiveLevel();
					if(activeLevel != null)
					{
						targetSettings = activeLevel.targetSettings;
					}
				}
				// item
				else if(this.shortcut is ItemShortcut)
				{
					targetSettings = ((ItemShortcut)this.shortcut).Setting.targetSettings;
				}

				if(ORK.BattleSystem.gridSettings.useRangeTargetSelection &&
					targetSettings != null)
				{
					if(this.useRangeCells.Count > 0)
					{
						this.HighlightUseRangeCells(false);
						this.useRangeCells.Clear();
					}
					targetSettings.GetUseRangeCells(
						this.owner, ref this.useRangeCells, null);
					this.HighlightUseRangeCells(true);
				}

				if(ORK.BattleSystem.gridSettings.examine.ExamineTarget)
				{
					for(int i = 0; i < this.selectedTargets.Count; i++)
					{
						if(this.selectedTargets[i] != null &&
							this.selectedTargets[i].GridCell != null)
						{
							ORK.BattleSystem.gridSettings.SelectedCell = this.selectedTargets[i].GridCell;
							ORK.BattleSystem.gridSettings.examine.ExternalExamine(
								this.selectedTargets[i].GridCell,
								ORK.BattleSystem.gridSettings.examine.targetExamineCell,
								ORK.BattleSystem.gridSettings.examine.targetExamineCellCombatant);
							break;
						}
					}
				}
			}

			bool cam = false;
			for(int i = 0; i < this.selectedTargets.Count; i++)
			{
				if(this.selectedTargets[i] != null)
				{
					if(targetSettings != null &&
						ORK.BattleSystem.gridSettings.affectRangeTargetSelection &&
						!targetSettings.NoneTarget())
					{
						targetSettings.GetAffectRangeCells(
							this.selectedTargets[i], this.selectedTargets[i].GridCell,
							ref this.affectRangeCells, null);
					}

					TargetHelper.Blink(this.selectedTargets[i], true);

					if(!cam &&
						ORK.BattleSettings.camera.blockEventCams &&
						this.selectedTargets[i].GameObject != null)
					{
						ORK.BattleSettings.camera.SetSelection(this.selectedTargets[i].GameObject.transform);
						cam = true;
					}
				}
			}
			this.HighlightAffectRangeCells(true);
		}

		private void ClearSelectedTargets()
		{
			if(this.affectRangeCells.Count > 0)
			{
				this.HighlightAffectRangeCells(false);
				this.affectRangeCells.Clear();
			}
			if(this.selectedTargets.Count > 0)
			{
				for(int i = 0; i < this.selectedTargets.Count; i++)
				{
					TargetHelper.Blink(this.selectedTargets[i], false);
				}
				this.selectedTargets.Clear();
			}
		}


		/*
		============================================================================
		Action functions
		============================================================================
		*/
		public void SelectAction(IShortcut shortcut)
		{
			if(this.shortcut != shortcut)
			{
				this.Clear();
				this.shortcut = shortcut;

				this.UpdateData();

				if(ORK.MenuSettings.preview.actionSelectionPreview)
				{
					ORK.GUI.ForcedPreviewShortcut = new PreviewSelection(
						this.owner, this.availableTargets, this.shortcut);
				}

				if(this.shortcut != null &&
					ORK.Battle.Grid != null)
				{
					if(ORK.BattleSystem.gridSettings.useRangeActionSelection)
					{
						this.HighlightUseRangeCells(true);
					}
					if(ORK.BattleSystem.gridSettings.affectRangeActionSelection)
					{
						this.HighlightAffectRangeCells(true);
					}
				}
			}
		}

		public void AcceptAction(IShortcut shortcut)
		{
			if(this.shortcut != shortcut)
			{
				this.Clear();
				this.shortcut = shortcut;

				this.UpdateData();
			}
		}

		public void AcceptHighlights()
		{
			if(this.shortcut != null)
			{
				this.owner.Shortcuts.Active = this.shortcut;

				if(ORK.MenuSettings.preview.targetSelectionPreview)
				{
					ORK.GUI.ForcedPreviewShortcut = new PreviewSelection(
						this.owner, this.availableTargets, this.shortcut);
				}

				if(ORK.Battle.Grid != null)
				{
					if(ORK.BattleSystem.gridSettings.useRangeTargetSelection)
					{
						this.HighlightUseRangeCells(true);
					}
					else
					{
						this.HighlightUseRangeCells(false);
					}

					this.HighlightAffectRangeCells(false);
				}
			}
		}

		private void UpdateData()
		{
			if(this.shortcut != null)
			{
				// ability
				if(this.shortcut is AbilityShortcut)
				{
					ActiveAbility activeLevel = ((AbilityShortcut)this.shortcut).GetActiveLevel();
					if(activeLevel != null)
					{
						if(ORK.Battle.Grid != null)
						{
							this.GetCells(activeLevel.targetSettings);
						}
						else
						{
							activeLevel.targetSettings.GetPossibleTargets(
								ref this.availableTargets, owner, null);
						}
					}
				}
				// item
				else if(this.shortcut is ItemShortcut)
				{
					if(ORK.Battle.Grid != null)
					{
						this.GetCells(((ItemShortcut)this.shortcut).Setting.targetSettings);
					}
					else
					{
						((ItemShortcut)this.shortcut).Setting.targetSettings.GetPossibleTargets(
							ref this.availableTargets, owner, null);
					}
				}
			}
		}


		/*
		============================================================================
		Cell functions
		============================================================================
		*/
		private void GetCells(TargetSettings targetSettings)
		{
			// get use range cells
			targetSettings.GetUseRangeCells(
				this.owner, ref this.useRangeCells, null);

			// get available targets
			for(int i = 0; i < this.useRangeCells.Count; i++)
			{
				if(this.useRangeCells[i] != null &&
					!this.useRangeCells[i].IsEmpty)
				{
					this.useRangeCells[i].GetCombatants(ref this.availableTargets, null);
				}
			}
			targetSettings.CheckTargets(this.owner, ref this.availableTargets);

			// get affect range cells
			if(!targetSettings.NoneTarget())
			{
				for(int i = 0; i < this.availableTargets.Count; i++)
				{
					targetSettings.GetAffectRangeCells(this.availableTargets[i],
						this.availableTargets[i].GridCell, ref this.affectRangeCells, null);
				}
			}
		}

		public void HighlightUseRangeCells(bool doHighlight)
		{
			if(ORK.BattleSystem.gridSettings.useRangeHighlight.enable &&
				this.useRangeCells.Count > 0)
			{
				if(doHighlight)
				{
					BattleGridHelper.Highlight(this.useRangeCells, GridHighlightType.UseRange);
				}
				else
				{
					BattleGridHelper.StopHighlight(this.useRangeCells, GridHighlightType.UseRange);
				}
			}
		}

		public void HighlightAffectRangeCells(bool doHighlight)
		{
			if(ORK.BattleSystem.gridSettings.affectRangeHighlight.enable &&
				this.affectRangeCells.Count > 0)
			{
				if(doHighlight)
				{
					BattleGridHelper.Highlight(this.affectRangeCells, GridHighlightType.AffectRange);
				}
				else
				{
					BattleGridHelper.StopHighlight(this.affectRangeCells, GridHighlightType.AffectRange);
				}
			}
		}
	}
}
