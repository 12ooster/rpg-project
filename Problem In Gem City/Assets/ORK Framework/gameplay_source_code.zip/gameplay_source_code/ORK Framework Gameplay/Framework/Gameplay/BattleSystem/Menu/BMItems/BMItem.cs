
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.UI
{
	public abstract class BMItem
	{
		public ChoiceContent content;
		
		public virtual void CreateDrag(Combatant owner)
		{
			
		}
		
		public virtual bool ActiveCheck(Combatant owner)
		{
			return false;
		}

		public virtual void Selected(Combatant owner)
		{
			owner.BattleMenu.TargetHighlight.Clear();
		}

		public abstract bool Accepted(Combatant owner);



		/*
		============================================================================
		Target functions
		============================================================================
		*/
		public virtual bool Contains(Combatant owner, Combatant target)
		{
			return false;
		}
		
		public virtual bool ContainsAny(Combatant owner, List<Combatant> list)
		{
			return false;
		}
		
		
		/*
		============================================================================
		Ability functions
		============================================================================
		*/
		public virtual bool ChangeUseLevel(int change, Combatant owner)
		{
			return false;
		}
	}
}
