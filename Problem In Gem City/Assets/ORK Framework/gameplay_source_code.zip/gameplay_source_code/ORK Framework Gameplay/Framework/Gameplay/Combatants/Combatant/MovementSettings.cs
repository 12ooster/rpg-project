
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class MovementSettings : BaseData
	{
		[ORKEditorHelp("Minimum Speed", "The minimum move speed of the combatant.\n" +
			"Since status effects and equipment can change the move speed you may want to set it to a " +
			"realistic value (e.g. 1-2), else the combatant could need a long time get anywhere.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float min = 1;
		
		[ORKEditorHelp("Maximum Speed", "The maximum move speed of the combatant.\n" +
			"Since status effects and equipment can change the move speed you may want to limit it to a " +
			"realistic value (e.g. 10-12), else the combatant could move too fast.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float max = 10;
		
		[ORKEditorHelp("Use Position Change", "The change of the combatant's position will be used to " +
			"determine the real speed of the combatant's movement. " +
			"The real speed is used for auto move animations, control maps and other things.\n" +
			"If disabled, other components will be used in that order: " +
			"CharacterController > Rigidbody > Rigidbody2D > NavMeshAgent > Position Change\n" +
			"Enable this setting if you have problems with auto move animations not playing properly.", "")]
		public bool usePositionChange = false;
		
		
		// speed
		[ORKEditorInfo("Walk Speed Settings", "The walk speed in world units per second.", "", 
			endFoldout=true, separatorForce=true)]
		public FloatValue walkSpeed = new FloatValue(3);
		
		[ORKEditorInfo("Run Speed", "The run speed in world units per second.", "", endFoldout=true)]
		public FloatValue runSpeed = new FloatValue(6);
		
		[ORKEditorInfo("Sprint Speed", "The sprint speed in world units per second.", "", endFoldout=true)]
		public FloatValue sprintSpeed = new FloatValue(9);
		
		public MovementSettings()
		{
			
		}
		
		
		/*
		============================================================================
		Speed functions
		============================================================================
		*/
		public float GetWalkSpeed(Combatant c)
		{
			float speed = this.walkSpeed.GetValue(c, c) + c.Status.GetWalkBonus();
			ValueHelper.Limit(ref speed, this.min, this.max);
			return speed;
		}
		
		public float GetRunSpeed(Combatant c)
		{
			float speed = this.runSpeed.GetValue(c, c) + c.Status.GetRunBonus();
			ValueHelper.Limit(ref speed, this.min, this.max);
			return speed;
		}
		
		public float GetSprintSpeed(Combatant c)
		{
			float speed = this.sprintSpeed.GetValue(c, c) + c.Status.GetSprintBonus();
			ValueHelper.Limit(ref speed, this.min, this.max);
			return speed;
		}
	}
}
