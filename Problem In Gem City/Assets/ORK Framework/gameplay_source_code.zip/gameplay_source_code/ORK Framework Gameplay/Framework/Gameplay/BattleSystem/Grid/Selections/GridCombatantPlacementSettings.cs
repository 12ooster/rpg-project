﻿
using UnityEngine;
using ORKFramework.Menu;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class GridCombatantPlacementSettings : BaseData
	{
		// combatant selection
		[ORKEditorHelp("Select Battle Group", "The combatant selection is used to select the members of the battle group.\n" +
			"All group members will be displayed, allowing to select those who will be used as battle group for the battle.\n" +
			"If locked battle members are available, you'll first have to place them." +
			"If disabled, only shows the battle group members for placement.", "")]
		[ORKEditorInfo(labelText="Combatant Selection")]
		public bool selectBattleGroup = false;

		[ORKEditorHelp("Use Selection", "The player can select the combatant that will be placed.\n" +
			"If disabled, the player can't select combatants and the order is predetermined by the sorting.", "")]
		public bool showSelection = false;

		[ORKEditorHelp("Combatant Selection", "The combatant selection select from the available combatants.", "")]
		[ORKEditorInfo(ORKDataType.CombatantSelection)]
		[ORKEditorLayout("showSelection", true, endCheckGroup=true)]
		public int combatantSelectionID = 0;

		public TypeSorter combatantSorter = new TypeSorter(TypeSorting.None);


		// cell selection
		[ORKEditorHelp("Remember Cell", "Start the cell selection at the last selected cell.", "")]
		[ORKEditorInfo(separator=true, labelText="Cell Selection")]
		public bool rememberCell = false;

		[ORKEditorHelp("Place On Selection", "The combatant's prefab will be placed on the selected cell before accepting it.", "")]
		public bool placeOnSelection = false;

		[ORKEditorHelp("Allow Cancel Cell", "The cell selection can be canceled using the 'Cancel' key.\n" +
			"This will return to the combatant selection.", "")]
		[ORKEditorLayout("showSelection", true, endCheckGroup=true)]
		public bool allowCancelCell = true;

		[ORKEditorHelp("Camera Control Target", "Changes the camera control target to a selected cell.\n" +
			"The camera control must descent from the 'BaseCameraControl' class (like all built-in camera controls).", "")]
		public bool cameraControlTarget = false;

		[ORKEditorHelp("Examine Cell", "Display the cell info text for the selected cell ('Examine Grid' settings).", "")]
		public bool examineCell = false;

		[ORKEditorHelp("Examine Cell Combatant", "Display the combatant info dialogue for the selected cell's combatant ('Examine Grid' settings).\n" +
			"Please note that this only shows the information dialogue and " +
			"doesn't show cell highlights (e.g. move range of a combatant).", "")]
		public bool examineCellCombatant = false;

		// orientation
		[ORKEditorHelp("Select Orientation", "Select the combatant's orientation after placement.", "")]
		[ORKEditorInfo(separator=true)]
		public bool selectOrientation = false;

		[ORKEditorHelp("Allow Cancel Orientation", "The orientation selection can be canceled using the 'Cancel' key.\n" +
			"This will return to the cell selection.", "")]
		[ORKEditorLayout("selectOrientation", true, endCheckGroup=true)]
		public bool allowCancelOrientation = true;


		// info text
		[ORKEditorHelp("Show Info Text", "An info text will be displayed while selecting a target cell for the placement.", "")]
		[ORKEditorInfo("Info Text", "Optionally display an info text box while the player selects a target cell for the placement.", "")]
		public bool showInfo = false;

		[ORKEditorInfo(separator=true, endFoldout=true, label=new string[] {
			"%un = user name, %ud = user description, %ui = user icon"
		})]
		[ORKEditorLayout("showInfo", true, endCheckGroup=true, autoInit=true)]
		public InfoBoxChoice info;


		// accept dialogue
		[ORKEditorHelp("Show Accept Question", "A question dialogue will be displayed when a cell was accepted.\n" +
			"If the player accepts the question, the cell will be used, otherwise the cell selection will be resumed.", "")]
		[ORKEditorInfo("Accept Question Dialogue", "Optionally display an accept question dialogue to ask " +
			"if the player wants to use the accepted cell.", "")]
		public bool showAcceptQuestion = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("showAcceptQuestion", true, endCheckGroup=true, autoInit=true)]
		public QuestionChoice acceptQuestion;


		// own cell selection
		[ORKEditorHelp("Own Cell Selection", "The placement selection uses a different cell selection setup.\n" +
			"If disabled, the cell selection will be used.", "")]
		[ORKEditorInfo("Cell Selection", "The placement selection can optionally override the cell selection settings.", "")]
		public bool ownCellSelection = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("ownCellSelection", true, endCheckGroup=true, autoInit=true)]
		public GridCellSelectionSettings selection;


		// in-game
		private Combatant selectedCombatant;

		private List<Combatant> availableCombatants;

		private List<Combatant> placedCombatants;

		private GameObject previousCameraControlTarget;


		// callbacks
		private NotifyBool notify;

		private CombatantChanged selectionCallback;


		// cell selection
		private bool canSelect = true;

		private bool canCancel = true;

		private List<BattleGridCellComponent> availableCells;

		private SelectGridCellBool selectCellFunction;

		private SelectGridCell acceptCellFunction;

		private GridCellCheck acceptCheckFunction;

		public GridCombatantPlacementSettings()
		{

		}

		public void Start(NotifyBool notify, bool canCancel)
		{
			ORK.InputKeys.ResetInputAxes();
			this.StopHighlights();
			this.CloseInfoBox();

			this.selectedCombatant = null;
			ORK.BattleSystem.gridSettings.ClearCellSelection();
			this.previousCameraControlTarget = ORK.Control.CameraControlTarget;
			ArrayHelper.GetBlank(ref this.placedCombatants);

			this.notify = notify;
			this.canCancel = canCancel;

			this.StartCombatantSelection();
		}

		private void End(bool finished)
		{
			this.ResetCameraControlTarget();
			this.previousCameraControlTarget = null;

			if(finished && this.selectBattleGroup)
			{
				ORK.Game.ActiveGroup.SetBattleGroup(this.placedCombatants);
			}

			if(this.notify != null)
			{
				this.notify(finished);
			}
		}

		private void StopHighlights()
		{
			if(ORK.BattleSystem.gridSettings.SelectedCell != null)
			{
				ORK.BattleSystem.gridSettings.SelectedCell.StopHighlight(GridHighlightType.PlacementSelection);
				ORK.BattleSystem.gridSettings.SelectedCell.StopHighlight(GridHighlightType.NoPlacementSelection);
			}
			if(this.availableCells != null)
			{
				BattleGridHelper.StopHighlight(this.availableCells, GridHighlightType.Placement);
			}
		}


		/*
		============================================================================
		GUI box functions
		============================================================================
		*/
		private string InfoReplace(string text)
		{
			return text.
				Replace("%un", this.selectedCombatant.GetName()).
				Replace("%ud", this.selectedCombatant.GetDescription()).
				Replace("%ui", this.selectedCombatant.GetIconTextCode());
		}

		private void ShowInfoBox()
		{
			if(this.showInfo &&
				this.selectedCombatant != null)
			{
				string tmpTitle = this.info.useTitle ?
					this.InfoReplace(this.info.title[ORK.Game.Language]) : "";
				string tmpText = this.InfoReplace(this.info.infoText[ORK.Game.Language]);

				this.info.Show(tmpTitle, tmpText, null);
			}
		}

		private void CloseInfoBox()
		{
			if(this.showInfo)
			{
				this.info.Close();
			}
		}


		/*
		============================================================================
		Combatant selection functions
		============================================================================
		*/
		private void StartCombatantSelection()
		{
			ArrayHelper.GetBlank(ref this.availableCombatants);

			if(this.selectBattleGroup)
			{
				if(this.placedCombatants.Count < ORK.GameSettings.maxBattleGroup)
				{
					if(ORK.Game.ActiveGroup.HasLockedBattleMembers())
					{
						this.AddNonPlacedCombatants(ORK.Game.ActiveGroup.GetLockedBattle());
					}
					if(this.availableCombatants.Count == 0)
					{
						this.AddNonPlacedCombatants(ORK.Game.ActiveGroup.GetGroup());
					}
				}
			}
			else
			{
				this.AddNonPlacedCombatants(ORK.Game.ActiveGroup.GetBattle());
			}

			if(this.availableCombatants.Count > 0)
			{
				this.combatantSorter.Sort(ref this.availableCombatants);

				if(this.showSelection)
				{
					if(this.selectionCallback == null)
					{
						this.selectionCallback = this.CombatantSelected;
					}

					ORK.CombatantSelections.Get(this.combatantSelectionID).ShowSelect(
						this.availableCombatants, this.selectionCallback, this.canCancel);
				}
				else
				{
					this.CombatantSelected(this.availableCombatants[0]);
				}
			}
			else
			{
				this.End(true);
			}
		}

		private void AddNonPlacedCombatants(List<Combatant> list)
		{
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null &&
					list[i].GridCell == null)
				{
					this.availableCombatants.Add(list[i]);
				}
			}
		}

		private void CombatantSelected(Combatant combatant)
		{
			// cancel
			if(combatant == null)
			{
				this.End(false);
			}
			// selected
			else
			{
				this.selectedCombatant = combatant;
				this.StartCellSelection();
			}
		}


		/*
		============================================================================
		Cell selection functions
		============================================================================
		*/
		public void Tick()
		{
			if(this.canSelect)
			{
				if(((this.showSelection && this.allowCancelCell) ||
					(!this.showSelection && this.canCancel)) &&
					ORK.InputKeys.Get(ORK.GameControls.cancelKey).GetButton())
				{
					if(this.ownCellSelection)
					{
						this.selection.PlayCancelAudio();
					}
					else
					{
						ORK.BattleSystem.gridSettings.cellSelection.PlayCancelAudio();
					}

					ORK.InputKeys.ResetInputAxes();
					this.StopHighlights();
					this.CloseInfoBox();
					ORK.BattleSystem.gridSettings.ClearCellSelection();
					if(!this.showSelection)
					{
						this.End(false);
					}
					else
					{
						this.StartCombatantSelection();
					}
				}
				else
				{
					if(ORK.BattleSystem.gridSettings.SelectedCell == null)
					{
						this.SelectCell(ORK.Battle.Grid.GetNearestDeploymentCell(this.selectedCombatant), true);
					}
					if(this.ownCellSelection)
					{
						this.selection.SelectCell(
							ORK.BattleSystem.gridSettings.SelectedCell,
							ORK.BattleSystem.gridSettings.SelectedCell,
							this.selectCellFunction, this.acceptCellFunction,
							this.acceptCheckFunction, null, false);
					}
					else
					{
						ORK.BattleSystem.gridSettings.cellSelection.SelectCell(
							ORK.BattleSystem.gridSettings.SelectedCell,
							ORK.BattleSystem.gridSettings.SelectedCell,
							this.selectCellFunction, this.acceptCellFunction,
							this.acceptCheckFunction, null, false);
					}
				}
			}
		}

		private void StartCellSelection()
		{
			ORK.BattleSystem.gridSettings.InitSelection(GridSelectionType.Placement, this.selectedCombatant);

			if(this.selectCellFunction == null)
			{
				this.selectCellFunction = this.SelectCell;
				this.acceptCellFunction = this.AcceptCell;
				this.acceptCheckFunction = this.CheckAcceptCell;
			}

			ArrayHelper.GetBlank(ref this.availableCells);
			ORK.Battle.Grid.GetCells(ref this.availableCells, this.CanDeploy);

			if(this.availableCells.Count > 0)
			{
				this.ShowInfoBox();
				this.canSelect = true;
				BattleGridHelper.Highlight(this.availableCells, GridHighlightType.Placement);

				if(this.rememberCell)
				{
					BattleGridCellComponent tmpCell = ORK.BattleSystem.gridSettings.SelectedCell;
					ORK.BattleSystem.gridSettings.SelectedCell = null;
					this.SelectCell(tmpCell, true);
				}
				else
				{
					this.SelectCell(null, true);
				}
			}
			else
			{
				this.End(false);
			}
		}

		private void UseSelectedCell()
		{
			this.StopHighlights();
			this.CloseInfoBox();
			ORK.InputKeys.ResetInputAxes();

			if(ORK.BattleSystem.gridSettings.SelectedCell != null &&
				this.selectedCombatant != null)
			{
				this.PlaceOnSelection();
				this.selectedCombatant.GridCell = ORK.BattleSystem.gridSettings.SelectedCell;
			}

			if(this.selectOrientation)
			{
				ORK.BattleSystem.gridSettings.orientationSelection.Start(
					this.selectedCombatant, null,
					this.OrientationSelected, this.allowCancelOrientation);
			}
			else
			{
				ORK.BattleSystem.gridSettings.SelectionType = GridSelectionType.None;
				this.placedCombatants.Add(this.selectedCombatant);
				this.StartCombatantSelection();
			}
		}

		private void ResetCameraControlTarget()
		{
			if(this.cameraControlTarget)
			{
				ORK.Control.CameraControlTarget = this.previousCameraControlTarget;
			}
		}

		private void PlaceOnSelection()
		{
			if(this.selectedCombatant != null &&
				ORK.BattleSystem.gridSettings.SelectedCell != null)
			{
				if(this.selectedCombatant.GameObject != null)
				{
					this.selectedCombatant.GameObject.transform.position =
						ORK.BattleSystem.gridSettings.SelectedCell.transform.position;
				}
				else
				{
					this.selectedCombatant.Spawn(
						ORK.BattleSystem.gridSettings.SelectedCell.transform.position,
						false, 0, false, Vector3.zero);
				}
			}
		}

		public void OrientationSelected(bool accept)
		{
			if(accept)
			{
				this.placedCombatants.Add(this.selectedCombatant);
				this.StartCombatantSelection();
			}
			else
			{
				this.selectedCombatant.GridCell = null;
				this.selectedCombatant.DestroyPrefab();
				this.StartCellSelection();
			}
		}

		public void SelectCell(BattleGridCellComponent cell, bool useCamera)
		{
			if(ORK.BattleSystem.gridSettings.SelectedCell != cell)
			{
				// stop selection highlight
				if(ORK.BattleSystem.gridSettings.SelectedCell != null)
				{
					ORK.BattleSystem.gridSettings.SelectedCell.StopHighlight(GridHighlightType.PlacementSelection);
					ORK.BattleSystem.gridSettings.SelectedCell.StopHighlight(GridHighlightType.NoPlacementSelection);
				}
				ORK.BattleSystem.gridSettings.SelectedCell = cell;

				// new highlights
				if(ORK.BattleSystem.gridSettings.SelectedCell != null)
				{
					if(this.cameraControlTarget && useCamera)
					{
						ORK.Control.CameraControlTarget = ORK.BattleSystem.gridSettings.SelectedCell.gameObject;
					}

					if(this.availableCells.Contains(ORK.BattleSystem.gridSettings.SelectedCell))
					{
						if(ORK.BattleSystem.gridSettings.placementSelectionHighlight.enable)
						{
							ORK.BattleSystem.gridSettings.SelectedCell.Highlight(GridHighlightType.PlacementSelection);
						}
					}
					else if(ORK.BattleSystem.gridSettings.noPlacementSelectionHighlight.enable)
					{
						ORK.BattleSystem.gridSettings.SelectedCell.Highlight(GridHighlightType.NoPlacementSelection);
					}

					if(this.placeOnSelection)
					{
						this.PlaceOnSelection();
					}
				}
				else
				{
					this.ResetCameraControlTarget();
				}

				if(this.examineCell ||
					this.examineCellCombatant)
				{
					ORK.BattleSystem.gridSettings.examine.ExternalExamine(
						ORK.BattleSystem.gridSettings.SelectedCell,
						this.examineCell, this.examineCellCombatant);
				}
			}
		}

		public void AcceptCell(BattleGridCellComponent cell)
		{
			if(cell != null &&
				this.availableCells.Contains(cell))
			{
				this.CloseInfoBox();
				this.canSelect = false;

				if(ORK.BattleSystem.gridSettings.SelectedCell != cell)
				{
					this.SelectCell(cell, true);
				}
				if(this.showAcceptQuestion)
				{
					this.acceptQuestion.Show(
						this.selectedCombatant.GetName(), this.AcceptQuestionClosed);
				}
				else
				{
					this.UseSelectedCell();
				}
			}
			else
			{
				this.SelectCell(cell, true);
			}
		}

		public void AcceptQuestionClosed(bool accepted)
		{
			if(accepted)
			{
				this.UseSelectedCell();
			}
			else
			{
				this.ShowInfoBox();
				this.canSelect = true;
			}
		}

		public bool CheckAcceptCell(BattleGridCellComponent cell)
		{
			return cell != null &&
				this.availableCells.Contains(cell) &&
				cell.CanDeploy(this.selectedCombatant);
		}

		public bool CanDeploy(BattleGridCellComponent cell)
		{
			return cell != null && cell.CanDeploy(this.selectedCombatant);
		}
	}
}
