﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ResearchTree : ISaveData, IContent
	{
		private ResearchHandler handler;

		private ResearchTreeSetting setting;


		// research
		private ResearchItem[] items;

		private int inResearchCount = 0;

		private bool isComplete = false;

		public ResearchTree(ResearchHandler handler, int researchTreeID)
		{
			this.handler = handler;
			this.Init(researchTreeID);
		}

		public ResearchTree(ResearchHandler handler, DataObject data)
		{
			this.handler = handler;
			this.LoadGame(data);
		}

		public void Init(int researchTreeID)
		{
			this.setting = ORK.ResearchTrees.Get(researchTreeID);
			this.items = new ResearchItem[this.setting.item.Length];

			for(int i = 0; i < this.setting.item.Length; i++)
			{
				this.items[i] = new ResearchItem(i, this, this.setting.item[i]);
			}
		}


		/*
		============================================================================
		Get/set functions
		============================================================================
		*/
		public ResearchTreeSetting Setting
		{
			get { return this.setting; }
		}

		public ResearchHandler Handler
		{
			get { return this.handler; }
		}

		public bool IsComplete
		{
			get { return this.isComplete; }
		}

		public int InResearch
		{
			get { return this.inResearchCount; }
		}

		public List<ResearchItem> GetItems()
		{
			return new List<ResearchItem>(this.items);
		}

		public ResearchItem GetItem(int index)
		{
			if(index >= 0 && index < this.items.Length)
			{
				return this.items[index];
			}
			return null;
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public int ID
		{
			get { return this.setting.ID; }
		}

		public int TypeID
		{
			get { return this.setting.TypeID; }
		}

		public string GetName()
		{
			return this.setting.GetName();
		}

		public string GetDescription()
		{
			return this.setting.GetDescription();
		}

		public string GetIconTextCode()
		{
			return this.setting.GetIconTextCode();
		}

		public Texture GetIcon()
		{
			return this.setting.GetIcon();
		}

		public GUIContent GetContent()
		{
			return this.setting.GetContent();
		}

		public IContentSimple GetTypeContent()
		{
			return this.setting.GetTypeContent();
		}

		public string GetInfo(Combatant c)
		{
			return this.setting.GetInfo(c);
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool CanResearch()
		{
			if(this.setting.limitResearch)
			{
				if(this.setting.globalLimit)
				{
					return this.handler.InResearch < this.setting.researchLimit;
				}
				else
				{
					return this.inResearchCount < this.setting.researchLimit;
				}
			}
			return true;
		}

		public bool ContainsItemState(bool researchable, bool notResearchableLimit,
			bool notResearchableCosts, bool notResearchableRequirements,
			bool inResearch, bool complete)
		{
			for(int i = 0; i < this.items.Length; i++)
			{
				ResearchDisplayType displayType = this.items[i].GetResearchDisplayType();

				if((researchable &&
						ResearchDisplayType.Researchable == displayType) ||
					(notResearchableLimit &&
						ResearchDisplayType.LimitFail == displayType) ||
					(notResearchableCosts &&
						ResearchDisplayType.CostsFail == displayType) ||
					(notResearchableRequirements &&
						ResearchDisplayType.RequirementsFail == displayType) ||
					(inResearch &&
						ResearchDisplayType.InResearch == displayType) ||
					(complete &&
						ResearchDisplayType.Complete == displayType))
				{
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Research functions
		============================================================================
		*/
		public void ResearchStarted(bool count)
		{
			if(count)
			{
				this.inResearchCount++;
			}
			this.handler.ResearchStarted(count);
		}

		public void ResearchCanceled(bool count)
		{
			if(count)
			{
				this.inResearchCount--;
				if(this.inResearchCount < 0)
				{
					this.inResearchCount = 0;
				}
			}
			this.handler.ResearchCanceled(count);
		}

		public void ResearchFinished(bool count)
		{
			if(count)
			{
				this.inResearchCount--;
				if(this.inResearchCount < 0)
				{
					this.inResearchCount = 0;
				}
			}
			this.CheckComplete();
			this.handler.ResearchFinished(count);
		}

		public void CheckComplete()
		{
			bool complete = true;
			for(int i = 0; i < this.items.Length; i++)
			{
				if(ResearchItemState.Complete != this.items[i].State)
				{
					complete = false;
					break;
				}
			}
			if(complete)
			{
				this.isComplete = true;
				if(this.setting.autoRemove)
				{
					this.handler.RemoveTree(this, this.setting.removeShowNotification, this.setting.removeShowConsole);
				}
			}
		}

		public void UpdateDuration()
		{
			for(int i = 0; i < this.items.Length; i++)
			{
				if(ResearchItemState.Complete != this.items[i].State)
				{
					this.items[i].UpdateDuration();
				}
			}
		}

		public void ManualProgress(float add)
		{
			for(int i = 0; i < this.items.Length; i++)
			{
				this.items[i].ManualProgress(add);
			}
		}

		public void TimeProgress(float add)
		{
			for(int i = 0; i < this.items.Length; i++)
			{
				this.items[i].TimeProgress(add);
			}
		}

		public void Progress(float add)
		{
			for(int i = 0; i < this.items.Length; i++)
			{
				this.items[i].Progress(add);
			}
		}


		/*
		============================================================================
		Reset functions
		============================================================================
		*/
		public void ResetProgress()
		{
			for(int i = 0; i < this.items.Length; i++)
			{
				this.items[i].ResetProgress();
			}
		}

		public void ResetManualProgress()
		{
			for(int i = 0; i < this.items.Length; i++)
			{
				this.items[i].ResetManualProgress();
			}
		}

		public void ResetTimeProgress()
		{
			for(int i = 0; i < this.items.Length; i++)
			{
				this.items[i].ResetTimeProgress();
			}
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();

			data.Set("id", this.setting.RealID);
			data.Set("inResearchCount", this.inResearchCount);
			data.Set("isComplete", this.isComplete);

			// research items
			DataObject[] tmp = new DataObject[this.items.Length];
			for(int i = 0; i < this.items.Length; i++)
			{
				tmp[i] = this.items[i].SaveGame();
			}
			data.Set("items", tmp);

			return data;
		}

		public void LoadGame(DataObject data)
		{
			if(data != null)
			{
				int id = 0;
				data.Get("id", ref id);
				this.Init(id);

				data.Get("inResearchCount", ref this.inResearchCount);
				data.Get("isComplete", ref this.isComplete);

				// research items
				DataObject[] tmp = data.GetFileArray("items");
				if(tmp != null && tmp.Length > 0)
				{
					for(int i = 0; i < tmp.Length; i++)
					{
						if(i < this.items.Length)
						{
							this.items[i].LoadGame(tmp[i]);
						}
					}
				}
			}
		}
	}
}
