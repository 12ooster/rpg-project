
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class SimpleCombatantRequirement : BaseData
	{
		// status requirements
		[ORKEditorHelp("Needed", "Either all or only one requirement must be met.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75, labelText="Status Requirements")]
		public Needed needed = Needed.All;

		[ORKEditorArray(false, "Add Status Requirement", "Add a status requirement.", "",
			"Remove", "Remove the status requirement", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Status Requirement", "Define the status requirement that must be met to use this prefab.", ""
		})]
		public StatusRequirement[] req = new StatusRequirement[0];


		// variable conditions
		[ORKEditorHelp("Use Object Variable", "Use object variables of the combatant.\n" +
			"The combatant's game object must have an 'Object Variables' component attached, " +
			"else the check fails.", "")]
		[ORKEditorInfo(separator=true, labelText="Variable Conditions")]
		public bool useObjectVariable = false;

		public VariableCondition condition = new VariableCondition();

		public SimpleCombatantRequirement()
		{

		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool Check(Combatant combatant)
		{
			return combatant != null &&
				StatusRequirement.Check(combatant, this.req, this.needed) &&
				this.CheckVariables(combatant);
		}

		public bool CheckVariables(Combatant combatant)
		{
			VariableHandler handler = this.GetUsedVariableHandler(combatant);
			if(handler != null)
			{
				return this.condition.CheckVariables(handler);
			}
			return false;
		}

		public VariableHandler GetUsedVariableHandler(Combatant combatant)
		{
			if(this.useObjectVariable)
			{
				if(combatant != null)
				{
					if(combatant.Variables != null)
					{
						return combatant.Variables;
					}
					else if(combatant.GameObject != null)
					{
						ObjectVariablesComponent comp = ComponentHelper.
							GetInChildren<ObjectVariablesComponent>(combatant.GameObject);
						if(comp != null)
						{
							return comp.GetHandler();
						}
					}
				}
			}
			else
			{
				return ORK.Game.Variables;
			}
			return null;
		}


		/*
		============================================================================
		Register functions
		============================================================================
		*/
		public void RegisterChanges(Combatant combatant, IStatusChanged statusChanged, Notify variablesChanged)
		{
			// status changes
			for(int i = 0; i < this.req.Length; i++)
			{
				this.req[i].RegisterStatusChanges(combatant, statusChanged);
			}

			// variable changes
			if(this.condition.gameVariable.Length > 0)
			{
				VariableHandler handler = this.GetUsedVariableHandler(combatant);
				if(handler != null)
				{
					handler.Changed += variablesChanged;
				}
			}
		}

		public void UnregisterChanges(Combatant combatant, IStatusChanged statusChanged, Notify variablesChanged)
		{
			// status changes
			for(int i = 0; i < this.req.Length; i++)
			{
				this.req[i].UnregisterStatusChanges(combatant, statusChanged);
			}

			// variable changes
			if(this.condition.gameVariable.Length > 0)
			{
				VariableHandler handler = this.GetUsedVariableHandler(combatant);
				if(handler != null)
				{
					handler.Changed -= variablesChanged;
				}
			}
		}
	}
}
