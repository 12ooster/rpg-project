﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework.UI
{
	public abstract class BaseBattleMenuItem : BaseTypeData
	{
		protected override string GetTypeNamespace()
		{
			return "UI.";
		}

		public abstract bool IsType(BMItemType type);

		public abstract void AddToMenu(ref List<BMItem> list, Combatant owner, BattleMenu bm, BattleMenuItem parent);
	}
}
