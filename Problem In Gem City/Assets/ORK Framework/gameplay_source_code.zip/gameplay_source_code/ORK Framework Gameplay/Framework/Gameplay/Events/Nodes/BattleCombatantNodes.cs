﻿
using UnityEngine;
using ORKFramework;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework.Events.Steps
{
	[ORKEditorHelp("Look At Enemies", "All combatants participating in the battle will look at their enemies.\n" +
		"Note that only combatant's that are already in the scene will look at their enemies.\n" +
		"When using a 'Battle Grid', the rotation will be adjusted to the grid directions.", "")]
	[ORKEventStep(typeof(BattleStartEvent), typeof(BattleEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Battle/Combatant", "Movement/Rotation")]
	public class LookAtEnemiesStep : BaseEventStep
	{
		public LookAtEnemiesStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			ORK.Battle.SetLooks(null);
			baseEvent.StepFinished(this.next);
		}
	}

	[ORKEditorHelp("Spawn Combatants", "Spawns combatants participating in this battle at their battle spots.\n" +
			"Note that only combatants that aren't already in the scene will be spawned.", "")]
	[ORKEventStep(typeof(BattleStartEvent))]
	[ORKNodeInfo("Battle/Combatant")]
	public class SpawnCombatantsStep : BaseEventStep
	{
		[ORKEditorHelp("Spawn All", "All combatants participating in this battle will be spawned at their battle spots.\n" +
			"Note that only combatants that aren't already in the scene will be spawned.", "")]
		public bool all = true;

		[ORKEditorHelp("Group", "Select the combatant group that will be spawned.", "")]
		[ORKEditorInfo(isTabPopup=true, tabPopupID=0)]
		[ORKEditorLayout("all", false, endCheckGroup=true)]
		public int id = 0;

		public SpawnCombatantsStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.all)
			{
				this.Spawn(baseEvent, 0);
				this.Spawn(baseEvent, 1);
				this.Spawn(baseEvent, 2);
			}
			else
			{
				this.Spawn(baseEvent, this.id);
			}
			baseEvent.StepFinished(this.next);
		}

		private void Spawn(BaseEvent baseEvent, int index)
		{
			List<Combatant> combatants = baseEvent.GetActorCombatant(index);
			for(int i = 0; i < combatants.Count; i++)
			{
				if(combatants[i] != null &&
					combatants[i].GameObject == null &&
					combatants[i].BattleSpot != null)
				{
					if(ORK.Battle.Grid != null)
					{
						BattleGridCellComponent cell = ORK.Battle.Grid.GetNearestDeploymentCell(combatants[i]);
						if(cell == null)
						{
							cell = ORK.Battle.Grid.GetNearestFreeCell(combatants[i]);
						}
						if(cell != null)
						{
							combatants[i].BattleSpot.transform.position = cell.transform.position;
							cell.Combatant = combatants[i];
						}
					}
					combatants[i].Spawn(
						combatants[i].BattleSpot.transform.position,
						ORK.BattleSpots.useYRotation, combatants[i].BattleSpot.transform.eulerAngles.y,
						ORK.BattleSpots.useScale, combatants[i].BattleSpot.transform.localScale);
				}
			}
		}
	}

	[ORKEditorHelp("Place At Spots", "Place combatants participating in this battle at their battle spots.", "")]
	[ORKEventStep(typeof(BattleStartEvent), typeof(BattleEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Battle/Combatant")]
	public class PlaceAtSpotsStep : BaseEventStep
	{
		[ORKEditorHelp("Place All", "All combatants participating in this battle will be placed at their battle spots.\n" +
			"Note that only combatants that are already in the scene will be placed.", "")]
		public bool all = true;

		[ORKEditorInfo(separator=true, labelText="Group")]
		[ORKEditorLayout("all", false, endCheckGroup=true)]
		public EventObjectSetting usedObject = new EventObjectSetting();

		public PlaceAtSpotsStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("id"))
			{
				this.usedObject.type = StepObjectType.Actor;
				data.Get("id", ref this.usedObject.aID);
			}
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(baseEvent is BattleEvent)
			{
				if(this.all)
				{
					this.Place(baseEvent.GetActorCombatant(0));
					this.Place(baseEvent.GetActorCombatant(1));
				}
				else
				{
					this.Place(this.usedObject.GetCombatant(baseEvent));
				}
			}
			else
			{
				if(this.all)
				{
					this.Place(baseEvent.GetActorCombatant(0));
					this.Place(baseEvent.GetActorCombatant(1));
					this.Place(baseEvent.GetActorCombatant(2));
				}
				else
				{
					this.Place(this.usedObject.GetCombatant(baseEvent));
				}
			}
			baseEvent.StepFinished(this.next);
		}

		private void Place(List<Combatant> combatants)
		{
			for(int i = 0; i < combatants.Count; i++)
			{
				if(combatants[i] != null &&
					combatants[i].GameObject != null &&
					combatants[i].BattleSpot != null)
				{
					combatants[i].PlaceAt(
						combatants[i].BattleSpot.transform.position,
						ORK.BattleSpots.useYRotation, combatants[i].BattleSpot.transform.eulerAngles.y,
						ORK.BattleSpots.useScale, combatants[i].BattleSpot.transform.localScale);
				}
			}
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.all ? "All" : this.usedObject.GetInfoText();
		}
	}

	[ORKEditorHelp("Place Spots On Ground", "Tries to place the battle spots on ground " +
		"(when using 'Place On Ground' settings in the battle spot settings).\n" +
		"Please note that this is only done in battles using the 'Battle' component " +
		"(or started through the auto battle settings of a combatant). " +
		"I.e. 'Real Time Area Battles' don't use battle spots.", "")]
	[ORKEventStep(typeof(BattleStartEvent), typeof(BattleEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Battle/Combatant", "Battle/Battle")]
	public class PlaceSpotsOnGroundStep : BaseEventStep
	{
		public PlaceSpotsOnGroundStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(ORK.Battle.BattleArena != null)
			{
				ORK.Battle.BattleArena.PlaceSpotsOnGround();
			}
			baseEvent.StepFinished(this.next);
		}
	}

	[ORKEditorHelp("Destroy Combatants", "Destroy combatants participating in this battle.", "")]
	[ORKEventStep(typeof(BattleEndEvent))]
	[ORKNodeInfo("Battle/Combatant")]
	public class DestroyCombatantsStep : BaseEventStep
	{
		[ORKEditorHelp("Destroy Player", "The player combatant (or group) will also be destroyed.\n" +
			"If disabled, the player combatant or group wont be destroyed - " +
			"depending on the 'group spawn' settings defined in the game settings.", "")]
		public bool player = false;

		[ORKEditorHelp("Destroy All", "All combatants participating in this battle will be destroyed.", "")]
		public bool all = true;

		[ORKEditorInfo(separator=true, labelText="Group")]
		[ORKEditorLayout("all", false, endCheckGroup=true)]
		public EventObjectSetting usedObject = new EventObjectSetting();

		public DestroyCombatantsStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("id"))
			{
				this.usedObject.type = StepObjectType.Actor;
				data.Get("id", ref this.usedObject.aID);
			}
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.all)
			{
				if(this.player || !ORK.GameSettings.spawnGroup)
				{
					this.Destroy(baseEvent.GetActorCombatant(0));
				}
				this.Destroy(baseEvent.GetActorCombatant(1));
				this.Destroy(baseEvent.GetActorCombatant(2));
			}
			else
			{
				this.Destroy(this.usedObject.GetCombatant(baseEvent));
			}
			baseEvent.StepFinished(this.next);
		}

		private void Destroy(List<Combatant> combatants)
		{
			for(int i = 0; i < combatants.Count; i++)
			{
				if(combatants[i] != null && combatants[i].GameObject != null &&
					(this.player || combatants[i] != ORK.Game.ActiveGroup.Leader))
				{
					combatants[i].DestroyPrefab();
				}
			}
		}
	}

	[ORKEditorHelp("Join Battle", "A combatant joins the battle.\n" +
		"The combatant is spawned at the first free battle spot of its group.", "")]
	[ORKEventStep(typeof(BattleEvent), typeof(BattleStartEvent))]
	[ORKNodeInfo("Battle/Combatant")]
	public class JoinBattleStep : BaseEventStep
	{
		[ORKEditorHelp("New Group", "The combatant will create a new group " +
			"instead of joining an existing combatant's group.", "")]
		public bool newGroup = false;

		[ORKEditorHelp("Faction", "Select the faction of the combatant.", "")]
		[ORKEditorInfo(ORKDataType.Faction)]
		[ORKEditorLayout("newGroup", true)]
		public int factionID = 0;

		[ORKEditorInfo(separator=true, labelText="Group")]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true)]
		public EventObjectSetting usedObject = new EventObjectSetting();

		[ORKEditorHelp("Mark As Temporary", "The combatant is marked as temporary.\n" +
			"Temporary combatants can be removed using the 'Remove Temporary' step.\n" +
			"Use marking combatants as temporary e.g. for summon game mechanics.", "")]
		public bool markTemporary = false;

		[ORKEditorInfo(separator=true, labelText="Combatant")]
		public CombatantGroupMember member = new CombatantGroupMember();

		public JoinBattleStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("id"))
			{
				this.usedObject.type = StepObjectType.Actor;
				data.Get("id", ref this.usedObject.aID);
			}
		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.newGroup)
			{
				Combatant c = member.Create(new Group(this.factionID));
				if(this.markTemporary)
				{
					c.IsTemporary = true;
				}
				ORK.Battle.Join(c);
			}
			else
			{
				List<Combatant> combatants = this.usedObject.GetCombatant(baseEvent);
				for(int i = 0; i < combatants.Count; i++)
				{
					if(combatants[i] != null)
					{
						Combatant c = member.Create(combatants[i].Group);
						if(this.markTemporary)
						{
							c.IsTemporary = true;
						}
						ORK.Battle.Join(c);
						break;
					}
				}
			}
			baseEvent.StepFinished(this.next);
		}
	}

	[ORKEditorHelp("Leave Battle", "A combatant leaves the battle.\n" +
		"The combatant's game object is destroyed.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle/Combatant")]
	public class LeaveBattleStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="Combatant")]
		public EventObjectSetting usedObject = new EventObjectSetting();

		[ORKEditorHelp("Remove From Group", "Remove the combatant from his group.", "")]
		public bool removeFromGroup = false;

		[ORKEditorHelp("Show Notification", "The leave group notification will be displayed.", "")]
		[ORKEditorLayout("removeFromGroup", true)]
		public bool showNotification = true;

		[ORKEditorHelp("Show Console", "The leave group text will be displayed in the console.", "")]
		[ORKEditorLayout(endCheckGroup=true)]
		public bool showConsole = true;

		public LeaveBattleStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("id"))
			{
				this.usedObject.type = StepObjectType.Actor;
				data.Get("id", ref this.usedObject.aID);
			}
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> combatants = this.usedObject.GetCombatant(baseEvent);
			for(int i = 0; i < combatants.Count; i++)
			{
				if(combatants[i] != null)
				{
					if(this.removeFromGroup)
					{
						combatants[i].Group.Remove(combatants[i], true, false,
							this.showNotification, this.showConsole);
					}
					ORK.Battle.RemoveCombatant(combatants[i], false);
				}
			}
			baseEvent.StepFinished(this.next);
		}
	}

	[ORKEditorHelp("Check Turn", "Checks a combatant's turn.\n" +
		"If the check is valid, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Battle/Combatant", "Combatant/Status", "Check/Battle")]
	public class CheckTurnStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Check Type", "Checks if the turn is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the turn is between two defined values, including the values.\n" +
			"Range exclusive checks if the turn is between two defined values, excluding the values.\n" +
			"Approximately checks if the turn is similar to the defined value.", "")]
		public VariableValueCheck check = VariableValueCheck.IsEqual;

		[ORKEditorInfo(separator=true, labelText="Turn Value")]
		public EventFloat turn = new EventFloat();

		[ORKEditorInfo(separator=true, labelText="Turn Value 2")]
		[ORKEditorLayout(new string[] {"check", "check"},
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive},
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public EventFloat turn2;


		// object
		[ORKEditorHelp("Needed", "Either all or only one combatant's turn check must be valid.", "")]
		[ORKEditorInfo(separator=true, labelText="Check Object",
			isEnumToolbar=true, toolbarWidth=75)]
		public Needed needed = Needed.One;

		public EventObjectSetting checkObject = new EventObjectSetting();

		[ORKEditorHelp("Use Average", "Use the average turn of the combatant's group.", "")]
		public bool useAverage = false;

		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;

		public CheckTurnStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.DoCheck(ComponentHelper.GetCombatants(this.checkObject.GetObject(baseEvent)),
				this.turn.GetValue(baseEvent),
				this.turn2 != null ? this.turn2.GetValue(baseEvent) : 0))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}

		private bool DoCheck(List<Combatant> list, float value, float value2)
		{
			if(list.Count > 0)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(ValueHelper.CheckVariableValue(
						this.useAverage ?
							(this.onlyBattle ?
								list[i].Group.AverageBattleTurn :
								list[i].Group.AverageTurn) :
							list[i].Battle.Turn,
						value, value2, this.check))
					{
						if(Needed.One == needed)
						{
							return true;
						}
					}
					else if(Needed.All == needed)
					{
						return false;
					}
				}
				if(Needed.All == needed)
				{
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.checkObject.GetInfoText() + ": " +
				this.check.ToString() + " " + this.turn.GetInfoText() +
				(this.turn2 != null ? " ~ " + this.turn2.GetInfoText() : "");
		}
	}

	[ORKEditorHelp("Set Attacked By", "Mark that a combatant has been attacked by another combatant.\n" +
		"This can influence various things, e.g. victory gains, faction sympathy changes, etc.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle/Combatant", "Combatant/Combatant")]
	public class SetAttackedByStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="Target Object", label=new string[] {
			"This object will be marked as attacked by the attacker object."
		})]
		public EventObjectSetting target = new EventObjectSetting();

		[ORKEditorInfo(separator=true, labelText="Attacker Object", label=new string[] {
			"This object will be used to mark the target object."
		})]
		public EventObjectSetting attacker = new EventObjectSetting();

		public SetAttackedByStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> targetList = this.target.GetCombatant(baseEvent);
			List<Combatant> attackerList = this.attacker.GetCombatant(baseEvent);

			for(int i = 0; i < targetList.Count; i++)
			{
				if(targetList[i] != null)
				{
					for(int j = 0; j < attackerList.Count; j++)
					{
						if(attackerList[j] != null)
						{
							targetList[i].Battle.SetAttackedBy(attackerList[j], true);
						}
					}
				}
			}

			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.target.GetInfoText() + ": " + this.attacker.GetInfoText();
		}
	}

	[ORKEditorHelp("Change Last Target", "Changes the last targets of a combatant.\n" +
		"This can influence various things, e.g. AI target selection, etc.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle/Combatant", "Combatant/Combatant")]
	public class ChangeLastTargetStep : BaseEventStep
	{
		[ORKEditorHelp("Change Type", "Select how the last targets will be changed:\n" +
			"- Add: A combatants will be added to the last targets.\n" +
			"- Remove: The combatants will be removed from the last targets.\n" +
			"- Clear: The last targets will be cleared (i.e. all will be removed).\n" +
			"- Set: A combatant will be set as the last target, removing previous targets.", "")]
		public ListChangeType changeType = ListChangeType.Clear;

		[ORKEditorInfo(separator=true, labelText="User Object", label=new string[] {
			"This object will change it's last targets."
		})]
		public EventObjectSetting user = new EventObjectSetting();

		[ORKEditorInfo(separator=true, labelText="Target Object", label=new string[] {
			"This object will be used to change the last targets of the user object."
		})]
		[ORKEditorLayout("changeType", ListChangeType.Clear,
			elseCheckGroup=true, endCheckGroup=true, autoInit=true)]
		public EventObjectSetting target;

		public ChangeLastTargetStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> userList = this.user.GetCombatant(baseEvent);

			if(ListChangeType.Clear == this.changeType)
			{
				for(int i = 0; i < userList.Count; i++)
				{
					if(userList[i] != null)
					{
						userList[i].Battle.LastTargets.Clear();
					}
				}
			}
			else
			{
				if(ListChangeType.Set == this.changeType)
				{
					for(int i = 0; i < userList.Count; i++)
					{
						if(userList[i] != null)
						{
							userList[i].Battle.LastTargets.Clear();
						}
					}
				}
				List<Combatant> targetList = this.target.GetCombatant(baseEvent);
				for(int i = 0; i < userList.Count; i++)
				{
					if(userList[i] != null)
					{
						if(ListChangeType.Add == this.changeType ||
							ListChangeType.Set == this.changeType)
						{
							for(int j = 0; j < targetList.Count; j++)
							{
								if(!userList[i].Battle.LastTargets.Contains(targetList[j]))
								{
									userList[i].Battle.LastTargets.Add(targetList[j]);
								}
							}
						}
						else if(ListChangeType.Remove == this.changeType)
						{
							for(int j = 0; j < targetList.Count; j++)
							{
								if(userList[i].Battle.LastTargets.Contains(targetList[j]))
								{
									userList[i].Battle.LastTargets.Remove(targetList[j]);
								}
							}
						}
					}
				}
			}

			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.user.GetInfoText() + ": " + this.changeType +
				(ListChangeType.Clear == this.changeType ?
					"" : " " + this.target.GetInfoText());
		}
	}

	[ORKEditorHelp("Mark As Temporary", "A combatant will be marked as temporary combatant.\n" +
		"Temporary combatants can be removed (e.g. in 'Battle End Events') by the 'Remove Temporary' step.\n" +
		"You can use marking combatants as temporary e.g. for summon game mechanics.", "")]
	[ORKEventStep(typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Battle/Combatant", "Combatant/Combatant")]
	public class MarkAsTemporaryStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="Combatant")]
		public EventObjectSetting usedObject = new EventObjectSetting();

		public MarkAsTemporaryStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("id"))
			{
				this.usedObject.type = StepObjectType.Actor;
				data.Get("id", ref this.usedObject.aID);
			}
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> combatants = this.usedObject.GetCombatant(baseEvent);
			for(int i = 0; i < combatants.Count; i++)
			{
				if(combatants[i] != null)
				{

				}
			}
			baseEvent.StepFinished(this.next);
		}
	}

	[ORKEditorHelp("Remove Temporary", "Removes combatants marked as temporary from their groups " +
		"and destroys their game objects.\n" +
		"Combatants can be marked as temporary using the 'Mark As Temporary' step.\n" +
		"You can use marking combatants as temporary e.g. for summon game mechanics.", "")]
	[ORKEventStep(typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Battle/Combatant", "Combatant/Combatant")]
	public class RemoveTemporaryStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="Group")]
		public EventObjectSetting usedObject = new EventObjectSetting();

		[ORKEditorHelp("Destroy Object", "Destroy the game object of the removed combatant.", "")]
		public bool destroy = true;

		[ORKEditorHelp("Show Notification", "The leave group notification will be displayed.", "")]
		public bool showNotification = true;

		[ORKEditorHelp("Show Console", "The leave group text will be displayed in the console.", "")]
		public bool showConsole = true;

		public RemoveTemporaryStep()
		{

		}

		public override void SetData(DataObject data)
		{
			base.SetData(data);

			if(data.Contains<int>("id"))
			{
				this.usedObject.type = StepObjectType.Actor;
				data.Get("id", ref this.usedObject.aID);
			}
		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Group> groups = new List<Group>();
			List<Combatant> combatants = this.usedObject.GetCombatant(baseEvent);
			for(int i = 0; i < combatants.Count; i++)
			{
				if(combatants[i] != null && !groups.Contains(combatants[i].Group))
				{
					groups.Add(combatants[i].Group);
				}
			}

			for(int i = 0; i < groups.Count; i++)
			{
				List<Combatant> tmp = groups[i].GetGroup();
				List<Combatant> remove = new List<Combatant>();
				for(int j = 0; j < tmp.Count; j++)
				{
					if(tmp[j] != null && tmp[j].IsTemporary)
					{
						remove.Add(tmp[j]);
					}
				}
				for(int j = 0; j < remove.Count; j++)
				{
					groups[i].Remove(remove[j], true, this.destroy,
						this.showNotification, this.showConsole);
				}
			}

			baseEvent.StepFinished(this.next);
		}
	}

	[ORKEditorHelp("Change Turn Value", "Changes the turn value of a combatant.\n" +
		"The turn value is used to generate the turn order in 'Turn Based Battles' using 'Multi Turns.\n" +
		"If the used combatant is the user, use a 'No Time Consume' step to prevent " +
		"the turn value from being reset after the action.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle/Combatant", "Combatant/Status")]
	public class ChangeTurnValueStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="User Object")]
		public EventObjectSetting user = new EventObjectSetting();


		// turn value change
		[ORKEditorHelp("Operator", "Defines how the turn value will be changed:\n" +
			"- Add: Adds the value to the current turn value.\n" +
			"- Sub: Subtracts the value from the current turn value.\n" +
			"- Multiply: Multiplies the current turn value with the value.\n" +
			"- Divide: Divides the current turn value by the value.\n" +
			"- Modulo: Uses the modulo operator, current turn value % the value.\n" +
			"- Power Of: The current turn value to the power of the value.\n" +
			"- Log: The current turn value is used in a logarithmic calculation with the value as base.\n" +
			"- Set: Sets the current turn value to the value.", "")]
		[ORKEditorInfo(separator=true, labelText="Turn Value Change")]
		public FormulaOperator op = FormulaOperator.Set;

		public EventFloat value = new EventFloat();

		[ORKEditorHelp("Result Rounding", "Rounds the result of the turn value change.\n" +
			"- None: No rounding.\n" +
			"- Ceil: The value will be rounded up (e.g. 14.2 will become 15).\n" +
			"- Floor: The value will be rounded down (e.g. 14.8 will become 14).\n" +
			"- Round: The value will be rounded to the nearest integer (e.g. 14.2 will become 14, 14.8 will become 15).", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public Rounding rounding = Rounding.None;

		public ChangeTurnValueStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> userList = this.user.GetCombatant(baseEvent);
			for(int i = 0; i < userList.Count; i++)
			{
				if(userList[i] != null)
				{
					float tmp = userList[i].Battle.TurnValue;
					ValueHelper.UseOperator(ref tmp, this.value.GetValue(baseEvent), this.op);
					userList[i].Battle.TurnValue = ValueHelper.GetRounded(tmp, this.rounding);
					userList[i].Battle.TurnValueDummy = userList[i].Battle.TurnValue;
				}
			}

			if(ORK.Battle.IsTurnBased() &&
				TurnBasedMode.MultiTurns == ORK.BattleSystem.turnBased.mode)
			{
				ORK.BattleSystem.turnBased.TurnValuesUpdated();
			}

			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.user.GetInfoText() + ": " + this.op.ToString() +
				" " + this.value.GetInfoText();
		}
	}

	[ORKEditorHelp("Check Turn Value", "Checks a combatant's turn value.\n" +
		"The turn value is used in to generate the turn order in 'Turn Based Battles' using 'Multi Turns'." +
		"If the check is valid, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Battle/Combatant", "Combatant/Status", "Check/Battle")]
	public class CheckTurnValueStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Check Type", "Checks if the turn value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the turn value is between two defined values, including the values.\n" +
			"Range exclusive checks if the turn value is between two defined values, excluding the values.\n" +
			"Approximately checks if the turn value is similar to the defined value.", "")]
		public VariableValueCheck check = VariableValueCheck.IsEqual;

		[ORKEditorInfo(separator=true, labelText="Check Value")]
		public EventFloat turn = new EventFloat();

		[ORKEditorInfo(separator=true, labelText="Check Value 2")]
		[ORKEditorLayout(new string[] {"check", "check"},
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive},
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public EventFloat turn2;


		// object
		[ORKEditorHelp("Needed", "Either all or only one combatant's turn value check must be valid.", "")]
		[ORKEditorInfo(separator=true, labelText="Check Object",
			isEnumToolbar=true, toolbarWidth=75)]
		public Needed needed = Needed.One;

		public EventObjectSetting checkObject = new EventObjectSetting();

		[ORKEditorHelp("Use Average", "Use the average turn value of the combatant's group.", "")]
		public bool useAverage = false;

		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;

		public CheckTurnValueStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.DoCheck(ComponentHelper.GetCombatants(this.checkObject.GetObject(baseEvent)),
				this.turn.GetValue(baseEvent),
				this.turn2 != null ? this.turn2.GetValue(baseEvent) : 0))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}

		private bool DoCheck(List<Combatant> list, float value, float value2)
		{
			if(list.Count > 0)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(ValueHelper.CheckVariableValue(
						this.useAverage ?
							(this.onlyBattle ?
								list[i].Group.AverageBattleTurnValue :
								list[i].Group.AverageTurnValue) :
							list[i].Battle.TurnValue,
						value, value2, this.check))
					{
						if(Needed.One == needed)
						{
							return true;
						}
					}
					else if(Needed.All == needed)
					{
						return false;
					}
				}
				if(Needed.All == needed)
				{
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.checkObject.GetInfoText() + ": " +
				this.check.ToString() + " " + this.turn.GetInfoText() +
				(this.turn2 != null ? " ~ " + this.turn2.GetInfoText() : "");
		}
	}

	[ORKEditorHelp("Change Action Bar", "Changes the action bar of a combatant.\n" +
		"In 'Turn Based Battles' and 'Phase Battles', this will change the actions per turn of the combatant.\n" +
		"In 'Active Time Battles', this will change the timebar of the combatant.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle/Combatant", "Combatant/Status")]
	public class ChangeActionBarStep : BaseEventStep
	{
		[ORKEditorInfo(labelText="User Object")]
		public EventObjectSetting user = new EventObjectSetting();

		[ORKEditorHelp("Used Action Bar", "Change the 'Used Action Bar' instead of the 'Action Bar'.\n" +
			"The 'Used Action Bar' defines how much of the action bar is already used by actions.\n" +
			"In 'Turn Based Battles' and 'Phase Battles', the used action bar will be increased by the actions the combatant selected.\n" +
			"In 'Active Time Battles', the used action bar defines how much of the timebar has already been used.\n" +
			"E.g. use this to reset the used action bar to 0, to allow using actions from the start.", "")]
		public bool usedActionBar = false;


		// turn value change
		[ORKEditorHelp("Operator", "Defines how the action bar will be changed:\n" +
			"- Add: Adds the value to the current action bar value.\n" +
			"- Sub: Subtracts the value from the current action bar value.\n" +
			"- Multiply: Multiplies the current action bar value with the value.\n" +
			"- Divide: Divides the current action bar value by the value.\n" +
			"- Modulo: Uses the modulo operator, current action bar value % the value.\n" +
			"- Power Of: The current action bar value to the power of the value.\n" +
			"- Log: The current action bar value is used in a logarithmic calculation with the value as base.\n" +
			"- Set: Sets the current action bar value to the value.", "")]
		[ORKEditorInfo(separator=true, labelText="Action Bar Change")]
		public FormulaOperator op = FormulaOperator.Set;

		public EventFloat value = new EventFloat();

		[ORKEditorHelp("Result Rounding", "Rounds the result of the action bar change.\n" +
			"- None: No rounding.\n" +
			"- Ceil: The value will be rounded up (e.g. 14.2 will become 15).\n" +
			"- Floor: The value will be rounded down (e.g. 14.8 will become 14).\n" +
			"- Round: The value will be rounded to the nearest integer (e.g. 14.2 will become 14, 14.8 will become 15).", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public Rounding rounding = Rounding.None;

		public ChangeActionBarStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> userList = this.user.GetCombatant(baseEvent);
			for(int i = 0; i < userList.Count; i++)
			{
				if(userList[i] != null)
				{
					if(this.usedActionBar)
					{
						float tmp = userList[i].Battle.UsedActionBar;
						ValueHelper.UseOperator(ref tmp, this.value.GetValue(baseEvent), this.op);
						userList[i].Battle.UsedActionBar = ValueHelper.GetRounded(tmp, this.rounding);
					}
					else
					{
						float tmp = userList[i].Battle.ActionBar;
						ValueHelper.UseOperator(ref tmp, this.value.GetValue(baseEvent), this.op);
						userList[i].Battle.ActionBar = ValueHelper.GetRounded(tmp, this.rounding);
					}
				}
			}

			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.user.GetInfoText() + ": " + this.op.ToString() +
				" " + this.value.GetInfoText();
		}
	}

	[ORKEditorHelp("Check Action Bar", "Checks a combatant's action bar.\n" +
		"In 'Turn Based Battles' and 'Phase Battles', the action bar represents the actions per turn of the combatant.\n" +
		"In 'Active Time Battles', the action bar represents the timebar of the combatant." +
		"If the check is valid, 'Success' will be executed, else 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Battle/Combatant", "Combatant/Status", "Check/Battle")]
	public class CheckActionBarStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Check Type", "Checks if the action bar value is equal, not equal, less or greater than a defined value.\n" +
			"Range inclusive checks if the action bar value is between two defined values, including the values.\n" +
			"Range exclusive checks if the action bar value is between two defined values, excluding the values.\n" +
			"Approximately checks if the action bar value is similar to the defined value.", "")]
		public VariableValueCheck check = VariableValueCheck.IsEqual;

		[ORKEditorInfo(separator=true, labelText="Check Value")]
		public EventFloat turn = new EventFloat();

		[ORKEditorInfo(separator=true, labelText="Check Value 2")]
		[ORKEditorLayout(new string[] {"check", "check"},
			new System.Object[] {VariableValueCheck.RangeInclusive, VariableValueCheck.RangeExclusive},
			needed=Needed.One, endCheckGroup=true, autoInit=true)]
		public EventFloat turn2;


		// object
		[ORKEditorHelp("Needed", "Either all or only one combatant's action bar value check must be valid.", "")]
		[ORKEditorInfo(separator=true, labelText="Check Object",
			isEnumToolbar=true, toolbarWidth=75)]
		public Needed needed = Needed.One;

		public EventObjectSetting checkObject = new EventObjectSetting();

		[ORKEditorHelp("Used Action Bar", "Check the 'Used Action Bar' instead of the 'Action Bar'.\n" +
			"The 'Used Action Bar' defines how much of the action bar is already used by actions.\n" +
			"In 'Turn Based Battles' and 'Phase Battles', the used action bar will be increased by the actions the combatant selected.\n" +
			"In 'Active Time Battles', the used action bar defines how much of the timebar has already been used.\n" +
			"E.g. use this to check if a combatant already chose actions by checking if the used action bar equals 0.", "")]
		public bool usedActionBar = false;

		[ORKEditorHelp("Use Average", "Use the average action bar value of the combatant's group.", "")]
		public bool useAverage = false;

		[ORKEditorHelp("Only Battle", "Only the battle members are used.\n" +
			"If disabled, the whole group will be used.", "")]
		[ORKEditorLayout("useAverage", true, endCheckGroup=true)]
		public bool onlyBattle = true;

		public CheckActionBarStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.DoCheck(ComponentHelper.GetCombatants(this.checkObject.GetObject(baseEvent)),
				this.turn.GetValue(baseEvent),
				this.turn2 != null ? this.turn2.GetValue(baseEvent) : 0))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}

		private bool DoCheck(List<Combatant> list, float value, float value2)
		{
			if(list.Count > 0)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(ValueHelper.CheckVariableValue(
						this.useAverage ?
							(this.onlyBattle ?
								(this.usedActionBar ?
									list[i].Group.AverageBattleUsedActionBar :
									list[i].Group.AverageBattleActionBar) :
								(this.usedActionBar ?
									list[i].Group.AverageUsedActionBar :
									list[i].Group.AverageActionBar)) :
							(this.usedActionBar ?
								list[i].Battle.UsedActionBar :
								list[i].Battle.ActionBar),
						value, value2, this.check))
					{
						if(Needed.One == needed)
						{
							return true;
						}
					}
					else if(Needed.All == needed)
					{
						return false;
					}
				}
				if(Needed.All == needed)
				{
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.checkObject.GetInfoText() + ": " +
				this.check.ToString() + " " + this.turn.GetInfoText() +
				(this.turn2 != null ? " ~ " + this.turn2.GetInfoText() : "");
		}
	}

	[ORKEditorHelp("Change AI Controlled", "Changes if a combatant is AI controlled or not.\n" +
		"This is only used for combatants of the player group - other combatants are always AI controlled.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Battle/Combatant")]
	public class ChangeAIControlledStep : BaseEventStep
	{
		[ORKEditorHelp("AI Controlled", "The combatant is AI controlled.\n" +
			"If disabled, the combatant isn't AI controlled.", "")]
		public bool aiControlled = false;

		// combatant settings
		[ORKEditorInfo(separator=true, labelText="Object Settings")]
		public EventObjectSetting usedObject = new EventObjectSetting();

		public ChangeAIControlledStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = this.usedObject.GetCombatant(baseEvent);

			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					list[i].AI.AIControlled = this.aiControlled;
				}
			}

			baseEvent.StepFinished(this.next);
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.usedObject.GetInfoText() +
				(this.aiControlled ? ": AI controlled" : ": Not AI controlled");
		}
	}

	[ORKEditorHelp("Is AI Controlled", "Checks if a combatant is AI controlled.\n" +
		"Combatants that are not part of the player group are always AI controlled.\n" +
		"If the combatant is AI controlled, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Battle/Combatant", "Check/Battle")]
	public class IsAIControlledStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Needed", "Either all or only one of the combatants must be AI controlled.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public Needed needed = Needed.All;

		[ORKEditorInfo(separator=true, labelText="Combatant")]
		public EventObjectSetting onObject = new EventObjectSetting();

		public IsAIControlledStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.DoCheck(this.onObject.GetCombatant(baseEvent)))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}

		private bool DoCheck(List<Combatant> list)
		{
			if(list.Count > 0)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i].IsAIControlled())
					{
						if(Needed.One == needed)
						{
							return true;
						}
					}
					else if(Needed.All == needed)
					{
						return false;
					}
				}
				if(Needed.All == needed)
				{
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.onObject.GetInfoText();
		}
	}

	[ORKEditorHelp("Block Battle AI", "Blocks or unblocks the battle AI of a combatant.\n" +
		"AI controlled combatants will only use the 'None' action if their battle AI is blocked.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Battle/Combatant")]
	public class BlockBattleAIStep : BaseEventStep
	{
		[ORKEditorHelp("Block/Unblock", "If enabled, the battle AI will be blocked.\n" +
			"If disabled, the battle AI will be unblocked.", "")]
		public bool block = false;

		[ORKEditorInfo(separator=true, labelText="Combatant")]
		public EventObjectSetting onObject = new EventObjectSetting();

		public BlockBattleAIStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = this.onObject.GetCombatant(baseEvent);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					list[i].AI.Blocked = this.block;
				}
			}

			baseEvent.StepFinished(this.next);
		}

		public override bool ExecuteOnStop
		{
			get { return true; }
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.onObject.GetInfoText() + ": " +
				(this.block ? "Block" : "Unblock");
		}
	}

	[ORKEditorHelp("Is Battle AI Blocked", "Checks if a combatant's battle AI is blocked.\n" +
		"If the battle AI is blocked, 'Success' will be executed, otherwise 'Failed'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Battle/Combatant", "Check/Battle")]
	public class IsBattleAIBlockedStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Needed", "Either all or only one of the combatants must have a blocked battle AI.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public Needed needed = Needed.All;

		[ORKEditorInfo(separator=true, labelText="Combatant")]
		public EventObjectSetting onObject = new EventObjectSetting();

		public IsBattleAIBlockedStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.DoCheck(this.onObject.GetCombatant(baseEvent)))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}

		private bool DoCheck(List<Combatant> list)
		{
			if(list.Count > 0)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i].AI.Blocked)
					{
						if(Needed.One == needed)
						{
							return true;
						}
					}
					else if(Needed.All == needed)
					{
						return false;
					}
				}
				if(Needed.All == needed)
				{
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.onObject.GetInfoText();
		}
	}

	[ORKEditorHelp("Change Aggression State", "Changes if a combatant is aggressive or not.", "")]
	[ORKEventStep(typeof(GameEvent), typeof(BattleEvent), typeof(BattleStartEvent), typeof(BattleEndEvent), typeof(PhaseChangeEvent))]
	[ORKNodeInfo("Battle/Combatant")]
	public class ChangeAggressionStateStep : BaseEventStep
	{
		[ORKEditorHelp("Is Aggressive", "If enabled, the combatant will be set aggressive.\n" +
			"If disabled, the combatant will be set not aggressive.", "")]
		public bool isAggressive = false;

		[ORKEditorInfo(separator=true, labelText="Combatant")]
		public EventObjectSetting onObject = new EventObjectSetting();

		public ChangeAggressionStateStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			List<Combatant> list = this.onObject.GetCombatant(baseEvent);
			for(int i = 0; i < list.Count; i++)
			{
				if(list[i] != null)
				{
					list[i].IsAggressive = this.isAggressive;
				}
			}

			baseEvent.StepFinished(this.next);
		}

		public override bool ExecuteOnStop
		{
			get { return true; }
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.onObject.GetInfoText() + ": " +
				(this.isAggressive ? "Aggressive" : "Not Aggressive");
		}
	}

	[ORKEditorHelp("Is Aggressive", "Checks if a combatant is aggressive.\n" +
		"If the combatant is aggressive, 'Aggressive' will be executed, otherwise 'Not Aggressive'.", "")]
	[ORKEventStep(typeof(BaseEvent))]
	[ORKNodeInfo("Battle/Combatant", "Combatant/Combatant", "Check/Battle")]
	public class IsAggressiveStep : BaseEventCheckStep
	{
		[ORKEditorHelp("Needed", "Either all or only one of the combatants must be aggressive.", "")]
		[ORKEditorInfo(isEnumToolbar=true, toolbarWidth=75)]
		public Needed needed = Needed.All;

		[ORKEditorInfo(separator=true, labelText="Combatant")]
		public EventObjectSetting onObject = new EventObjectSetting();

		public IsAggressiveStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(this.DoCheck(this.onObject.GetCombatant(baseEvent)))
			{
				baseEvent.StepFinished(this.next);
			}
			else
			{
				baseEvent.StepFinished(this.nextFail);
			}
		}

		private bool DoCheck(List<Combatant> list)
		{
			if(list.Count > 0)
			{
				for(int i = 0; i < list.Count; i++)
				{
					if(list[i].IsAggressive)
					{
						if(Needed.One == needed)
						{
							return true;
						}
					}
					else if(Needed.All == needed)
					{
						return false;
					}
				}
				if(Needed.All == needed)
				{
					return true;
				}
			}
			return false;
		}


		/*
		============================================================================
		Node name functions
		============================================================================
		*/
		public override string GetNodeDetails()
		{
			return this.onObject.GetInfoText();
		}

		public override string GetNextName(int index)
		{
			if(index == 0)
			{
				return "Aggressive";
			}
			else if(index == 1)
			{
				return "Not Aggressive";
			}
			return "";
		}
	}

	[ORKEditorHelp("Cancel Death", "Cancels the death of the combatant.\n" +
		"Only used during death actions.\n" +
		"Please note that this doesn't change any 'Consumable' type status values.", "")]
	[ORKEventStep(typeof(BattleEvent))]
	[ORKNodeInfo("Battle/Combatant")]
	public class CancelDeathStep : BaseEventStep
	{
		public CancelDeathStep()
		{

		}

		public override void Execute(BaseEvent baseEvent)
		{
			if(baseEvent is BattleEvent)
			{
				BattleEvent battleEvent = (BattleEvent)baseEvent;
				if(battleEvent.Action is DeathAction)
				{
					((DeathAction)battleEvent.Action).cancelDeath = true;
					battleEvent.Action.user.Dead = false;
				}
			}
			baseEvent.StepFinished(this.next);
		}
	}
}
