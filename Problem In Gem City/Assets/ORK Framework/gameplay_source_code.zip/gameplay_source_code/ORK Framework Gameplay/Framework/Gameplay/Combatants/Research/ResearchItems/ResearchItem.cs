﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ResearchItem : ISaveData, IContent
	{
		private int index = 0;

		private ResearchTree researchTree;

		private ResearchItemSetting setting;


		// research
		private bool[] costsConsumed;

		private float progress = 0;

		private float duration = 0;

		private int researchCount = 0;

		private ResearchItemState state = ResearchItemState.Unresearched;

		public ResearchItem(int index, ResearchTree researchTree, ResearchItemSetting setting)
		{
			this.index = index;
			this.researchTree = researchTree;
			this.setting = setting;

			if(ResearchItemType.Ability == this.setting.type &&
				this.setting.ability.HasLearned(this.researchTree.Handler.Owner))
			{
				this.researchCount = 1;
				this.state = ResearchItemState.Complete;
			}

			this.UpdateDuration();
		}


		/*
		============================================================================
		Get/set functions
		============================================================================
		*/
		public ResearchItemSetting Setting
		{
			get { return this.setting; }
		}

		public ResearchTree ResearchTree
		{
			get { return this.researchTree; }
		}

		public ResearchItemState State
		{
			get { return this.state; }
		}

		public int ResearchCount
		{
			get { return this.researchCount; }
		}

		public float ProgressValue
		{
			get { return this.progress; }
		}

		public float DurationValue
		{
			get { return this.duration; }
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public int ID
		{
			get { return this.index; }
		}

		public int TypeID
		{
			get { return this.setting.TypeID; }
		}

		public string GetName()
		{
			return this.setting.GetName();
		}

		public string GetDescription()
		{
			return this.setting.GetDescription();
		}

		public string GetIconTextCode()
		{
			return this.researchTree.Setting.GetIconTextCode(this.index);
		}

		public Texture GetIcon()
		{
			return this.setting.GetIcon();
		}

		public GUIContent GetContent()
		{
			return this.setting.GetContent();
		}

		public IContentSimple GetTypeContent()
		{
			return this.setting.GetTypeContent();
		}

		public string GetInfo(Combatant c)
		{
			return this.setting.GetCostString(c);
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool CanResearch()
		{
			return this.researchTree.CanResearch() &&
				(ResearchItemState.Unresearched == this.state ||
					ResearchItemState.Researched == this.state) &&
				this.setting.CanResearch(this.researchTree.Handler.Owner);
		}

		public ResearchDisplayType GetResearchDisplayType()
		{
			if(ResearchItemState.Complete == this.state)
			{
				return ResearchDisplayType.Complete;
			}
			else if(ResearchItemState.InResearch == this.state)
			{
				return ResearchDisplayType.InResearch;
			}
			else if(ResearchItemState.Unresearched == this.state ||
				ResearchItemState.Researched == this.state)
			{
				if(this.setting.CheckRequirements(this.researchTree.Handler.Owner))
				{
					if(this.setting.CheckCosts(this.researchTree.Handler.Owner))
					{
						if(!this.researchTree.CanResearch())
						{
							return ResearchDisplayType.LimitFail;
						}
					}
					else
					{
						return ResearchDisplayType.CostsFail;
					}
				}
				else
				{
					return ResearchDisplayType.RequirementsFail;
				}
			}
			return ResearchDisplayType.Researchable;
		}

		public bool CanCancel()
		{
			return ResearchItemState.InResearch == this.state &&
				this.setting.cancelable;
		}


		/*
		============================================================================
		Research functions
		============================================================================
		*/
		public void StartResearch()
		{
			if(this.researchTree.CanResearch() &&
				(ResearchItemState.Unresearched == this.state ||
					ResearchItemState.Researched == this.state) &&
				this.setting.StartResearch(this.researchTree.Handler.Owner, out this.costsConsumed))
			{
				if(ResearchItemDuration.None == this.setting.duration)
				{
					this.ResearchFinished();
				}
				else
				{
					this.state = ResearchItemState.InResearch;
					this.UpdateDuration();
					this.researchTree.ResearchStarted(true);
					this.ResearchTree.Setting.ShowResearchStarted(this.researchTree.Handler.Owner, this);
				}
			}
		}

		public void CancelResearch()
		{
			if(this.CanCancel())
			{
				this.state = this.researchCount > 0 ?
					ResearchItemState.Researched :
					ResearchItemState.Unresearched;
				if(!this.setting.cancelKeepProgress)
				{
					this.progress = 0;
				}
				if(this.setting.cancelRefundCosts &&
					this.costsConsumed != null)
				{
					this.setting.RefundCosts(this.researchTree.Handler.Owner, this.costsConsumed);
				}
				this.costsConsumed = null;
				this.researchTree.ResearchCanceled(true);
				this.ResearchTree.Setting.ShowResearchCanceled(this.researchTree.Handler.Owner, this);
			}
		}

		public void ResearchFinished()
		{
			this.researchCount++;
			this.setting.ResearchFinished(this.researchTree.Handler.Owner);

			if(this.setting.limitResearchTimes &&
				this.researchCount >= this.setting.researchTimes)
			{
				this.state = ResearchItemState.Complete;
			}
			else
			{
				this.progress = 0;
				this.state = ResearchItemState.Researched;
			}

			this.costsConsumed = null;
			this.researchTree.ResearchFinished(ResearchItemDuration.None != this.setting.duration);
			this.ResearchTree.Setting.ShowResearchFinished(this.researchTree.Handler.Owner, this);
		}

		public void ManualProgress(float add)
		{
			if(ResearchItemDuration.Manual == this.setting.duration)
			{
				this.Progress(add);
			}
		}

		public void TimeProgress(float add)
		{
			if(ResearchItemDuration.Time == this.setting.duration)
			{
				this.Progress(add);
			}
		}

		public void Progress(float add)
		{
			if(ResearchItemDuration.None != this.setting.duration &&
				ResearchItemState.InResearch == this.state)
			{
				this.progress += add;

				this.UpdateDuration();
				if(this.progress >= this.duration)
				{
					this.progress = this.duration;
					this.ResearchFinished();
				}
				else
				{
					this.researchTree.Handler.FireChanged();
				}
			}
		}

		public void UpdateDuration()
		{
			if(ResearchItemDuration.None != this.setting.duration)
			{
				this.duration = this.setting.durationValue.GetValue(
					this.researchTree.Handler.Owner, this.researchTree.Handler.Owner);

				if(this.progress >= this.duration)
				{
					this.progress = this.duration;
					this.ResearchFinished();
				}
			}
		}


		/*
		============================================================================
		Reset functions
		============================================================================
		*/
		public void ResetProgress()
		{
			if(ResearchItemState.InResearch == this.state)
			{
				this.researchTree.ResearchCanceled(true);
			}
			this.costsConsumed = null;
			this.progress = 0;
			this.duration = 0;
			this.researchCount = 0;
			this.state = ResearchItemState.Unresearched;
		}

		public void ResetManualProgress()
		{
			if(ResearchItemDuration.Manual == this.setting.duration)
			{
				this.ResetProgress();
			}
		}

		public void ResetTimeProgress()
		{
			if(ResearchItemDuration.Time == this.setting.duration)
			{
				this.ResetProgress();
			}
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();
			if(this.costsConsumed != null &&
				this.costsConsumed.Length > 0)
			{
				data.Set("costsConsumed", this.costsConsumed);
			}
			data.Set("progress", this.progress);
			data.Set("duration", this.duration);
			data.Set("researchCount", this.researchCount);
			data.Set("state", this.state);
			return data;
		}

		public void LoadGame(DataObject data)
		{
			if(data != null)
			{
				data.Get("costsConsumed", out this.costsConsumed);
				data.Get("progress", ref this.progress);
				data.Get("duration", ref this.duration);
				data.Get("researchCount", ref this.researchCount);
				data.Get("state", ref this.state);
			}
		}
	}
}
