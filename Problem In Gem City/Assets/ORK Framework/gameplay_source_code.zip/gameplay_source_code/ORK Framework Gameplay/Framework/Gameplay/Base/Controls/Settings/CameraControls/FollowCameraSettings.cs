﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class FollowCameraSettings : BaseData
	{
		[ORKEditorHelp("Use Child Object", "The camera will be positioned using a child object of the player (e.g. body/head).\n" +
			"Leave empty if you don't want to use a child object and place the camera using the root of the player object.", "")]
		[ORKEditorInfo(expandWidth=true)]
		public string onChild = "";
		
		[ORKEditorHelp("Distance", "The distance of the camera to the player.", "")]
		[ORKEditorInfo(separator=true)]
		public float distance = 10.0f;

		[ORKEditorHelp("Height", "The height above the player.", "")]
		public float height = 5.0f;

		[ORKEditorHelp("Height Damping", "Used for smoother height changes.\n" +
			"Higher values mean quicker changes, set to 0 to disable.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float heightDamping = 2.0f;

		[ORKEditorHelp("Rotation Damping", "Used for smoother rotation changes.\n" +
			"Higher values mean quicker changes, set to 0 to disable.", "")]
		[ORKEditorLimit(0.0f, false)]
		public float rotationDamping = 3.0f;

		public FollowCameraSettings()
		{

		}

		public void Setup(GameObject camera)
		{
			if(camera != null)
			{
				SmoothFollow comp = camera.GetComponent<SmoothFollow>();
				if(comp == null)
				{
					comp = camera.AddComponent<SmoothFollow>();

					comp.onChild = this.onChild;
					comp.distance = this.distance;
					comp.height = this.height;
					comp.heightDamping = this.heightDamping;
					comp.rotationDamping = this.rotationDamping;

					ORK.Control.AddCameraControl(comp);
				}
			}
		}
	}
}
