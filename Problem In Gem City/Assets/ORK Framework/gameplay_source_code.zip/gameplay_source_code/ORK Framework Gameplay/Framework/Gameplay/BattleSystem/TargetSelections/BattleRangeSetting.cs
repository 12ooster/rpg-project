﻿
using UnityEngine;
using ORKFramework.Behaviours;
using System.Collections.Generic;

namespace ORKFramework
{
	public class BattleRangeSetting : BaseData
	{
		// range settings
		[ORKEditorHelp("Minimum Range", "A minimum range is used.", "")]
		[ORKEditorInfo("Range Settings", "Define the minimum and maximum range of this battle range.", "")]
		public bool useMin = false;

		[ORKEditorLayout("useMin", true, endCheckGroup=true, autoInit=true)]
		public Range minRange;

		[ORKEditorHelp("Maximum Range", "A maximum range is used.", "")]
		[ORKEditorInfo(separator=true)]
		public bool useMax = false;

		[ORKEditorLayout("useMax", true, endCheckGroup=true, autoInit=true)]
		public Range maxRange;

		// move AI
		[ORKEditorHelp("Move Into Range", "Use the move AI to move into range if the target is out of range.\n" +
			"Only used when the move AI is allowed in battle and the combatant can move.", "")]
		[ORKEditorInfo(separator=true, labelText="Move AI Settings")]
		public bool moveAIMoveIntoRange = true;

		// check only for angle, defining angle threshold?
		[ORKEditorHelp("Use Stop Angle", "If the hunt or caution settings of the move AI use a stop angle, " +
			"the action can only be used from the angled position when moving into range.", "")]
		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("moveAIMoveIntoRange", true, endCheckGroup=true)]
		public bool moveAIUseStopAngle = false;


		// grid range settings
		[ORKEditorHelp("Shape Type", "Select the type of this grid shape:\n" +
			"- None: Uses the range settings (i.e. no special grid handling).\n" +
			"- All: Uses the whole grid.\n" +
			"- Range: All cells within a defined range of the origin cell.\n" +
			"- Mask: Only defined cells around the origin cell.\n" +
			"- Ring: All cells on a ring with a defined range (radius) around the origin cell.", "")]
		[ORKEditorInfo("Grid Shape", "Define the grid shape of this battle range.\n" +
			"The grid shape is only used in battles that use a 'Battle Grid'.", "")]
		public GridShapeType gridShapeType = GridShapeType.None;

		[ORKEditorHelp("Range (Cells)", "The range around the origin cell in cells.\n" +
			"This defines the available cells for selection when using 'Mask' type.", "")]
		[ORKEditorLimit(0, false)]
		[ORKEditorLayout(new string[] { "gridShapeType", "gridShapeType", "gridShapeType" },
			new System.Object[] { GridShapeType.Range, GridShapeType.Mask, GridShapeType.Ring },
			needed=Needed.One, endCheckGroup=true)]
		public int gridRange = 1;

		// cell settings
		[ORKEditorHelp("Add Origin Cell", "The origin cell will also be used by this shape.\n" +
			"If disabled, only the cells around the origin cell will be used.", "")]
		[ORKEditorLayout("gridShapeType", GridShapeType.Range, endCheckGroup=true)]
		public bool addOriginCell = true;

		[ORKEditorHelp("Add Blocked Cells", "Blocked cells will be selected by this shape.\n" +
			"If disabled, blocked cells will be omitted.", "")]
		[ORKEditorLayout("gridShapeType", GridShapeType.None, elseCheckGroup=true)]
		public bool addBlockedCells = false;

		[ORKEditorHelp("Add Not Passable Cells", "Blocked cells that are not passable will be selected by this shape.\n" +
			"If disabled, blocked cells that aren't passable will be omitted.", "")]
		[ORKEditorLayout("addBlockedCells", true, endCheckGroup=true, endGroups=2)]
		public bool addNotPassableCells = false;

		[ORKEditorHelp("Local Space", "The shape will be rotated in the local space of the combatant using it.\n" +
			"If disabled, the shape is rotated in world space.", "")]
		[ORKEditorLayout("gridShapeType", GridShapeType.Mask, endCheckGroup=true)]
		public bool shapeLocalSpace = false;

		// line of sight
		[ORKEditorHelp("Use Line of Sight", "Use a line of sight between the center of the origin cell " +
			"and the center of the used cells to determine if they're available.", "")]
		[ORKEditorInfo(separator=true, labelText="Line of Sight")]
		public bool useLineOfSight = false;

		[ORKEditorHelp("LOS Blocked Cells", "Blocked cells will block the line of sight.", "")]
		[ORKEditorLayout("useLineOfSight", true)]
		public bool losBlockedCells = true;

		[ORKEditorHelp("LOS Passable Cells", "Blocked cells that are passable will block the line of sight.", "")]
		[ORKEditorLayout("losBlockedCells", true, endCheckGroup=true)]
		public bool losPassableCells = false;

		[ORKEditorHelp("LOS Allied Combatants", "Cells occupied by allied combatants will block the line of sight.", "")]
		public bool losAlliedCombatants = true;

		[ORKEditorHelp("LOS Enemy Combatants", "Cells occupied by enemy combatants will block the line of sight.", "")]
		public bool losEnemyCombatants = true;

		[ORKEditorHelp("LOS Check Cell Types", "Defined grid cell types will block the line of sight.", "")]
		public bool losCheckCellTypes = false;

		[ORKEditorHelp("Grid Cell Type", "Select the grid cell type that will block the line of sight.", "")]
		[ORKEditorInfo(ORKDataType.BattleGridCellType, noAutoAdd=true)]
		[ORKEditorArray(false, "Add Cell Type", "Adds a grid cell type that will block the line of sight.", "",
			"Remove", "Removes the grid cell type.", "", isHorizontal=true)]
		[ORKEditorLayout("losCheckCellTypes", true, endCheckGroup=true, endGroups=2, autoInit=true)]
		public int[] losCellType;

		// shape mask
		[ORKEditorInfo(hide=true, instanceCallback="editor:GridShapeMask", endFoldout=true)]
		[ORKEditorLayout("gridShapeType", GridShapeType.Mask, endCheckGroup=true,
			setDefault=true, defaultValue=null)]
		public GridShapeMask gridShapeMask;

		public BattleRangeSetting()
		{

		}

		public Range GetMoveAIUseRange()
		{
			if(this.useMin)
			{
				return this.minRange.GetOutOfRange();
			}
			else if(this.useMax)
			{
				return this.maxRange.GetInRange();
			}
			return null;
		}


		/*
		============================================================================
		Range functions
		============================================================================
		*/
		public bool InRange(Combatant user, Combatant target)
		{
			if(ORK.Battle.Grid != null &&
				GridShapeType.None != this.gridShapeType &&
				user != null && user.GridCell != null)
			{
				List<Combatant> list = new List<Combatant>();
				this.GetCellCombatants(user.GridCell, ref list, null);
				return list.Contains(target);
			}
			else
			{
				return (!this.useMin || this.minRange.OutOfRange(user, target)) &&
					(!this.useMax || this.maxRange.InRange(user, target));
			}
		}

		public bool InRange(Combatant user, Vector3 position)
		{
			return (!this.useMin || this.minRange.OutOfRange(position, user)) &&
				(!this.useMax || this.maxRange.InRange(position, user));
		}

		public List<Combatant> GetTargets(Combatant user, Consider isEnemy, Consider isDead, Consider inBattle)
		{
			List<Combatant> list = null;
			if(ORK.Battle.Grid != null &&
				GridShapeType.None != this.gridShapeType &&
				user != null && user.GridCell != null)
			{
				list = new List<Combatant>();
				this.GetCellCombatants(user.GridCell, ref list, null);
			}
			else
			{
				list = ORK.Game.Combatants.Get(user,
					true, this.useMax ? this.maxRange : null, isEnemy, isDead, inBattle);
				if(this.useMin)
				{
					for(int i = 0; i < list.Count; i++)
					{
						if(!this.minRange.OutOfRange(user, list[i]))
						{
							list.RemoveAt(i--);
						}
					}
				}
			}
			return list;
		}


		/*
		============================================================================
		Cell functions
		============================================================================
		*/
		public bool BlocksGridLineOfSight(BattleGridCellComponent origin, BattleGridCellComponent cell)
		{
			if(this.useLineOfSight)
			{
				if((this.losBlockedCells && cell.IsBlocked &&
					(this.losPassableCells || !cell.IsPassable)) ||
					(this.losAlliedCombatants &&
						cell.Combatant != null &&
						origin.Combatant != null &&
						!origin.Combatant.IsEnemy(cell.Combatant)) ||
					(this.losEnemyCombatants &&
						cell.Combatant != null &&
						origin.Combatant != null &&
						origin.Combatant.IsEnemy(cell.Combatant)))
				{
					return true;
				}
				else if(this.losCheckCellTypes &&
					this.losCellType != null)
				{
					for(int i = 0; i < this.losCellType.Length; i++)
					{
						if(this.losCellType[i] == cell.cellTypeID)
						{
							return true;
						}
					}
				}
			}
			return false;
		}

		public void GetCells(BattleGridCellComponent origin,
			ref List<BattleGridCellComponent> list, GridCellCheck check)
		{
			if(origin != null)
			{
				if(GridShapeType.All == this.gridShapeType)
				{
					if(origin.parentGrid != null &&
						origin.parentGrid.cellRow != null)
					{
						for(int i = 0; i < origin.parentGrid.cellRow.Length; i++)
						{
							for(int j = 0; j < origin.parentGrid.cellRow[i].cell.Length; j++)
							{
								if(origin.parentGrid.cellRow[i].cell[j] != null &&
									(this.addBlockedCells || !origin.parentGrid.cellRow[i].cell[j].IsBlocked) &&
									(this.addNotPassableCells || origin.parentGrid.cellRow[i].cell[j].IsPassable) &&
									(check == null || check(origin.parentGrid.cellRow[i].cell[j])) &&
									!list.Contains(origin.parentGrid.cellRow[i].cell[j]) &&
									(!this.useLineOfSight || BattleGridHelper.CheckLineOfSight(origin,
										origin.parentGrid.cellRow[i].cell[j], this.BlocksGridLineOfSight)))
								{
									list.Add(origin.parentGrid.cellRow[i].cell[j]);
								}
							}
						}
					}
				}
				else if(GridShapeType.Range == this.gridShapeType)
				{
					BattleGridHelper.GetRange(origin, this.gridRange, ref list,
						this.addBlockedCells, this.addNotPassableCells, check);
					if(this.useLineOfSight)
					{
						for(int i = 0; i < list.Count; i++)
						{
							if(!BattleGridHelper.CheckLineOfSight(origin,
								list[i], this.BlocksGridLineOfSight))
							{
								list.RemoveAt(i--);
							}
						}
					}
				}
				else if(GridShapeType.Mask == this.gridShapeType)
				{
					if(this.gridShapeMask != null &&
						this.gridShapeMask.cell != null)
					{
						if(this.shapeLocalSpace &&
							origin.Combatant != null)
						{
							int turns = BattleGridHelper.GetCombatantDirection(origin.Combatant);
							for(int i = 0; i < this.gridShapeMask.cell.Length; i++)
							{
								if(this.gridShapeMask.cell[i] != null &&
									this.gridShapeMask.cell[i].selected)
								{
									BattleGridCellComponent cell = origin.parentGrid.GetCell(
										origin.CubeCoord + this.gridShapeMask.cell[i].coord.Rotate(turns));
									if(cell != null &&
										(this.addBlockedCells || !cell.IsBlocked) &&
										(this.addNotPassableCells || cell.IsPassable) &&
										(check == null || check(cell)) &&
										!list.Contains(cell) &&
										(!this.useLineOfSight || BattleGridHelper.CheckLineOfSight(origin,
											cell, this.BlocksGridLineOfSight)))
									{
										list.Add(cell);
									}
								}
							}
						}
						else
						{
							for(int i = 0; i < this.gridShapeMask.cell.Length; i++)
							{
								if(this.gridShapeMask.cell[i] != null &&
									this.gridShapeMask.cell[i].selected)
								{
									BattleGridCellComponent cell = origin.parentGrid.GetCell(
										origin.CubeCoord + this.gridShapeMask.cell[i].coord);
									if(cell != null &&
										(this.addBlockedCells || !cell.IsBlocked) &&
										(this.addNotPassableCells || cell.IsPassable) &&
										(check == null || check(cell)) &&
										!list.Contains(cell) &&
										(!this.useLineOfSight || BattleGridHelper.CheckLineOfSight(origin,
											cell, this.BlocksGridLineOfSight)))
									{
										list.Add(cell);
									}
								}
							}
						}
					}
				}
				else if(GridShapeType.Ring == this.gridShapeType)
				{
					BattleGridHelper.GetRing(origin, this.gridRange, ref list,
						this.addBlockedCells, this.addNotPassableCells, check);
					if(this.useLineOfSight)
					{
						for(int i = 0; i < list.Count; i++)
						{
							if(!BattleGridHelper.CheckLineOfSight(origin,
								list[i], this.BlocksGridLineOfSight))
							{
								list.RemoveAt(i--);
							}
						}
					}
				}
			}
		}

		public void GetCellCombatants(BattleGridCellComponent origin,
			ref List<Combatant> list, GridCellCheck check)
		{
			if(origin != null)
			{
				if(GridShapeType.All == this.gridShapeType)
				{
					if(origin.parentGrid != null &&
						origin.parentGrid.cellRow != null)
					{
						for(int i = 0; i < origin.parentGrid.cellRow.Length; i++)
						{
							for(int j = 0; j < origin.parentGrid.cellRow[i].cell.Length; j++)
							{
								if(origin.parentGrid.cellRow[i].cell[j] != null &&
									!origin.parentGrid.cellRow[i].cell[j].IsEmpty &&
									(this.addBlockedCells || !origin.parentGrid.cellRow[i].cell[j].IsBlocked) &&
									(this.addNotPassableCells || origin.parentGrid.cellRow[i].cell[j].IsPassable) &&
									(check == null || check(origin.parentGrid.cellRow[i].cell[j])) &&
									(!this.useLineOfSight || BattleGridHelper.CheckLineOfSight(origin,
										origin.parentGrid.cellRow[i].cell[j], this.BlocksGridLineOfSight)))
								{
									origin.parentGrid.cellRow[i].cell[j].GetCombatants(ref list, null);
								}
							}
						}
					}
				}
				else if(GridShapeType.Range == this.gridShapeType)
				{
					BattleGridHelper.GetRangeCombatants(origin, this.gridRange, ref list,
						this.addBlockedCells, this.addNotPassableCells, check);
					if(this.useLineOfSight)
					{
						for(int i = 0; i < list.Count; i++)
						{
							if(!BattleGridHelper.CheckLineOfSight(origin,
								list[i].GridCell, this.BlocksGridLineOfSight))
							{
								list.RemoveAt(i--);
							}
						}
					}
				}
				else if(GridShapeType.Mask == this.gridShapeType)
				{
					if(this.gridShapeMask != null &&
						this.gridShapeMask.cell != null)
					{
						if(this.shapeLocalSpace &&
							origin.Combatant != null)
						{
							int turns = BattleGridHelper.GetCombatantDirection(origin.Combatant);
							for(int i = 0; i < this.gridShapeMask.cell.Length; i++)
							{
								if(this.gridShapeMask.cell[i] != null &&
									this.gridShapeMask.cell[i].selected)
								{
									BattleGridCellComponent cell = origin.parentGrid.GetCell(
										origin.CubeCoord + this.gridShapeMask.cell[i].coord.Rotate(turns));
									if(cell != null && !cell.IsEmpty &&
										(this.addBlockedCells || !cell.IsBlocked) &&
										(this.addNotPassableCells || cell.IsPassable) &&
										(check == null || check(cell)) &&
										(!this.useLineOfSight || BattleGridHelper.CheckLineOfSight(origin,
											cell, this.BlocksGridLineOfSight)))
									{
										cell.GetCombatants(ref list, null);
									}
								}
							}
						}
						else
						{
							for(int i = 0; i < this.gridShapeMask.cell.Length; i++)
							{
								if(this.gridShapeMask.cell[i] != null &&
									this.gridShapeMask.cell[i].selected)
								{
									BattleGridCellComponent cell = origin.parentGrid.GetCell(
										origin.CubeCoord + this.gridShapeMask.cell[i].coord);
									if(cell != null && !cell.IsEmpty &&
										(this.addBlockedCells || !cell.IsBlocked) &&
										(this.addNotPassableCells || cell.IsPassable) &&
										(check == null || check(cell)) &&
										(!this.useLineOfSight || BattleGridHelper.CheckLineOfSight(origin,
											cell, this.BlocksGridLineOfSight)))
									{
										cell.GetCombatants(ref list, null);
									}
								}
							}
						}
					}
				}
				else if(GridShapeType.Ring == this.gridShapeType)
				{
					BattleGridHelper.GetRingCombatants(origin, this.gridRange, ref list,
						this.addBlockedCells, this.addNotPassableCells, check);
					if(this.useLineOfSight)
					{
						for(int i = 0; i < list.Count; i++)
						{
							if(!BattleGridHelper.CheckLineOfSight(origin,
								list[i].GridCell, this.BlocksGridLineOfSight))
							{
								list.RemoveAt(i--);
							}
						}
					}
				}
			}
		}
	}
}
