
namespace ORKFramework
{
	public class FactionBenefit : BaseLanguageData
	{
		// range
		[ORKEditorHelp("Minimum Sympathy", "The minimum sympathy this benefit is valid.", "")]
		[ORKEditorInfo("Benefit Settings", "Set the sympathy range and benefits.\n" +
			"A benefit will be used if a factions sympathy for the player is within " +
			"the minimum and maximum range of the benefit.", "", 
			labelText="Sympathy Range")]
		public float min = -1000;
		
		[ORKEditorHelp("Maximum Sympathy", "The maximum sympathy this benefit is valid.", "")]
		public float max = 1000;
		
		
		// shop price modifier
		[ORKEditorHelp("Buy Price Modifier", "The price items can be bought at shops of the faction will be multiplied by this number.", "")]
		[ORKEditorInfo(separator=true, labelText="Shop Price Modifiers")]
		public float buyMod = 1;
		
		[ORKEditorHelp("Sell Price Modifier", "The price items can be sold at shops of the faction will be multiplied by this number.", "")]
		[ORKEditorInfo(endFoldout=true)]
		public float sellMod = 1;
		
		public FactionBenefit()
		{
			
		}
		
		public FactionBenefit(string n) : base(n)
		{
			
		}
		
		public bool InSympathyRange(float value)
		{
			return value >= this.min && value <= this.max;
		}
	}
}

