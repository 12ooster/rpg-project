﻿
using UnityEngine;
using System.Collections.Generic;
using System.Text;
using System;

namespace ORKFramework
{
	public class ResearchItemSetting : BaseData
	{
		// settings
		[ORKEditorHelp("Type", "Select what will be researched:\n" +
			"- None: Nothing will be researched (e.g. can be used for requirements).\n" +
			"- Ability: Learns an ability to the user.\n" +
			"- Status Value: Gives a status value upgrade to the user.\n" +
			"- Item: Adds an item, equipment, currency, AI behaviour or AI ruleset to the inventory of the user.", "")]
		public ResearchItemType type = ResearchItemType.None;


		// research times
		[ORKEditorHelp("Limit Research Times", "Limit how often this research item can be researched.", "")]
		[ORKEditorInfo(separator=true)]
		[ORKEditorLayout("type", ResearchItemType.Ability, elseCheckGroup=true)]
		public bool limitResearchTimes = true;

		[ORKEditorHelp("Research Times", "Define how often this research item can be researched.", "")]
		[ORKEditorLimit(1, false)]
		[ORKEditorLayout("limitResearchTimes", true, endCheckGroup=true, endGroups=2)]
		public int researchTimes = 1;


		// duration
		[ORKEditorHelp("Research Duration", "Select how long the research of this item will take:\n" +
			"- None: The research is finished immediately.\n" +
			"- Manual: The research progresses manually using the event system.\n" +
			"- Time: The research takes a defined amount of time (in seconds).", "")]
		[ORKEditorInfo(separator=true)]
		public ResearchItemDuration duration = ResearchItemDuration.None;

		[ORKEditorInfo(labelText="Duration Value", label=new string[] {
			"The value (time) that must be reached to finish researching this item."
		})]
		[ORKEditorLayout("duration", ResearchItemDuration.None, elseCheckGroup=true, autoInit=true)]
		public FloatValue durationValue;


		// cancel
		[ORKEditorHelp("Cancelable", "Researching this item can be canceled.","")]
		[ORKEditorInfo(separator=true)]
		public bool cancelable = false;

		[ORKEditorHelp("Refund Costs", "Canceling the research will refund the costs " +
			"that where consumed for starting research of this item.", "")]
		[ORKEditorLayout("cancelable", true)]
		public bool cancelRefundCosts = false;

		[ORKEditorHelp("Keep Progress", "Canceling the research will keep the already achieved research progress.\n" +
			"Research will continue from the previous progress when the item is researched again.", "")]
		[ORKEditorLayout(endCheckGroup=true, endGroups=2)]
		public bool cancelKeepProgress = false;


		// ability
		[ORKEditorInfo("Ability Settings", "Define the ability that will be learnt.", "",
			endFoldout=true)]
		[ORKEditorLayout("type", ResearchItemType.Ability, endCheckGroup=true, autoInit=true)]
		public AbilityResearchItem ability;


		// status value
		[ORKEditorInfo("Status Value Settings", "Define the status value that will receive an upgrade.", "",
			endFoldout=true)]
		[ORKEditorLayout("type", ResearchItemType.StatusValue, endCheckGroup=true, autoInit=true)]
		public StatusValueResearchItem statusValue;


		// item, weapon, armor, currency
		[ORKEditorInfo("Item Settings", "Define the item that will be added to the inventory.", "",
			endFoldout=true)]
		[ORKEditorLayout("type", ResearchItemType.Item, endCheckGroup=true, autoInit=true)]
		public ItemResearchItem item;


		// none
		[ORKEditorLayout("type", ResearchItemType.None, autoInit=true)]
		public NoneResearchItem none;


		// override content
		[ORKEditorInfo("Override Content", "Optionally override the name, description or icon of the researched ability, status value or item.", "",
			endFoldout=true)]
		[ORKEditorLayout(elseCheckGroup=true, endCheckGroup=true, autoInit=true)]
		public OverrideLanguageContent overrideContent;


		// portrait
		[ORKEditorHelp("Use Portrait", "This research item has a portrait that can be displayed in menus.\n" +
			"If disabled, the portrait of the researched content (ability, item, etc.) is used (if available).", "")]
		[ORKEditorInfo("Portrait Settings", "The research item can display a portrait in menus when it's selected.", "")]
		public bool usePortrait = false;

		[ORKEditorInfo(endFoldout=true)]
		[ORKEditorLayout("usePortrait", true, endCheckGroup=true, autoInit=true)]
		public Portrait portrait;


		// variable changes
		[ORKEditorHelp("User Object Variables", "Change object variables on the user.", "")]
		[ORKEditorInfo("Finish Variable Changes", "Change global variables or object variables on the user when finishing research.", "")]
		public bool finishUserVariables = false;

		[ORKEditorInfo(endFoldout=true)]
		public VariableSetter finishVariables = new VariableSetter();


		// costs
		[ORKEditorInfo("Learn Costs", "Define the costs for researching this research item.\n" +
			"Research can cost 'Experience' type status values, items, equipment and currency.", "",
			endFoldout=true)]
		[ORKEditorArray(false, "Add Research Cost", "Adds a research cost.", "",
			"Remove", "Removes this research cost.", "", isCopy=true, isMove=true,
			removeType=ORKDataType.StatusValue, removeCheckField="statusID",
			foldout=true, foldoutText=new string[] {
				"Research Cost", "Research can consume 'Experience' type status values, items, equipment and currency.", ""
		})]
		public LearnCost[] learnCost = new LearnCost[0];


		// requirements
		[ORKEditorHelp("Needed", "Either all or only one requirement must be met.", "")]
		[ORKEditorInfo("Research Requirements", "Research can depend on status requirements of the user.", "",
			separator=true, isEnumToolbar=true, toolbarWidth=75)]
		public Needed needed = Needed.All;

		[ORKEditorInfo(endFoldout=true, instanceCallback="button:addpreviouscondition")]
		[ORKEditorArray(false, "Add Status Requirement", "Adds a status requirement.", "",
			"Remove", "Removes this requirement", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[] {
				"Status Requirement", "Researching can depend on status requirements.", ""
		})]
		public StatusRequirement[] learnRequirement = new StatusRequirement[0];

		public ResearchItemSetting()
		{

		}

		public Portrait GetPortrait()
		{
			if(this.usePortrait)
			{
				return this.portrait;
			}
			else if(ResearchItemType.Ability == this.type)
			{
				return this.ability.GetPortrait();
			}
			else if(ResearchItemType.Item == this.type)
			{
				return this.item.GetPortrait();
			}
			return null;
		}


		/*
		============================================================================
		Content functions
		============================================================================
		*/
		public int ID
		{
			get
			{
				if(ResearchItemType.None == this.type)
				{
					return this.none.ID;
				}
				else if(ResearchItemType.Ability == this.type)
				{
					return this.ability.ID;
				}
				else if(ResearchItemType.StatusValue == this.type)
				{
					return this.statusValue.ID;
				}
				else if(ResearchItemType.Item == this.type)
				{
					return this.item.ID;
				}
				return -1;
			}
		}

		public int TypeID
		{
			get
			{
				if(ResearchItemType.Ability == this.type)
				{
					return this.ability.TypeID;
				}
				else if(ResearchItemType.StatusValue == this.type)
				{
					return this.statusValue.TypeID;
				}
				else if(ResearchItemType.Item == this.type)
				{
					return this.item.TypeID;
				}
				return -1;
			}
		}

		public string GetName()
		{
			if(ResearchItemType.None == this.type)
			{
				return this.none.GetName();
			}
			else if(this.overrideContent.ownName)
			{
				return this.overrideContent.name[ORK.Game.Language];
			}
			else if(ResearchItemType.Ability == this.type)
			{
				return this.ability.GetName();
			}
			else if(ResearchItemType.StatusValue == this.type)
			{
				return this.statusValue.GetName();
			}
			else if(ResearchItemType.Item == this.type)
			{
				return this.item.GetName();
			}
			return "";
		}

		public string GetDescription()
		{
			if(ResearchItemType.None == this.type)
			{
				return this.none.GetDescription();
			}
			else if(this.overrideContent.ownDescription)
			{
				return this.overrideContent.description[ORK.Game.Language];
			}
			else if(ResearchItemType.Ability == this.type)
			{
				return this.ability.GetDescription();
			}
			else if(ResearchItemType.StatusValue == this.type)
			{
				return this.statusValue.GetDescription();
			}
			else if(ResearchItemType.Item == this.type)
			{
				return this.item.GetDescription();
			}
			return "";
		}

		public string GetIconTextCode(int treeID, int itemID)
		{
			if(ResearchItemType.None == this.type ||
				this.overrideContent.ownIcon)
			{
				return TextCode.ResearchItemIcon + treeID + "#" + itemID + "#";
			}
			else if(ResearchItemType.Ability == this.type)
			{
				return this.ability.GetIconTextCode();
			}
			else if(ResearchItemType.StatusValue == this.type)
			{
				return this.statusValue.GetIconTextCode();
			}
			else if(ResearchItemType.Item == this.type)
			{
				return this.item.GetIconTextCode();
			}
			return "";
		}

		public Texture GetIcon()
		{
			if(ResearchItemType.None == this.type)
			{
				return this.none.GetIcon();
			}
			else if(this.overrideContent.ownIcon)
			{
				return this.overrideContent.icon[ORK.Game.Language];
			}
			else if(ResearchItemType.Ability == this.type)
			{
				return this.ability.GetIcon();
			}
			else if(ResearchItemType.StatusValue == this.type)
			{
				return this.statusValue.GetIcon();
			}
			else if(ResearchItemType.Item == this.type)
			{
				return this.item.GetIcon();
			}
			return null;
		}

		public GUIContent GetContent()
		{
			if(ResearchItemType.None == this.type)
			{
				return this.none.GetContent();
			}
			else
			{
				GUIContent gc = null;
				if(ResearchItemType.Ability == this.type)
				{
					gc = this.ability.GetContent();
				}
				else if(ResearchItemType.StatusValue == this.type)
				{
					gc = this.statusValue.GetContent();
				}
				else if(ResearchItemType.Item == this.type)
				{
					gc = this.item.GetContent();
				}
				if(this.overrideContent.ownName)
				{
					gc.text = this.overrideContent.name[ORK.Game.Language];
				}
				if(this.overrideContent.ownIcon)
				{
					gc.image = this.overrideContent.icon[ORK.Game.Language];
				}
				return gc;
			}
		}

		public IContentSimple GetTypeContent()
		{
			if(ResearchItemType.Ability == this.type)
			{
				return this.ability.GetTypeContent();
			}
			else if(ResearchItemType.StatusValue == this.type)
			{
				return this.statusValue.GetTypeContent();
			}
			else if(ResearchItemType.Item == this.type)
			{
				return this.item.GetTypeContent();
			}
			return null;
		}


		/*
		============================================================================
		Check functions
		============================================================================
		*/
		public bool CanResearch(Combatant combatant)
		{
			return this.CheckCosts(combatant) &&
				this.CheckRequirements(combatant);
		}

		public bool CheckCosts(Combatant combatant)
		{
			if(combatant != null)
			{
				for(int i = 0; i < this.learnCost.Length; i++)
				{
					if(!this.learnCost[i].CheckCosts(combatant))
					{
						return false;
					}
				}
			}
			return true;
		}

		public bool CheckRequirements(Combatant combatant)
		{
			return combatant != null &&
				StatusRequirement.Check(combatant, this.learnRequirement, this.needed);
		}


		/*
		============================================================================
		Cost functions
		============================================================================
		*/
		public void ConsumeCosts(Combatant combatant, out bool[] consumed)
		{
			consumed = new bool[this.learnCost.Length];
			for(int i = 0; i < this.learnCost.Length; i++)
			{
				consumed[i] = this.learnCost[i].Consume(combatant);
			}
		}

		public void RefundCosts(Combatant combatant, bool[] consumed)
		{
			for(int i = 0; i < this.learnCost.Length; i++)
			{
				if(i < consumed.Length &&
					consumed[i])
				{
					this.learnCost[i].Refund(combatant);
				}
			}
		}

		public string GetCostString(Combatant combatant)
		{
			StringBuilder builder = new StringBuilder();
			for(int i = 0; i < this.learnCost.Length; i++)
			{
				this.learnCost[i].GetCostString(ref builder, combatant);
			}
			return builder.ToString();
		}


		/*
		============================================================================
		Research functions
		============================================================================
		*/
		public bool StartResearch(Combatant combatant, out bool[] consumed)
		{
			if(this.CanResearch(combatant))
			{
				this.ConsumeCosts(combatant, out consumed);
				return true;
			}
			else
			{
				consumed = new bool[0];
			}
			return false;
		}

		public void ResearchFinished(Combatant combatant)
		{
			this.finishVariables.SetVariables(this.finishUserVariables ?
				combatant.Variables : ORK.Game.Variables);

			if(ResearchItemType.Ability == this.type)
			{
				this.ability.ResearchFinished(combatant);
			}
			else if(ResearchItemType.StatusValue == this.type)
			{
				this.statusValue.ResearchFinished(combatant);
			}
			else if(ResearchItemType.Item == this.type)
			{
				this.item.ResearchFinished(combatant);
			}
		}
	}
}
