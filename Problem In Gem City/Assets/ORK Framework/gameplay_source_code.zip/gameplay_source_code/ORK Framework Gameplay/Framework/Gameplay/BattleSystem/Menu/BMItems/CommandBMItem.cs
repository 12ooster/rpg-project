
using System.Collections.Generic;

namespace ORKFramework.UI
{
	public class CommandBMItem : BMItem
	{
		private Combatant combatant;

		private BattleMenuItem parent;

		public CommandBMItem(ChoiceContent content, Combatant combatant, BattleMenuItem parent)
		{
			this.content = content;
			this.combatant = combatant;
			this.parent = parent;
		}

		public override void CreateDrag(Combatant owner)
		{
			// portrait
			if(this.content.portrait == null && this.combatant != null &&
				owner.BattleMenu.Settings.showCommandPortraits)
			{
				this.content.portrait = this.combatant.GetPortrait(
					owner.BattleMenu.Settings.commandPortraitTypeID);
			}
		}

		public override bool ActiveCheck(Combatant owner)
		{
			bool tmp = this.content.Active;
			// sub menu
			if(this.combatant == null)
			{
				this.content.Active = owner.BattleMenu.CommandedBy == null &&
					!owner.Status.BlockCommand && this.CommandAvailable(owner);
			}
			else
			{
				this.content.Active = !combatant.Status.StopMove;
			}
			return tmp != this.content.Active;
		}

		private bool CommandAvailable(Combatant owner)
		{
			CommandBattleMenuItem settings = (CommandBattleMenuItem)this.parent.settings;
			List<Combatant> members = owner.Group.GetBattle();
			for(int i = 0; i < members.Count; i++)
			{
				if(members[i] != owner &&
					(!settings.onlyAICombatants ||
					members[i].IsAIControlled()))
				{
					return true;
				}
			}
			return false;
		}

		public override void Selected(Combatant owner)
		{
			owner.BattleMenu.TargetHighlight.SelectTarget(this.combatant, null);
		}

		public override bool Accepted(Combatant owner)
		{
			if(owner.BattleMenu != null)
			{
				// list combatants
				if(this.combatant == null)
				{
					CommandBattleMenuItem settings = (CommandBattleMenuItem)this.parent.settings;
					List<BMItem> list = new List<BMItem>();

					// back button first
					if(owner.BattleMenu.Settings.addBack &&
						owner.BattleMenu.Settings.backFirst)
					{
						list.Add(new BackBMItem(
							owner.BattleMenu.Settings.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton)));
					}

					List<Combatant> members = owner.Group.GetBattle();
					for(int i = 0; i < members.Count; i++)
					{
						if(members[i] != owner &&
							(!settings.onlyAICombatants ||
							members[i].IsAIControlled()))
						{
							list.Add(new CommandBMItem(owner.BattleMenu.GetCombatantChoice(members[i]),
								members[i], this.parent));
						}
					}
					// back button last
					if(owner.BattleMenu.Settings.addBack &&
						!owner.BattleMenu.Settings.backFirst)
					{
						list.Add(new BackBMItem(
							owner.BattleMenu.Settings.contentLayout.GetChoiceContent(ORK.MenuSettings.backButton)));
					}

					owner.BattleMenu.Show(list, 0, BattleMenuMode.Command);
				}
				// show combatant's menu
				else
				{
					owner.EndBattleMenu(true);
					this.combatant.BattleMenu.CommandedBy = owner;
					this.combatant.ShowBattleMenu();
				}
				return true;
			}
			return false;
		}
	}
}
