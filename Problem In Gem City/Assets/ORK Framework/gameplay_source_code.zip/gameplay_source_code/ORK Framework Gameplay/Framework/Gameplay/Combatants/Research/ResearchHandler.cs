﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class ResearchHandler : ISaveData
	{
		private Combatant owner;


		// research
		private int inResearchCount = 0;

		private List<ResearchTree> trees;


		// notify
		private Notify changedSimpleHandler;
		public event Notify ChangedSimple
		{
			add { this.changedSimpleHandler += value; }
			remove { this.changedSimpleHandler -= value; }
		}

		private CombatantChanged changedHandler;
		public event CombatantChanged Changed
		{
			add { this.changedHandler += value; }
			remove { this.changedHandler -= value; }
		}


		/*
		============================================================================
		Initialization
		============================================================================
		*/
		public ResearchHandler(Combatant owner)
		{
			this.owner = owner;
			this.owner.Changed += this.Update;
			this.Clear();
		}

		public void Clear()
		{
			this.trees = new List<ResearchTree>();
			this.FireChanged();
		}

		public void FireChanged()
		{
			if(this.changedHandler != null)
			{
				this.changedHandler(this.owner);
			}
		}

		public void Update(Combatant combatant)
		{
			if(this.owner == combatant)
			{
				this.UpdateDurations();
			}
		}

		public Combatant Owner
		{
			get { return this.owner; }
		}

		public bool HasResearch
		{
			get { return this.trees.Count > 0; }
		}


		/*
		============================================================================
		Research functions
		============================================================================
		*/
		public void Tick(float time)
		{
			if(this.inResearchCount > 0)
			{
				for(int i = 0; i < this.trees.Count; i++)
				{
					this.trees[i].TimeProgress(time);
				}
			}
		}

		public void UpdateDurations()
		{
			for(int i = 0; i < this.trees.Count; i++)
			{
				this.trees[i].UpdateDuration();
			}
		}

		public void ResearchStarted(bool count)
		{
			if(count)
			{
				this.inResearchCount++;
			}
			this.FireChanged();
		}

		public void ResearchCanceled(bool count)
		{
			if(count)
			{
				this.inResearchCount--;
				if(this.inResearchCount < 0)
				{
					this.inResearchCount = 0;
				}
			}
			this.FireChanged();
		}

		public void ResearchFinished(bool count)
		{
			if(count)
			{
				this.inResearchCount--;
				if(this.inResearchCount < 0)
				{
					this.inResearchCount = 0;
				}
			}
			this.FireChanged();
		}

		public int InResearch
		{
			get { return this.inResearchCount; }
		}

		public void RemoveInResearch(ResearchTree tree)
		{
			if(tree.InResearch > 0)
			{
				this.inResearchCount -= tree.InResearch;
				this.FireChanged();
			}
		}


		/*
		============================================================================
		Type functions
		============================================================================
		*/
		public void AddType(int researchTypeID, bool checkParent, bool multiAdd, bool showNotification, bool showConsole)
		{
			for(int i = 0; i < ORK.ResearchTrees.Count; i++)
			{
				ResearchTreeSetting tree = ORK.ResearchTrees.Get(i);
				if(tree.researchTypeID == researchTypeID ||
					(checkParent && ORK.ResearchTypes.Get(tree.researchTypeID).IsSubTypeOf(researchTypeID)))
				{
					if(multiAdd || !this.HasTree(tree.RealID))
					{
						ResearchTree tmp = new ResearchTree(this, tree.RealID);
						this.trees.Add(tmp);
						tmp.Setting.ShowTreeAdded(this.owner, tmp, showNotification, showConsole);
					}
				}
			}
			this.FireChanged();
		}

		public void RemoveType(int researchTypeID, bool checkParent, bool removeAll, bool showNotification, bool showConsole)
		{
			for(int i = 0; i < ORK.ResearchTrees.Count; i++)
			{
				ResearchTreeSetting tree = ORK.ResearchTrees.Get(i);
				if(tree.researchTypeID == researchTypeID ||
					(checkParent && ORK.ResearchTypes.Get(tree.researchTypeID).IsSubTypeOf(researchTypeID)))
				{
					for(int j = 0; j < this.trees.Count; j++)
					{
						if(this.trees[j].Setting.RealID == tree.RealID)
						{
							this.trees[j].Setting.ShowTreeRemoved(this.owner, this.trees[j], showNotification, showConsole);
							this.RemoveInResearch(this.trees[j]);
							this.trees.RemoveAt(j--);
							if(!removeAll)
							{
								break;
							}
						}
					}
				}
			}
			this.FireChanged();
		}

		public List<int> GetTypes(int parentType)
		{
			List<int> list = new List<int>();
			for(int i = 0; i < this.trees.Count; i++)
			{
				if(!list.Contains(this.trees[i].Setting.researchTypeID))
				{
					ORK.ResearchTypes.Get(this.trees[i].Setting.researchTypeID).AddTypeToList(parentType, ref list);
				}
			}
			return list;
		}

		public List<int> GetTypes(int parentType,
			bool researchable, bool notResearchableLimit,
			bool notResearchableCosts, bool notResearchableRequirements,
			bool inResearch, bool complete)
		{
			List<int> list = new List<int>();
			for(int i = 0; i < this.trees.Count; i++)
			{
				if(!list.Contains(this.trees[i].Setting.researchTypeID) &&
					this.trees[i].ContainsItemState(
						researchable, notResearchableLimit,
						notResearchableCosts, notResearchableRequirements,
						inResearch, complete))
				{
					ORK.ResearchTypes.Get(this.trees[i].Setting.researchTypeID).AddTypeToList(parentType, ref list);
				}
			}
			return list;
		}

		public bool HasType(bool checkParent, int researchTypeID)
		{
			List<int> types = new List<int>();
			for(int i = 0; i < this.trees.Count; i++)
			{
				if(researchTypeID == -1 ||
					this.trees[i].Setting.researchTypeID == researchTypeID)
				{
					return true;
				}
				else if(checkParent)
				{
					if(!types.Contains(this.trees[i].Setting.researchTypeID))
					{
						if(ORK.ResearchTypes.Get(this.trees[i].Setting.researchTypeID).IsSubTypeOf(researchTypeID))
						{
							return true;
						}
						else
						{
							types.Add(this.trees[i].Setting.researchTypeID);
						}
					}
				}
			}
			return false;
		}

		public bool HasType(bool checkParent, int researchTypeID,
			bool researchable, bool notResearchableLimit,
			bool notResearchableCosts, bool notResearchableRequirements,
			bool inResearch, bool complete)
		{
			List<int> types = new List<int>();
			for(int i = 0; i < this.trees.Count; i++)
			{
				if(this.trees[i].ContainsItemState(
					researchable, notResearchableLimit,
					notResearchableCosts, notResearchableRequirements,
					inResearch, complete))
				{
					if(researchTypeID == -1 ||
						this.trees[i].Setting.researchTypeID == researchTypeID)
					{
						return true;
					}
					else if(checkParent)
					{
						if(!types.Contains(this.trees[i].Setting.researchTypeID))
						{
							if(ORK.ResearchTypes.Get(this.trees[i].Setting.researchTypeID).IsSubTypeOf(researchTypeID))
							{
								return true;
							}
							else
							{
								types.Add(this.trees[i].Setting.researchTypeID);
							}
						}
					}
				}
			}
			return false;
		}

		public List<ResearchTree> GetTreesByType(int researchTypeID, bool checkParent)
		{
			List<ResearchTree> list = new List<ResearchTree>();
			for(int i = 0; i < this.trees.Count; i++)
			{
				if(researchTypeID == -1 ||
					this.trees[i].Setting.researchTypeID == researchTypeID ||
					(checkParent && ORK.ResearchTypes.Get(this.trees[i].Setting.researchTypeID).IsSubTypeOf(researchTypeID)))
				{
					list.Add(this.trees[i]);
				}
			}
			return list;
		}

		public List<ResearchTree> GetTreesByType(int researchTypeID, bool checkParent,
			bool researchable, bool notResearchableLimit,
			bool notResearchableCosts, bool notResearchableRequirements,
			bool inResearch, bool complete)
		{
			List<ResearchTree> list = new List<ResearchTree>();
			for(int i = 0; i < this.trees.Count; i++)
			{
				if((researchTypeID == -1 ||
					this.trees[i].Setting.researchTypeID == researchTypeID ||
					(checkParent && ORK.ResearchTypes.Get(
						this.trees[i].Setting.researchTypeID).IsSubTypeOf(researchTypeID))) &&
					this.trees[i].ContainsItemState(
						researchable, notResearchableLimit,
						notResearchableCosts, notResearchableRequirements,
						inResearch, complete))
				{
					list.Add(this.trees[i]);
				}
			}
			return list;
		}


		/*
		============================================================================
		Tree functions
		============================================================================
		*/
		public void AddTree(int researchTreeID, bool multiAdd, bool showNotification, bool showConsole)
		{
			if(multiAdd || !this.HasTree(researchTreeID))
			{
				ResearchTree tree = new ResearchTree(this, researchTreeID);
				this.trees.Add(tree);
				tree.Setting.ShowTreeAdded(this.owner, tree, showNotification, showConsole);
				this.FireChanged();
			}
		}

		public void RemoveTree(int researchTreeID, bool removeAll, bool showNotification, bool showConsole)
		{
			for(int i = 0; i < this.trees.Count; i++)
			{
				if(this.trees[i].Setting.RealID == researchTreeID)
				{
					this.trees[i].Setting.ShowTreeRemoved(this.owner, this.trees[i], showNotification, showConsole);
					this.RemoveInResearch(this.trees[i]);
					this.trees.RemoveAt(i--);
					if(!removeAll)
					{
						break;
					}
				}
			}
			this.FireChanged();
		}

		public void RemoveTree(ResearchTree researchTree, bool showNotification, bool showConsole)
		{
			if(this.trees.Contains(researchTree))
			{
				researchTree.Setting.ShowTreeRemoved(this.owner, researchTree, showNotification, showConsole);
				this.RemoveInResearch(researchTree);
				this.trees.Remove(researchTree);
				this.FireChanged();
			}
		}

		public List<ResearchTree> GetTree(int researchTreeID)
		{
			List<ResearchTree> list = new List<ResearchTree>();
			for(int i = 0; i < this.trees.Count; i++)
			{
				if(this.trees[i].Setting.RealID == researchTreeID)
				{
					list.Add(this.trees[i]);
				}
			}
			return list;
		}

		public List<ResearchTree> GetAllTrees()
		{
			return new List<ResearchTree>(this.trees);
		}

		public bool HasTree(int researchTreeID)
		{
			for(int i = 0; i < this.trees.Count; i++)
			{
				if(this.trees[i].Setting.RealID == researchTreeID)
				{
					return true;
				}
			}
			return false;
		}

		public bool IsTreeComplete(int researchTreeID)
		{
			for(int i = 0; i < this.trees.Count; i++)
			{
				if(this.trees[i].Setting.RealID == researchTreeID &&
					this.trees[i].IsComplete)
				{
					return true;
				}
			}
			return false;
		}

		public bool CheckTreeState(int researchTreeID, ResearchTreeStateCheck check)
		{
			if(ResearchTreeStateCheck.Known == check)
			{
				return this.HasTree(researchTreeID);
			}
			else if(ResearchTreeStateCheck.Unknown == check)
			{
				return !this.HasTree(researchTreeID);
			}
			else if(ResearchTreeStateCheck.Complete == check)
			{
				return this.IsTreeComplete(researchTreeID);
			}
			return false;
		}


		/*
		============================================================================
		Item functions
		============================================================================
		*/
		public List<ResearchItem> GetItem(int researchTreeID, int researchItem)
		{
			List<ResearchItem> list = new List<ResearchItem>();
			for(int i = 0; i < this.trees.Count; i++)
			{
				if(this.trees[i].Setting.RealID == researchTreeID)
				{
					ResearchItem item = this.trees[i].GetItem(researchItem);
					if(item != null)
					{
						list.Add(item);
					}
				}
			}
			return list;
		}

		public bool CheckItemState(int researchTreeID, int researchItem, ResearchItemState state)
		{
			for(int i = 0; i < this.trees.Count; i++)
			{
				if(this.trees[i].Setting.RealID == researchTreeID)
				{
					ResearchItem item = this.trees[i].GetItem(researchItem);
					if(item != null && item.State == state)
					{
						return true;
					}
				}
			}
			return false;
		}

		public bool CheckItemResearchCount(int researchTreeID, int researchItem, int count, ValueCheck check)
		{
			for(int i = 0; i < this.trees.Count; i++)
			{
				if(this.trees[i].Setting.RealID == researchTreeID)
				{
					ResearchItem item = this.trees[i].GetItem(researchItem);
					if(item != null &&
						ValueHelper.CheckValue(item.ResearchCount, count, check))
					{
						return true;
					}
				}
			}
			return false;
		}


		/*
		============================================================================
		Save game functions
		============================================================================
		*/
		public DataObject SaveGame()
		{
			DataObject data = new DataObject();

			data.Set("inResearchCount", this.inResearchCount);

			// research trees
			DataObject[] tmp = new DataObject[this.trees.Count];
			for(int i = 0; i < this.trees.Count; i++)
			{
				tmp[i] = this.trees[i].SaveGame();
			}
			data.Set("trees", tmp);

			return data;
		}

		public void LoadGame(DataObject data)
		{
			if(data != null)
			{
				data.Get("inResearchCount", ref this.inResearchCount);

				// research trees
				DataObject[] tmp = data.GetFileArray("trees");
				if(tmp != null && tmp.Length > 0)
				{
					for(int i = 0; i < tmp.Length; i++)
					{
						this.trees.Add(new ResearchTree(this, tmp[i]));
					}
				}
			}
		}
	}
}
