﻿
using UnityEngine;
using System.Collections.Generic;

namespace ORKFramework
{
	public class FormulaCall
	{
		public float result = 0;

		public Combatant user;

		public Combatant target;

		private VariableHandler localVariables;

		private SelectedDataHandler selectedData;

		public FormulaCall(float initialValue, Combatant user, Combatant target)
		{
			this.result = initialValue;
			this.user = user;
			this.target = target;
		}

		public FormulaCall(float initialValue, Combatant user, Combatant target,
			SelectedDataHandler selectedData)
		{
			this.result = initialValue;
			this.user = user;
			this.target = target;
			this.selectedData = selectedData;
		}

		public FormulaCall(float initialValue, Combatant user, Combatant target,
			VariableHandler localVariables)
		{
			this.result = initialValue;
			this.user = user;
			this.target = target;
			this.localVariables = localVariables;
		}

		public FormulaCall(float initialValue, Combatant user, Combatant target,
			VariableHandler localVariables, SelectedDataHandler selectedData)
		{
			this.result = initialValue;
			this.user = user;
			this.target = target;
			this.localVariables = localVariables;
			this.selectedData = selectedData;
		}

		public VariableHandler Variables
		{
			get
			{
				if(this.localVariables == null)
				{
					this.localVariables = new VariableHandler(false);
				}
				return this.localVariables;
			}
		}

		public SelectedDataHandler SelectedData
		{
			get
			{
				if(this.selectedData == null)
				{
					this.selectedData = new SelectedDataHandler();
                }
				return this.selectedData;
			}
		}
    }
}
