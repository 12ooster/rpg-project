﻿
using UnityEngine;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("")]
	public class BattleGridCellComponent : MonoBehaviour, ISerializationCallbackReceiver
	{
		// grid info
		public BattleGridComponent parentGrid;

		public int row = 0;

		public int column = 0;


		// cell settings
		[ORKEditorInfo(ORKDataType.BattleGridCellType)]
		public int cellTypeID = 0;

		public bool ownDeployment = false;

		public GridDeploymentCell deployment;


		// cell events
		[ORKEditorInfo("Cell Events", "A cell event can perform abilities and game events on combatants that " +
			"move to/over or start/end their turn on cells of this type.", "",
			endFoldout=true)]
		[ORKEditorArray(false, "Add Cell Event", "Adds a cell event (abilities and game events) that can be performed on combatants on cells of this type.", "",
			"Remove", "Removes this cell event.", "", isCopy=true, isMove=true,
			foldout=true, foldoutText=new string[]
			{
				"Cell Event", "Define when this cell event will be performed and what abilities and game events will be used.", ""
			})]
		[System.NonSerialized]
		public GridCellEvent[] cellEvent = new GridCellEvent[0];

		[SerializeField]
		private ORKDataFile serialize_cellEvent;


		// in-game
		private BattleGridCellType settings;

		[SerializeField]
		private GameObject prefabInstance;

		private CubeCoord cubeCoord;


		// occupant
		private Combatant combatant;

		private Combatant markedForCombatant;

		private List<Combatant> guestCombatants;


		// highlighting
		private GridHighlightType currentHighlight = GridHighlightType.None;

		private Stack<GridHighlightType> highlightStack;

		private Dictionary<GridHighlightType, GameObject> highlight;

		public void Init(BattleGridComponent parentGrid, int row, int column)
		{
			this.parentGrid = parentGrid;
			this.row = row;
			this.column = column;
		}

		public BattleGridCellType Settings
		{
			get
			{
				if(this.settings == null &&
					ORK.Initialized)
				{
					this.settings = ORK.BattleGridCellTypes.Get(this.cellTypeID);
				}
				return this.settings;
			}
			set { this.settings = value; }
		}

		public CubeCoord CubeCoord
		{
			get
			{
				if(this.cubeCoord == null)
				{
					this.cubeCoord = CubeCoord.FromOffset(this.row, this.column);
				}
				return this.cubeCoord;
			}
		}

		public bool IsBlocked
		{
			get { return this.Settings.blocked; }
		}

		public bool IsPassable
		{
			get { return !this.Settings.blocked || this.settings.passable; }
		}


		/*
		============================================================================
		Combatant functions
		============================================================================
		*/
		public bool CanDeploy(Combatant combatant)
		{
			return !this.IsBlocked &&
				this.combatant == null &&
				(this.ownDeployment ?
					this.deployment.CanDeploy(combatant) :
					this.Settings.deployment.CanDeploy(combatant));
		}

		public bool IsEmpty
		{
			get
			{
				return this.combatant == null &&
					this.markedForCombatant == null &&
					!this.HasGuests;
			}
		}

		public Combatant Combatant
		{
			get { return this.combatant; }
			set
			{
				if(this.combatant != value)
				{
					// reset current combatant's grid cell
					if(this.combatant != null &&
						this.combatant.GridCell == this)
					{
						Combatant tmpCombatant = this.combatant;
						this.combatant = null;
						tmpCombatant.GridCell = null;
					}

					this.combatant = value;
					this.markedForCombatant = null;
					if(this.HasGuests)
					{
						this.guestCombatants.Remove(this.combatant);
					}

					// set new combatant's grid cell
					if(this.combatant != null)
					{
						this.combatant.GridCell = this;
					}
					this.parentGrid.FireGridChanged();
				}
			}
		}

		public Combatant MarkedForCombatant
		{
			get { return this.markedForCombatant; }
			set
			{
				if(this.markedForCombatant != value)
				{
					this.markedForCombatant = value;
					this.parentGrid.FireGridChanged();
				}
			}
		}

		public bool HasGuests
		{
			get
			{
				return this.guestCombatants != null &&
					this.guestCombatants.Count > 0;
			}
		}

		public List<Combatant> GetGuests()
		{
			return this.guestCombatants;
		}

		public bool IsGuest(Combatant combatant)
		{
			return this.HasGuests &&
				this.guestCombatants.Contains(combatant);
		}

		public void AddGuest(Combatant combatant)
		{
			if(this.guestCombatants == null)
			{
				this.guestCombatants = new List<Combatant>();
			}
			if(!this.guestCombatants.Contains(combatant))
			{
				this.guestCombatants.Add(combatant);
				combatant.AddGuestCell(this);
				this.parentGrid.FireGridChanged();
			}
		}

		public void RemoveGuest(Combatant combatant)
		{
			if(this.guestCombatants != null &&
				this.guestCombatants.Contains(combatant))
			{
				this.guestCombatants.Remove(combatant);
				combatant.RemoveGuestCell(this);
				this.parentGrid.FireGridChanged();
			}
		}

		public void GetCombatants(ref List<Combatant> list, CombatantCheck check)
		{
			if(this.combatant != null &&
				!list.Contains(this.combatant) &&
				(check == null || check(this.combatant)))
			{
				list.Add(this.combatant);
			}
			if(this.HasGuests)
			{
				for(int i = 0; i < this.guestCombatants.Count; i++)
				{
					if(!list.Contains(this.guestCombatants[i]) &&
						(check == null || check(this.guestCombatants[i])))
					{
						list.Add(this.guestCombatants[i]);
					}
				}
			}
		}

		public bool CheckOccupants(CombatantCheck check)
		{
			if(check != null)
			{
				if(check(this.combatant))
				{
					return true;
				}
				else if(this.HasGuests)
				{
					for(int i = 0; i < this.guestCombatants.Count; i++)
					{
						if(check(this.guestCombatants[i]))
						{
							return true;
						}
					}
				}
			}
			return false;
		}

		public void SwapCombatants(BattleGridCellComponent other, bool placeAtCell)
		{
			if(!this.IsBlocked &&
				other != null &&
				!other.IsBlocked)
			{
				Combatant tmpCombatant = this.combatant;
				this.combatant = null;
				this.Combatant = other.combatant;

				other.combatant = null;
				other.Combatant = tmpCombatant;

				if(placeAtCell)
				{
					if(this.combatant != null)
					{
						this.combatant.GameObject.transform.position = this.transform.position;
					}
					if(other.combatant != null)
					{
						other.combatant.GameObject.transform.position = other.transform.position;
					}
				}
			}
		}


		/*
		============================================================================
		Prefab functions
		============================================================================
		*/
		public GameObject PrefabInstance
		{
			get { return this.prefabInstance; }
		}

		public GameObject HighlightPrefabInstance
		{
			get
			{
				if(this.highlight != null &&
					this.highlight.ContainsKey(this.currentHighlight))
				{
					return this.highlight[this.currentHighlight];
				}
				return null;
			}
			set
			{
				if(this.highlight == null)
				{
					this.highlight = new Dictionary<GridHighlightType, GameObject>();
				}
				if(this.highlight.ContainsKey(this.currentHighlight))
				{
					this.highlight[this.currentHighlight] = value;
				}
				else
				{
					this.highlight.Add(this.currentHighlight, value);
				}
			}
		}

		public void ShowPrefab()
		{
			if(this.prefabInstance == null &&
				this.Settings != null)
			{
				this.prefabInstance = this.Settings.prefab.CreatePrefabInstance(this.transform);
			}
		}

		public void HidePrefab()
		{
			if(this.prefabInstance != null)
			{
				this.prefabInstance.SetActive(false);
			}
			if(this.highlight != null)
			{
				foreach(KeyValuePair<GridHighlightType, GameObject> pair in this.highlight)
				{
					if(pair.Value != null)
					{
						pair.Value.SetActive(false);
					}
				}
			}
		}

		public void DestroyPrefab()
		{
			if(this.prefabInstance != null)
			{
				GameObject.Destroy(this.prefabInstance);
			}
			if(this.highlight != null)
			{
				foreach(KeyValuePair<GridHighlightType, GameObject> pair in this.highlight)
				{
					if(pair.Value != null)
					{
						GameObject.Destroy(pair.Value);
					}
				}
			}
		}


		/*
		============================================================================
		Highlight functions
		============================================================================
		*/
		public void Highlight(GridHighlightType highlightType)
		{
			if(this.currentHighlight != highlightType)
			{
				if(GridHighlightType.None != this.currentHighlight)
				{
					if(this.highlightStack == null)
					{
						this.highlightStack = new Stack<GridHighlightType>();
					}
					this.highlightStack.Push(this.currentHighlight);
					this.DoStopHighlight();
				}

				this.currentHighlight = highlightType;
				this.DoHighlight();
			}
		}

		public void StopHighlight(GridHighlightType highlightType)
		{
			if(this.currentHighlight == highlightType)
			{
				this.DoStopHighlight();

				if(this.highlightStack != null &&
					this.highlightStack.Count > 0)
				{
					this.currentHighlight = this.highlightStack.Pop();
					this.DoHighlight();
				}
				else
				{
					this.currentHighlight = GridHighlightType.None;
				}
			}
			else if(this.highlightStack != null &&
				this.highlightStack.Contains(highlightType))
			{
				this.RemoveLastFromStack(highlightType);
			}
		}

		private void RemoveLastFromStack(GridHighlightType highlightType)
		{
			if(this.highlightStack != null &&
				this.highlightStack.Count > 0)
			{
				GridHighlightType tmpType = this.highlightStack.Pop();
				if(highlightType != tmpType)
				{
					this.RemoveLastFromStack(highlightType);
					this.highlightStack.Push(tmpType);
				}
			}
		}

		public void StopAllHighlights()
		{
			if(GridHighlightType.None != this.currentHighlight)
			{
				this.DoStopHighlight();

				if(this.highlightStack != null &&
					this.highlightStack.Count > 0)
				{
					this.highlightStack.Clear();
				}
				this.currentHighlight = GridHighlightType.None;
			}
		}

		private void DoHighlight()
		{
			if(GridHighlightType.Placement == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.placementHighlight.Highlight(this);
			}
			else if(GridHighlightType.PlacementSelection == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.placementSelectionHighlight.Highlight(this);
			}
			else if(GridHighlightType.NoPlacementSelection == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.noPlacementSelectionHighlight.Highlight(this);
			}
			else if(GridHighlightType.MoveRange == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.moveRangeHighlight.Highlight(this);
			}
			else if(GridHighlightType.MoveSelection == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.moveSelectionHighlight.Highlight(this);
			}
			else if(GridHighlightType.NoMoveSelection == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.noMoveSelectionHighlight.Highlight(this);
			}
			else if(GridHighlightType.MovePath == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.movePathHighlight.Highlight(this);
			}
			else if(GridHighlightType.OrientationSelection == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.orientationSelectionHighlight.Highlight(this);
			}
			else if(GridHighlightType.UseRange == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.useRangeHighlight.Highlight(this);
			}
			else if(GridHighlightType.AffectRange == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.affectRangeHighlight.Highlight(this);
			}
			else if(GridHighlightType.TargetCellSelection == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.targetCellSelectionHighlight.Highlight(this);
			}
			else if(GridHighlightType.NoTargetCellSelection == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.noTargetCellSelectionHighlight.Highlight(this);
			}
			else if(GridHighlightType.Examine == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.examineHighlight.Highlight(this);
			}
			else if(GridHighlightType.ExamineMoveRange == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.moveRangeHighlight.Highlight(this);
			}
			else if(GridHighlightType.ExamineUseRange == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.useRangeHighlight.Highlight(this);
			}
		}

		private void DoStopHighlight()
		{
			if(GridHighlightType.Placement == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.placementHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.PlacementSelection == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.placementSelectionHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.NoPlacementSelection == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.noPlacementSelectionHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.MoveRange == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.moveRangeHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.MoveSelection == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.moveSelectionHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.NoMoveSelection == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.noMoveSelectionHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.MovePath == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.movePathHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.OrientationSelection == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.orientationSelectionHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.UseRange == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.useRangeHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.AffectRange == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.affectRangeHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.TargetCellSelection == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.targetCellSelectionHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.NoTargetCellSelection == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.noTargetCellSelectionHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.Examine == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.examineHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.ExamineMoveRange == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.moveRangeHighlight.StopHighlight(this);
			}
			else if(GridHighlightType.ExamineUseRange == this.currentHighlight)
			{
				ORK.BattleSystem.gridSettings.useRangeHighlight.StopHighlight(this);
			}
		}


		/*
		============================================================================
		Cell event functions
		============================================================================
		*/
		public void GetCellEvents(ref List<GridCellEventCall> cellEvents, GridCellEventStartType startType)
		{
			// cell type events
			if(this.Settings != null)
			{
				for(int i = 0; i < this.Settings.cellEvent.Length; i++)
				{
					if(this.Settings.cellEvent[i].startType == startType ||
						this.Settings.cellEvent[i].startType == GridCellEventStartType.Any ||
						GridCellEventStartType.Any == startType)
					{
						cellEvents.Add(new GridCellEventCall(this, this.Settings.cellEvent[i]));
					}
				}
			}
			// cell events
			for(int i = 0; i < this.cellEvent.Length; i++)
			{
				if(this.cellEvent[i].startType == startType ||
					this.cellEvent[i].startType == GridCellEventStartType.Any ||
					GridCellEventStartType.Any == startType)
				{
					cellEvents.Add(new GridCellEventCall(this, this.cellEvent[i]));
				}
			}
		}


		/*
		============================================================================
		Serialization functions
		============================================================================
		*/
		public void OnBeforeSerialize()
		{
			DataObject data = new DataObject();
			DataObject[] events = new DataObject[this.cellEvent.Length];
			for(int i = 0; i < this.cellEvent.Length; i++)
			{
				events[i] = this.cellEvent[i].GetData();
			}
			data.Set("cellEvents", events);
			this.serialize_cellEvent = data.GetDataFile("cellEvents", false);
		}

		public void OnAfterDeserialize()
		{
			this.cellEvent = new GridCellEvent[0];
			if(this.serialize_cellEvent != null)
			{
				DataObject data = this.serialize_cellEvent.ToDataObject();
				DataObject[] events = data.GetFileArray("cellEvents");
				if(events != null)
				{
					this.cellEvent = new GridCellEvent[events.Length];
					for(int i = 0; i < this.cellEvent.Length; i++)
					{
						this.cellEvent[i] = new GridCellEvent();
						this.cellEvent[i].SetData(events[i]);
					}
				}
			}
			this.serialize_cellEvent = null;
		}
	}
}
