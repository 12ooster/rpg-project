
using ORKFramework;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Controls/No Click Move")]
	public class NoClickMove : BaseColliderZone
	{
		void Start()
		{
			this.gameObject.layer = 2;
			if(this.GetComponent<Collider>() == null && 
				this.GetComponent<Collider2D>() == null)
			{
				GameObject.Destroy(this.gameObject);
			}
			else
			{
				ORK.Game.Scene.AddNoClickMove(this);
			}
		}
	}
}
