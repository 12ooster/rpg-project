
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using ORKFramework;
using System.Collections.Generic;

namespace ORKFramework.Behaviours
{
	public class UIMouseOverComponent : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
	{
		public void OnPointerEnter(PointerEventData eventData)
		{
			ORK.GUI.AddMouseOverObject(this.gameObject);
		}
		
		public void OnPointerExit(PointerEventData eventData)
		{
			ORK.GUI.RemoveMouseOverObject(this.gameObject);
		}

		void OnDestroy()
		{
			ORK.GUI.RemoveMouseOverObject(this.gameObject);
		}

		void OnDisable()
		{
			ORK.GUI.RemoveMouseOverObject(this.gameObject);
		}
	}
}

