
using ORKFramework;
using UnityEngine;

namespace ORKFramework.Behaviours
{
	[AddComponentMenu("ORK Framework/Controls/Camera: Smooth Follow")]
	public class SmoothFollow : BaseCameraControl
	{
		public string onChild = "";

		public float distance = 10.0f;
	
		public float height = 5.0f;
	
		public float heightDamping = 2.0f;

		public float rotationDamping = 3.0f;
	
		void LateUpdate()
		{
			GameObject obj = TransformHelper.GetChildObject(this.onChild, this.CameraTarget);
			if(obj != null)
			{
				Transform target = obj.transform;
			
				// Calculate the current rotation angles
				float wantedRotationAngle = target.eulerAngles.y;
				float wantedHeight = target.position.y + this.height;
				
				float currentRotationAngle = transform.eulerAngles.y;
				float currentHeight = transform.position.y;
			
				// Damp the rotation around the y-axis
				if(this.rotationDamping > 0)
				{
					currentRotationAngle = Mathf.LerpAngle(currentRotationAngle, wantedRotationAngle, this.rotationDamping * Time.deltaTime);
				}
				else
				{
					currentRotationAngle = wantedRotationAngle;
				}
				

				// Damp the height
				if(this.heightDamping > 0)
				{
					currentHeight = Mathf.Lerp(currentHeight, wantedHeight, this.heightDamping * Time.deltaTime);
				}
				else
				{
					currentHeight = wantedHeight;
				}

				// Convert the angle into a rotation
				Quaternion currentRotation = Quaternion.Euler(0, currentRotationAngle, 0);
			
				// Set the position of the camera on the x-z plane to:
				// distance meters behind the target
				transform.position = target.position;
				transform.position -= currentRotation * Vector3.forward * this.distance;

				// Set the height of the camera
				Vector3 pos = transform.position;
				pos.y = currentHeight;
				transform.position = pos;
			
				// Always look at the target
				transform.LookAt(target);
			}
		}
	}
}
