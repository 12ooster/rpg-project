
using UnityEngine;
using UnityEngine.UI;
using ORKFramework.UI;
using System.Collections.Generic;
using System.Collections;

namespace ORKFramework.Behaviours
{
	public class UIChoiceButtonComponent : MonoBehaviour
	{
		private GUIBox box;

		private ChoiceContent content;

		private Button button;

		private ButtonClick callback;

		private int choiceIndex = 0;


		// fade
		private NewUIButtonSettings buttonSettings;

		private Color lastColor;

		private CanvasRenderer canvasRenderer;

		private List<CanvasRenderer> childRenderer;

		public void Initialize(GUIBox box, ChoiceContent content, Button button, ButtonClick callback, int choiceIndex, NewUIButtonSettings buttonSettings)
		{
			this.box = box;
			this.content = content;
			this.buttonSettings = buttonSettings;

			this.button = button;
			this.callback = callback;
			this.choiceIndex = choiceIndex;
			if(this.button != null)
			{
				this.button.onClick.AddListener(this.ClickDelegate);
			}

			if(this.buttonSettings != null)
			{
				if(this.buttonSettings.fadeMode == ChildColorFadeMode.None)
				{
					this.canvasRenderer = null;
					if(this.childRenderer != null)
					{
						this.childRenderer.Clear();
					}
				}
				else
				{
					this.canvasRenderer = this.GetComponent<CanvasRenderer>();
					ArrayHelper.GetBlank(ref this.childRenderer);
					this.GetComponentsInChildren<CanvasRenderer>(this.childRenderer);
					this.childRenderer.Remove(this.canvasRenderer);
				}
			}
		}

		private void ClickDelegate()
		{
			if(this.callback != null)
			{
				this.callback(this.choiceIndex);
			}
		}

		public void Clear()
		{
			if(this.button != null &&
				this.callback != null)
			{
				this.button.onClick.RemoveListener(this.ClickDelegate);
			}
			if(this.content != null)
			{
				this.content.buttonRectTransform = null;
			}

			this.box = null;
			this.content = null;
			this.button = null;
			this.buttonSettings = null;
			this.canvasRenderer = null;
			if(this.childRenderer != null)
			{
				this.childRenderer.Clear();
			}
		}

		void LateUpdate()
		{
			if(this.box != null &&
				this.box.IsOpened &&
				this.canvasRenderer != null &&
				this.childRenderer != null &&
				this.childRenderer.Count > 0 &&
				this.buttonSettings != null)
			{
				Color color = this.canvasRenderer.GetColor();
				if(this.buttonSettings.useInactiveColor &&
					!this.button.interactable)
				{
					color = this.buttonSettings.inactiveColor;
				}

				if(this.box.controlable && this.box.focusable &&
					!this.box.Focused && this.box.InactiveColor.setColor)
				{
					color = this.box.InactiveColor.color;
					this.canvasRenderer.SetColor(color);
				}

				if(this.buttonSettings.fadeMode == ChildColorFadeMode.Alpha)
				{
					if(color.a != this.lastColor.a)
					{
						for(int i = 0; i < this.childRenderer.Count; i++)
						{
							this.childRenderer[i].SetAlpha(color.a);
						}
						this.lastColor = color;
					}
				}
				else if(this.buttonSettings.fadeMode == ChildColorFadeMode.Color)
				{
					if(color != this.lastColor)
					{
						for(int i = 0; i < this.childRenderer.Count; i++)
						{
							this.childRenderer[i].SetColor(color);
						}
						this.lastColor = color;
					}
				}
			}
		}
	}
}
